import configure_parameters

class Arc:
    def __init__(self, start_vertex, end_vertex, demanda, coste):
        self.start_vertex = start_vertex
        self.end_vertex = end_vertex
        self.coste = coste
        self.demanda = demanda
        self.coste_original = coste
        self.demanda_original = demanda

        self.reverse_arc = None

        # URARP: ring membership
        self.ring_id = None           # which ring this arc belongs to (1-based, None = non-ring)
        self.ring_sequence = None     # position index in the ring cycle (0-based)
        self.ring_total = None        # total number of arcs in the ring

    @property
    def is_ring_arc(self):
        """Whether this arc belongs to a ring (must be serviced)."""
        return self.ring_id is not None

    @property
    def is_ring_entry(self):
        """Whether this arc is the first arc in its ring cycle."""
        return self.ring_sequence == 0

    def set_reverse(self, reverse_arc):
        self.reverse_arc = reverse_arc


    def randomize(self, seed=None, rng=None):
        """Only perturb arc cost; demand is no longer used in URARP."""
        if rng is None:
            import random
            rng = random.Random(seed)

        try:
            new_coste = int(rng.gauss(self.coste_original, self.coste_original * configure_parameters.cost_change_rate))
        except OverflowError:
            new_coste = self.coste_original
        new_coste = max(1, new_coste)

        self.coste = new_coste

        if self.reverse_arc:
            self.reverse_arc.coste = self.coste

    def __repr__(self):
        return f"({self.start_vertex}->{self.end_vertex}, demanda={self.demanda}, coste={self.coste})"

    def __eq__(self, other):
        return isinstance(other, Arc) and \
            self.start_vertex == other.start_vertex and \
            self.end_vertex == other.end_vertex and \
            self.demanda == other.demanda and \
            self.coste == other.coste

    def __hash__(self):
        return hash((self.start_vertex, self.end_vertex, self.demanda, self.coste))

    def copy(self):
        """Returns an independent Arc copy (reverse_arc must be re-linked separately)."""
        new_arc = Arc(self.start_vertex, self.end_vertex, self.demanda, self.coste)
        new_arc.coste_original = self.coste_original
        new_arc.demanda_original = self.demanda_original
        new_arc.ring_id = self.ring_id
        new_arc.ring_sequence = self.ring_sequence
        new_arc.ring_total = self.ring_total
        # reverse_arc is NOT copied — must be linked explicitly after copy
        return new_arc
