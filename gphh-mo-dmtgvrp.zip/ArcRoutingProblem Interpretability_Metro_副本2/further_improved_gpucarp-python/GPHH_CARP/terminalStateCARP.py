# 给出每个 terminal 的具体取值
current_state = None  # 全局变量


def _get(attr, default = 1.0):
    if current_state is None:
        return default
    val = getattr(current_state, attr, None)
    if val is None:
        return None
    return float(val)


def CFH():
    return _get('cost_from_here')


def CFD():
    return _get('cost_from_arc_depot')


def CFR1():
    return _get('cost_from_otherRoutes_task')


def CTT1():
    return _get('cost_from_candidate_others')


def CTD():
    return _get('cost_from_depot_arc')


def CR():
    return _get('cost_from_depot_location')


def DEM():
    return _get('demand')


def DEM1():
    return _get('dem1')


def DC():
    return _get('deadheading_cost')


def FULL():
    return _get('fullness')


def FRT():
    return _get('fraction_unserved_tasks')


def FUT():
    return _get('fraction_unasigned_tasks')


def RQ():
    return _get('demand_left')


def RQ1():
    return _get('remaing_query')


def SC():
    return _get('serving_cost')


def ERC():
    return _get('random_value')
