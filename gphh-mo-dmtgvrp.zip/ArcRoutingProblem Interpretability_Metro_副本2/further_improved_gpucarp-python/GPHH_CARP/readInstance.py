import os
import re
import math
import heapq
from collections import defaultdict

from Arc import Arc
from Vehicle import Vehicle


##这里用的是贪心算法

# =========================================================
# 读取算例
# =========================================================
def load_instance_text(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()


# =========================================================
# 解析算例
# =========================================================
def parse_carp_instance(text: str):
    vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
    vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
    capacidad = int(re.search(r"CAPACIDAD\s*:\s*(\d+)", text).group(1))
    deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

    edges = []
    edge_pattern = re.compile(
        r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)\s*demanda\s*(\d+)"
    )

    for m in edge_pattern.finditer(text):
        u, v, coste, demanda = map(int, m.groups())
        arc_fwd = Arc(u, v, demanda, coste)
        arc_rev = Arc(v, u, demanda, coste)
        arc_fwd.set_reverse(arc_rev)
        arc_rev.set_reverse(arc_fwd)
        edges.append(arc_fwd)
        edges.append(arc_rev)

    return {
        "vertices": vertices,
        "vehiculos": vehiculos,
        "capacidad": capacidad,
        "deposito": deposito,
        "edges": edges
    }


# =========================================================
# Dijkstra（单源最短路）
# =========================================================
def dijkstra(start, vertices, adj):
    dist = {v: math.inf for v in range(1, vertices + 1)}
    dist[start] = 0.0
    pq = [(0.0, start)]

    while pq:
        cur_dist, u = heapq.heappop(pq)
        if cur_dist > dist[u]:
            continue
        for v, cost in adj.get(u, []):
            nd = cur_dist + cost
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(pq, (nd, v))
    return dist


# =========================================================
# 构建 / 更新 OD 矩阵（严格三层优先级）
# =========================================================
def build_dynamic_od_matrix(vertices, instance, remaining_edges):
    """
    OD 生成规则（严格）：
    0. od[i][i] = 0，其余 inf
    1. instance 中弧 coste
    2. remaining_edges 中弧 coste 覆盖
    3. shortest path 填充剩余 inf
    """

    # -------------------------------------------------
    # Step 0. 初始化 od
    # -------------------------------------------------
    od = {
        i: {j: math.inf for j in range(1, vertices + 1)}
        for i in range(1, vertices + 1)
    }
    for i in range(1, vertices + 1):
        od[i][i] = 0.0

    # -------------------------------------------------
    # Step 1. 率先定义邻接节点
    # -------------------------------------------------
    adj = defaultdict(dict)  # 用 dict，方便覆盖 cost

    # -------------------------------------------------
    # Step 2. 用 remaining_edges 覆盖
    # -------------------------------------------------
    for arc in remaining_edges:
        od[arc.start_vertex][arc.end_vertex] = arc.coste
        adj[arc.start_vertex][arc.end_vertex] = arc.coste

    # -------------------------------------------------
    # Step 3. 用 instance["edges"] 补全
    # -------------------------------------------------
    for arc in instance["edges"]:
        if arc not in remaining_edges:
            od[arc.start_vertex][arc.end_vertex] = arc.coste
            adj[arc.start_vertex][arc.end_vertex] = arc.coste

    # -------------------------------------------------
    # Step 4. 最短路径填充
    # -------------------------------------------------
    # dijkstra 需要 list[(v, cost)]，这里做一次转换
    adj_list = {
        u: [(v, c) for v, c in nbrs.items()]
        for u, nbrs in adj.items()
    }

    for i in range(1, vertices + 1):
        dist = dijkstra(i, vertices, adj_list)
        for j in range(1, vertices + 1):
            if od[i][j] == math.inf and dist[j] < math.inf:
                od[i][j] = dist[j]

    return od


# =========================================================
# 基于 OD 选择下一条弧
# =========================================================

def select_next_edge(current_pos, remaining_edges, od):
    """
    选择下一条要服务的弧
    规则：最小化 当前节点 → 弧起点 的最短路成本
    """
    best_arc = None
    best_cost = float('inf')

    for arc in remaining_edges:
        cost = od[current_pos][arc.start_vertex]
        if cost < best_cost:
            best_cost = cost
            best_arc = arc

    return best_arc


def shortest_path_nodes(start, end, od):
    """
    基于 od 距离矩阵恢复一条最短路
    假设 od 是对称且无负权
    """
    if start == end:
        return [start]

    # 使用 Dijkstra（节点集合来自 od 的 key）
    dist = {v: float('inf') for v in od}
    prev = {}
    dist[start] = 0

    pq = [(0, start)]

    while pq:
        d, u = heapq.heappop(pq)
        if u == end:
            break
        if d > dist[u]:
            continue

        for v in od[u]:
            w = od[u][v]
            if w == float('inf'):
                continue
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heapq.heappush(pq, (nd, v))

    # 回溯路径
    path = [end]
    while path[-1] != start:
        path.append(prev[path[-1]])
    path.reverse()
    return path

# =========================================================
# 主逻辑：逐步构建路径
# =========================================================
def stepwise_build_paths(instance, seed=None):
    remaining_edges = instance["edges"].copy()
    vertices = instance["vertices"]
    vehiculos = instance["vehiculos"]
    capacidad = instance["capacidad"]
    deposito = instance["deposito"]

    vehicles = [Vehicle(vehicle_count=vehiculos, capacity=capacidad, start_depot=deposito) for _ in range(vehiculos)]

    positions = [deposito] * vehiculos
    step = 0

    while remaining_edges:
        print(f"\n=== Step {step} ===")

        for i, vehicle in enumerate(vehicles):
            if not remaining_edges:
                break

            # ---------------------------------------------
            # 1. 扰动 coste / demanda
            # ---------------------------------------------
            for arc in remaining_edges:
                arc.randomize(seed=seed)

            # ---------------------------------------------
            # 2. 构建动态 OD
            # ---------------------------------------------
            od = build_dynamic_od_matrix(vertices, instance, remaining_edges)

            # ---------------------------------------------
            # 3. 选择下一条弧
            # ---------------------------------------------
            arc = select_next_edge(positions[i], remaining_edges, od)

            if arc is None:
                continue

            # ---------------------------------------------
            # 4. 容量不足 → 立即回库
            # ---------------------------------------------
            if vehicle.remain_capacity < arc.demanda:
                if positions[i] != deposito:
                    return_cost = od[positions[i]][deposito]
                    return_path = shortest_path_nodes(positions[i], deposito, od)
                    vehicle.finish_route(return_path, return_cost)

                positions[i] = deposito
                vehicle.reset_capacity()
                continue

            # ---------------------------------------------
            # 5. 容量消耗
            # ---------------------------------------------
            vehicle.use_capacity(arc.demanda)

            # ---------------------------------------------
            # 6. 移动到弧起点
            # ---------------------------------------------
            if positions[i] != arc.start_vertex:
                move_cost = od[positions[i]][arc.start_vertex]
                path_nodes = shortest_path_nodes(
                    positions[i],
                    arc.start_vertex,
                    od
                )
                vehicle.add_move_path(path_nodes, move_cost)

            # ---------------------------------------------
            # 7. 服务弧
            # ---------------------------------------------
            vehicle.add_service_arc(
                arc.start_vertex,
                arc.end_vertex,
                arc.coste
            )
            positions[i] = arc.end_vertex

            # ---------------------------------------------
            # 8. 删除已服务弧（正反）
            # ---------------------------------------------
            remaining_edges = [
                e for e in remaining_edges
                if e != arc and e != arc.reverse_arc
            ]

        step += 1

    # ---------------------------------------------
    # 9. 所有车辆最终回库
    # ---------------------------------------------
    for i, vehicle in enumerate(vehicles):
        if positions[i] != deposito:
            od = build_dynamic_od_matrix(
                vertices,
                instance,
                remaining_edges=[]
            )
            return_cost = od[positions[i]][deposito]
            return_path = shortest_path_nodes(
                positions[i],
                deposito,
                od
            )
            vehicle.finish_route(return_path, return_cost)

    return vehicles

# =========================================================
# 主程序
# =========================================================
if __name__ == "__main__":
    file_path = "data/val/val1A.dat"
    instance_text = load_instance_text(file_path)
    instance = parse_carp_instance(instance_text)

    vehicles = stepwise_build_paths(instance, seed=42)


    a = 1