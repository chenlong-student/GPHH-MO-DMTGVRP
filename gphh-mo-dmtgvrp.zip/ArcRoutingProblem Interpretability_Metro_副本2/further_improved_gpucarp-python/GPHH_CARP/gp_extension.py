import deap.gp
import configure_parameters
from functools import wraps


def staticLimitWithMaxRetries(key, max_value, max_retries=configure_parameters.max_attempts_unique):
    """
    带最大重试次数的静态限制装饰器，用于防止GP树爆炸
    """

    def decorator(func):
        @wraps(func)  # 可选：保留被装饰函数的元信息（函数名、文档字符串等）
        def wrapper(*args, **kwargs):
            retry_count = 0
            while retry_count < max_retries:
                result = func(*args, **kwargs)
                is_valid = True
                if isinstance(result, tuple):
                    for ind in result:
                        if key(ind) > max_value:
                            is_valid = False
                            break
                else:
                    if key(result) > max_value:
                        is_valid = False
                if is_valid:
                    return result
                retry_count += 1
            # 兜底逻辑：重试耗尽后返回最后一次结果（避免返回None导致异常）
            return result

        return wrapper

    return decorator

deap.gp.staticLimitWithMaxRetries = staticLimitWithMaxRetries