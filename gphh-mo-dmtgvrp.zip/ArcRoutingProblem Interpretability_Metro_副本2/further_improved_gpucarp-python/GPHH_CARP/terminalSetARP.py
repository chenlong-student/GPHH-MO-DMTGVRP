from deap import gp
import configure_parameters


def terminal_set():
    if configure_parameters.problem == "CARP":
        return terminal_set_CARP()
    elif configure_parameters.problem == "CPP":
        return terminal_set_CPP()
    elif configure_parameters.problem == "RPP":
        return terminal_set_RPP()
    elif configure_parameters.problem == "kRPP":
        return terminal_set_kRPP()
    elif configure_parameters.problem == "URARP":
        return terminal_set_URARP()


def _build_pset(terminal_names):
    pset = gp.PrimitiveSet("MAIN", 0)

    for terminal_name in terminal_names:
        pset.addTerminal(1.0, name=terminal_name)

    return pset


def terminal_set_CARP():
    terminal_names = [
        "CFH",
        "CFD",
        "CR",
        "CTD",
        "DC",
        "DEM",
        "FRT",
        "FUT",
        "FULL",
        "RQ",
        "SC",
    ]

    if configure_parameters.terminals_from == "extended":
        terminal_names.extend(["CFR1", "CTT1", "DEM1"])

    if configure_parameters.include_erc:
        terminal_names.append("ERC")

    return _build_pset(terminal_names)


def terminal_set_CPP():
    terminal_names = [
        "CFH",
        "CFD",
        "CR",
        "CTD",
        "DC",
        "FRT",
        "FUT",
        "SC",
    ]

    if configure_parameters.terminals_from == "extended":
        terminal_names.extend(["CFR1", "CTT1"])

    if configure_parameters.include_erc:
        terminal_names.append("ERC")

    return _build_pset(terminal_names)


def terminal_set_RPP():
    terminal_names = [
        "CFH",
        "CFD",
        "CR",
        "CTD",
        "DC",
        "FRT",
        "FUT",
        "SC",
    ]

    if configure_parameters.terminals_from == "extended":
        terminal_names.extend(["CFR1", "CTT1"])

    if configure_parameters.include_erc:
        terminal_names.append("ERC")

    return _build_pset(terminal_names)


def terminal_set_URARP():
    """URARP GP terminal set — no DEM/DEM1/FULL since URARP has no demand or capacity."""
    terminal_names = [
        "CFH",
        "CFD",
        "CR",
        "CTD",
        "DC",
        "FRT",
        "FUT",
        "RQ",
        "SC",
    ]

    if configure_parameters.terminals_from == "extended":
        terminal_names.extend(["CFR1", "CTT1"])

    if configure_parameters.include_erc:
        terminal_names.append("ERC")

    return _build_pset(terminal_names)


def terminal_set_kRPP():
    terminal_names = [
        "CFH",
        "CFD",
        "CR",
        "CTD",
        "DC",
        "FRT",
        "FUT",
        "SC",
        "FULL",
        "RQ",
    ]

    if configure_parameters.terminals_from == "extended":
        terminal_names.extend(["CFR1", "CTT1"])

    if configure_parameters.include_erc:
        terminal_names.append("ERC")

    return _build_pset(terminal_names)
