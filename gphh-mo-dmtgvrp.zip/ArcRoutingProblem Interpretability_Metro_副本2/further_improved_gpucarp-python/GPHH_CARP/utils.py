from deap import gp, creator
import terminalStateCARP
from toolBoxCARP import toolbox
import configure_parameters
from State import State

def _extract_subtree(individual, start_idx):
    """Extract a PrimitiveTree subtree starting at start_idx."""
    sub_slice = individual.searchSubtree(start_idx)
    return gp.PrimitiveTree(individual[sub_slice])


def _find_best_valid_subtree(individual, max_height, max_length):
    """Find the largest valid subtree from root that satisfies both height and length constraints.

    Scans from the root downward, keeping track of the largest subtree
    (by node count) whose height <= max_height AND len <= max_length.
    """
    best_tree = None
    best_size = 0

    for idx in range(len(individual)):
        sub_tree = _extract_subtree(individual, idx)
        if sub_tree.height <= max_height and len(sub_tree) <= max_length:
            if len(sub_tree) > best_size:
                best_tree = sub_tree
                best_size = len(sub_tree)

    # Fallback: root-only subtree if nothing else is valid
    if best_tree is None:
        best_tree = _extract_subtree(individual, 0)
    return best_tree

########################################################################################################################

# ---------------------------------------------
# 枚举 Vehicle × Arc 在当前state的优先级
# ---------------------------------------------
def vehicle_arc_prior_CARP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng):

    depot = instance.deposito
    result = []

    for vehicle in vehicles:
        for arc in remaining_edges:
            key = (vehicle, arc)

            # 只对被选中的车辆重新计算
            if vehicle in dirty_vehicles or key not in priority_cache:
                # -------------------------------
                # 构建 State
                # -------------------------------
                state = State.__new__(State)
                state.od = od
                state.fraction_unserved_tasks = len(remaining_edges) * len(instance.seedEdges)
                state.fraction_unasigned_tasks = (len(remaining_edges)  - 1) * len(instance.seedEdges)

                state.vehicle = vehicle
                state.arc = arc
                state.cost_from_here = od[vehicle.current_position][arc.start_vertex]
                state.cost_from_arc_depot = od[arc.end_vertex][depot]
                state.cost_from_depot_arc = od[depot][arc.start_vertex]
                state.cost_from_depot_location = od[depot][vehicle.current_position]
                state.demand = arc.demanda
                state.deadheading_cost = od[arc.start_vertex][arc.end_vertex]
                state.fullness = vehicle.capacity
                state.demand_left = vehicle.remain_capacity
                state.serving_cost = arc.coste
                state.random_value = rng.random()

                # CFR1 / remaing_query
                min_dist_v2v = float('inf')
                for v in vehicles:
                    if v is not vehicle:
                        dist = od[v.current_position][vehicle.current_position]
                        if dist < min_dist_v2v: min_dist_v2v = dist
                state.cost_from_otherRoutes_task = min_dist_v2v if min_dist_v2v != float('inf') else 1.0
                state.remaing_query = vehicle.remain_capacity

                # arc_lookup 可以用 instance 预计算表
                state.dem1 = 1.0
                state.cost_from_candidate_others = 1.0
                others = [a for a in remaining_edges if a is not state.arc]
                if others:
                    min_dis = float('inf')
                    min_ctt = float('inf')
                    for a in others:
                        # -------- DEM1 --------
                        dis = state.od[a.end_vertex][state.arc.start_vertex]
                        if dis < min_dis:
                            min_dis = dis
                            state.dem1 = a.demanda
                        # -------- CTT1 --------
                        ctt = state.od[state.arc.end_vertex][a.start_vertex]
                        if ctt < min_ctt:
                            min_ctt = ctt
                            state.cost_from_candidate_others = ctt

                # 评估
                terminalStateCARP.current_state = state
                val = toolbox.evaluate(individual)
                # 存入缓存
                priority_cache[key] = val
            else:
                # 直接复用缓存
                val = priority_cache[key]

            result.append((val, vehicle, arc))

    return result

def vehicle_arc_prior_CPP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng):

    depot = instance.deposito
    result = []

    for vehicle in vehicles:
        for arc in remaining_edges:
            key = (vehicle, arc)

            # 只对被选中的车辆重新计算
            if vehicle in dirty_vehicles or key not in priority_cache:
                # -------------------------------
                # 构建 State
                # -------------------------------
                state = State()

                state.od = od
                state.fraction_unserved_tasks = len(remaining_edges) * len(instance.seedEdges)
                state.fraction_unasigned_tasks = (len(remaining_edges)  - 1) * len(instance.seedEdges)

                state.vehicle = vehicle
                state.arc = arc
                state.cost_from_here = od[vehicle.current_position][arc.start_vertex]
                state.cost_from_arc_depot = od[arc.end_vertex][depot]
                state.cost_from_depot_arc = od[depot][arc.start_vertex]
                state.cost_from_depot_location = od[depot][vehicle.current_position]
                # state.demand = arc.demanda
                state.deadheading_cost = od[arc.start_vertex][arc.end_vertex]
                # state.fullness = vehicle.capacity
                # state.demand_left = vehicle.remain_capacity
                state.serving_cost = arc.coste
                state.random_value = rng.random()


                # CFR1 / remaing_query
                min_dist_v2v = float('inf')
                for v in vehicles:
                    if v is not vehicle:
                        dist = od[v.current_position][vehicle.current_position]
                        if dist < min_dist_v2v: min_dist_v2v = dist
                state.cost_from_otherRoutes_task = min_dist_v2v if min_dist_v2v != float('inf') else 1.0
                # state.remaing_query = vehicle.remain_capacity

                # arc_lookup 可以用 instance 预计算表
                # state.dem1 = 1.0
                state.cost_from_candidate_others = 1.0
                others = [a for a in remaining_edges if a is not state.arc]
                if others:
                    min_dis = float('inf')
                    min_ctt = float('inf')
                    for a in others:
                        # # -------- DEM1 --------
                        # dis = state.od[a.end_vertex][state.arc.start_vertex]
                        # if dis < min_dis:
                        #     min_dis = dis
                        #     state.dem1 = a.demanda
                        # -------- CTT1 --------
                        ctt = state.od[state.arc.end_vertex][a.start_vertex]
                        if ctt < min_ctt:
                            min_ctt = ctt
                            state.cost_from_candidate_others = ctt

                # 评估
                terminalStateCARP.current_state = state

                val = toolbox.evaluate(individual)
                # 存入缓存
                priority_cache[key] = val
            else:
                # 直接复用缓存
                val = priority_cache[key]

            result.append((val, vehicle, arc))

    return result

def vehicle_arc_prior_RPP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng):

    depot = instance.deposito
    result = []

    for vehicle in vehicles:
        for arc in remaining_edges:
            key = (vehicle, arc)

            # 只对被选中的车辆重新计算
            if vehicle in dirty_vehicles or key not in priority_cache:
                # -------------------------------
                # 构建 State
                # -------------------------------
                state = State()

                state.od = od
                state.fraction_unserved_tasks = len(remaining_edges) * len(instance.seedEdges)
                state.fraction_unasigned_tasks = (len(remaining_edges)  - 1) * len(instance.seedEdges)

                state.vehicle = vehicle
                state.arc = arc
                state.cost_from_here = od[vehicle.current_position][arc.start_vertex]
                state.cost_from_arc_depot = od[arc.end_vertex][depot]
                state.cost_from_depot_arc = od[depot][arc.start_vertex]
                state.cost_from_depot_location = od[depot][vehicle.current_position]
                # state.demand = arc.demanda
                state.deadheading_cost = od[arc.start_vertex][arc.end_vertex]
                # state.fullness = vehicle.capacity
                # state.demand_left = vehicle.remain_capacity
                state.serving_cost = arc.coste
                state.random_value = rng.random()


                # CFR1 / remaing_query
                min_dist_v2v = float('inf')
                for v in vehicles:
                    if v is not vehicle:
                        dist = od[v.current_position][vehicle.current_position]
                        if dist < min_dist_v2v: min_dist_v2v = dist
                state.cost_from_otherRoutes_task = min_dist_v2v if min_dist_v2v != float('inf') else 1.0
                # state.remaing_query = vehicle.remain_capacity

                # arc_lookup 可以用 instance 预计算表
                # state.dem1 = 1.0
                state.cost_from_candidate_others = 1.0
                others = [a for a in remaining_edges if a is not state.arc]
                if others:
                    min_dis = float('inf')
                    min_ctt = float('inf')
                    for a in others:
                        # # -------- DEM1 --------
                        # dis = state.od[a.end_vertex][state.arc.start_vertex]
                        # if dis < min_dis:
                        #     min_dis = dis
                        #     state.dem1 = a.demanda
                        # -------- CTT1 --------
                        ctt = state.od[state.arc.end_vertex][a.start_vertex]
                        if ctt < min_ctt:
                            min_ctt = ctt
                            state.cost_from_candidate_others = ctt

                # 评估
                terminalStateCARP.current_state = state

                val = toolbox.evaluate(individual)
                # 存入缓存
                priority_cache[key] = val
            else:
                # 直接复用缓存
                val = priority_cache[key]

            result.append((val, vehicle, arc))

    return result



def vehicle_arc_prior(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng):

    if configure_parameters.problem == "CARP":
        result = vehicle_arc_prior_CARP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng)
    elif configure_parameters.problem == "CPP":
        result = vehicle_arc_prior_CPP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng)
    elif configure_parameters.problem == "RPP":
        result = vehicle_arc_prior_RPP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng)
    elif configure_parameters.problem == "URARP":
        # URARP uses CARP-style priority with range-aware state
        result = vehicle_arc_prior_CARP(vehicles, remaining_edges, od, individual, instance, priority_cache, dirty_vehicles, rng)

    return result


def individual_height_limit(individual, max_height):
    """
    确保返回值始终是 Individual 类型（而非 PrimitiveTree）
    如果 individual.height <= max_height，直接返回原 Individual
    否则：
        从靠近根的节点开始，找第一个 height <= max_height 的完整子树
        将该子树包装为 Individual 后返回
    """
    # 已经合法：直接返回原 Individual
    if individual.height <= max_height:
        return individual

    # 从根开始，依次尝试每个节点作为子树根
    for idx in range(len(individual)):
        subtree_slice = individual.searchSubtree(idx)
        # 1. 先创建 PrimitiveTree 子树
        subtree_tree = gp.PrimitiveTree(individual[subtree_slice])

        if subtree_tree.height <= max_height:
            # 2. 关键修复：将 PrimitiveTree 转换为 Individual（复用你定义的 Individual 类）
            # from deap import creator  # 确保导入 creator（已定义 Individual 类）
            subtree_ind = creator.IndividualMO(subtree_tree)

            # 可选：继承原个体的 fitness 属性（如果需要）
            if hasattr(individual, 'fitness'):
                subtree_ind.fitness = individual.fitness

            return subtree_ind

    # 极端情况：返回仅含根节点的 Individual
    # from deap import creator
    fallback_ind = creator.IndividualMO([individual[0]])
    if hasattr(individual, 'fitness'):
        fallback_ind.fitness = individual.fitness
    return fallback_ind


def constrain_individual(individual, max_height, max_length):
    """约束个体：若超过 max_height 或 max_length，先尝试找最大合法子树，
    若子树仍不满足（理论上不会发生），则随机生成新个体。

    Args:
        individual: 待约束的个体
        max_height: 最大树高
        max_length: 最大节点数

    Returns:
        满足约束的新个体
    """
    if individual.height <= max_height and len(individual) <= max_length:
        return individual

    # 1. 从根往下找最大合法子树
    best_sub = _find_best_valid_subtree(individual, max_height, max_length)

    # 2. 如果子树满足约束，包装为 IndividualMO 返回
    if best_sub.height <= max_height and len(best_sub) <= max_length:
        ind_cls = getattr(creator, "IndividualMO", creator.Individual)
        new_ind = ind_cls(best_sub)
        if hasattr(individual, 'fitness'):
            try:
                new_ind.fitness = individual.fitness
            except Exception:
                pass
        return new_ind

    # 3. 兜底：随机生成新个体（最多尝试 max_attempts_unique 次）
    for _ in range(configure_parameters.max_attempts_unique):
        new_ind = toolbox.individual()
        if new_ind.height <= max_height and len(new_ind) <= max_length:
            return new_ind

    # 极端情况：返回最后一次随机生成的个体
    return new_ind


##找到种群中的最优个体
def find_best_ind(pop):
    """Find the best individual from a multi-objective population.

    Returns the individual with the lowest Fitness1 (total cost) among
    those on the first non-dominated Pareto front.
    """
    if not pop:
        raise ValueError("Population is empty")

    # Check that fitness has been evaluated (multi-objective: .values)
    for ind in pop:
        if not hasattr(ind.fitness, "values") or len(ind.fitness.values) == 0:
            raise ValueError(f"Individual {ind} has not been evaluated")

    # Extract the first non-dominated front using DEAP's sortNondominated
    from deap import tools
    fronts = tools.sortNondominated(pop, len(pop))
    if fronts and fronts[0]:
        pareto_front = fronts[0]
    else:
        # Fallback: use entire population
        pareto_front = pop

    # Among Pareto-optimal individuals, pick the one with lowest Fitness1
    return min(pareto_front, key=lambda ind: ind.fitness.values[0])


##避免产生重复个体，若出现相同个体，则随机初始化一个
def remove_duplicate_and_refill(population, toolbox, max_attempts = configure_parameters.max_attempts_unique):
    """
    功能：
    - 检测种群中的重复个体（基于 GP 树结构）
    - 每种结构只保留一个
    - 其余重复个体用全新的随机个体替换（保证新个体不会重复）

    参数：
    - population: list，GP 个体列表
    - toolbox: DEAP toolbox（必须已注册 individual / population）
    - max_attempts: int，生成唯一个体的最大尝试次数，防止无限循环

    返回：
    - new_population: 去重并补齐后的新种群
    """

    seen = set()
    new_population = []

    for ind in population:
        ind_str = str(ind)

        if ind_str not in seen:
            seen.add(ind_str)
            new_population.append(ind)
        else:
            # 发现重复个体 → 用新个体替换
            attempt = 0
            while attempt < max_attempts:
                new_ind = toolbox.individual()
                new_ind_str = str(new_ind)

                if new_ind_str not in seen:
                    # 新个体唯一，加入种群
                    if hasattr(new_ind.fitness, "values"):
                        del new_ind.fitness.values
                    seen.add(new_ind_str)
                    new_population.append(new_ind)
                    break
                else:
                    attempt += 1

            if attempt == max_attempts:
                # 极端情况：达到最大尝试依旧无法生成新个体
                # 直接保留原个体（虽然重复）
                new_population.append(ind)

    return new_population


##计算种群个体的深度统计值
def pop_everage_height(pop):

    pop_size = len(pop)

    s, d = 0, 0
    ss, dd = -1, -1
    sss, ddd = 99999999, 99999999

    for i in range(pop_size):
        s = s + pop[i].height
        d = d + pop[i].fitness

        if dd < pop[i].fitness:
            dd = pop[i].fitness

        if ddd > pop[i].fitness:
            ddd = pop[i].fitness

        if ss < pop[i].height:
            ss = pop[i].height

        if sss > pop[i].height:
            sss = pop[i].height

    pop_fit = d / pop_size
    pop_height = s / pop_size

    return pop_height, ss, sss, pop_fit, dd, ddd



def check_best_ind_same(best_ind_pop, s):
    """
    检查 best_ind_pop 中指定切片内的个体是否全部相同
    :param best_ind_pop: 存储最优个体的列表
    :param s: 当前索引
    :return: True（全部相同）/False（存在不同）
    """
    # 1. 确定切片范围（避免索引越界）
    start_idx = max(0, s - configure_parameters.update_population_times)
    end_idx = s
    target_slice = best_ind_pop[start_idx:end_idx]

    # 2. 空切片直接返回 True（边界处理）
    if len(target_slice) < configure_parameters.update_population_times:
        # print("待观察")
        return False

    # 3. 提取个体的唯一标识（关键修复：用可哈希的特征代替个体本身）
    def get_ind_identifier(ind):
        """获取个体的唯一可哈希标识"""

        # 方案1：用个体的适应度值（如果适应度相同则认为个体相同，适合你的场景）
        # if hasattr(ind, 'fitness') and ind.fitness.values:
        #     return ind.fitness.values[0]  # 适应度值是浮点数，可哈希

        # 方案2：用个体的树结构字符串（更精准，适合判断树结构是否相同）
        return str(ind)  # PrimitiveTree 转字符串后可哈希

        # 方案3：自定义唯一标识（比如组合多个特征）
        # return (str(ind), ind.fitness.values[0] if ind.fitness.values else -inf)

    # 4. 提取所有个体的标识，放入集合判断是否唯一
    identifiers = [get_ind_identifier(ind) for ind in target_slice]
    is_all_same = len(set(identifiers)) == 1
    if is_all_same:
        print("最优个体总是不变，需要重新设置种群")
        return True
    else:
        print("最优个体在给定循环情况下出现变化，不需要重新设置种群")
        return False



