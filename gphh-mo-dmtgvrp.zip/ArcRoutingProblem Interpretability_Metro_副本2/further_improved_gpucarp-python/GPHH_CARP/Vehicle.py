class Vehicle:
    def __init__(self, vehicle_count, start_depot, capacity=None, max_running_mileage=None):
        self.vehicle_count = vehicle_count
        self.start_depot = start_depot
        self.end_depot = start_depot

        # Capacity mode (CPP / CARP)
        self.capacity = capacity if capacity is not None else float('inf')
        self.remain_capacity = self.capacity

        # Mileage mode (URARP)
        self.max_running_mileage = max_running_mileage if max_running_mileage is not None else float('inf')
        self.remaining_mileage = self.max_running_mileage

        self.is_alive = True

        self.path_nodes = [start_depot]
        self.total_cost = 0.0
        self.served_arcs = []
        self.current_position = self.path_nodes[-1]
        self.current_cost = self.total_cost
        self.passed_path = ""

    def add_move_path(self, path_nodes, cost):
        if len(path_nodes) > 1:
            self.path_nodes.extend(path_nodes[1:])
            self.total_cost += cost
            if self.max_running_mileage != float('inf'):
                self.remaining_mileage -= cost

    def add_service_arc(self, u, v, cost):
        self.path_nodes.append(v)
        self.total_cost += cost
        self.served_arcs.append((u, v))
        if self.max_running_mileage != float('inf'):
            self.remaining_mileage -= cost

    def finish_route(self, return_path, cost):
        if len(return_path) > 1:
            self.path_nodes.extend(return_path[1:])
            self.total_cost += cost
            if self.max_running_mileage != float('inf'):
                self.remaining_mileage -= cost
        self.end_depot = self.start_depot

    def recharge_at_facility(self):
        self.remaining_mileage = self.max_running_mileage

    def use_capacity(self, demand):
        self.remain_capacity -= demand

    def reset_capacity(self):
        self.remain_capacity = self.capacity

    def get_path_string(self):
        if len(self.path_nodes) <= 1:
            return str(self.start_depot)
        served = set(self.served_arcs)
        s = str(self.path_nodes[0])
        for i in range(len(self.path_nodes) - 1):
            u, v = self.path_nodes[i], self.path_nodes[i + 1]
            if (u, v) in served:
                s += f"={v}"
            else:
                s += f"-{v}"
        self.passed_path = s
        return s

    def __repr__(self):
        if self.max_running_mileage != float('inf'):
            status = "alive" if self.is_alive else "broken"
            return (
                f"Vehicle(remaining_mileage={self.remaining_mileage:.1f}, "
                f"total_cost={self.total_cost:.2f}, "
                f"status={status}, "
                f"path={self.get_path_string()})"
            )
        else:
            return (
                f"Vehicle(remain_capacity={self.remain_capacity}, "
                f"total_cost={self.total_cost:.2f}, "
                f"path={self.get_path_string()})"
            )
