import os
import time
import random
import statistics
import csv
from copy import deepcopy

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import toolboxRegister
import configure_parameters_rl as configure_parameters
import breeding
import evaluate
import utils
import Instance
import math
from deap import tools
from Instance import SeededSample


# ==============================================================================
# Q-Learning Reinforcement Learning Controller
# ==============================================================================

# Five environment selection strategies
ACTION_STRONG_F1  = 0
ACTION_NSGA2      = 1
ACTION_STRONG_F2  = 2
ACTION_STRONG_IGD = 3
ACTION_STRONG_AREA = 4

ACTION_NAMES = {
    ACTION_STRONG_F1:  "strong_F1",
    ACTION_NSGA2:      "standard_NSGA2",
    ACTION_STRONG_F2:  "strong_F2",
    ACTION_STRONG_IGD: "strong_IGD",
    ACTION_STRONG_AREA:  "strong_area",
}


class RLEvolutionController:
    """Q-learning controller for adaptive NSGA-II selection strategy.

    State = (avg_f1_nor, avg_f2_nor, igd, hv, gen_phase) — 5 dims, 3 bins each.
    Reward combines Pareto front HV improvement with IGD improvement.
    """

    def __init__(self):
        self.actions = [ACTION_STRONG_F1, ACTION_NSGA2, ACTION_STRONG_F2,
                        ACTION_STRONG_IGD, ACTION_STRONG_AREA]
        self.q_table = {}
        self.epsilon = configure_parameters.rl_epsilon
        self.lr = configure_parameters.rl_learning_rate
        self.gamma = configure_parameters.rl_gamma

        self.last_state = None
        self.last_action = None

    # --- Epsilon decay ---
    def get_epsilon(self, current_gen, total_gen):
        """Linear decay: epsilon starts at initial value, decays to 0.01."""
        min_eps = 0.01
        progress = current_gen / total_gen
        return max(min_eps, self.epsilon * (1 - progress))

    # --- State discretization (5 dimensions, including generation phase) ---
    def get_state_key(self, avg_f1_nor, avg_f2_nor, igd, hv, gen_phase):
        """Discretize population state into a Q-table key.

        Each dimension → 3 bins.  Total 3^5 = 243 states.
        For avg_f1, avg_f2, igd: lower is better.
        For hv: higher is better.
        gen_phase: 0=early, 1=mid, 2=late.
        """
        # avg_f1_bin: 2=good(low), 1=medium, 0=poor(high)
        f1_bin = (2 if avg_f1_nor < configure_parameters.rl_avgF1_nor_low else
                  0 if avg_f1_nor > configure_parameters.rl_avgF1_nor_high else 1)

        # avg_f2_bin: 2=good(low), 1=medium, 0=poor(high)
        f2_bin = (2 if avg_f2_nor < configure_parameters.rl_avgF2_nor_low else
                  0 if avg_f2_nor > configure_parameters.rl_avgF2_nor_high else 1)

        # igd_bin: 2=good(close to ideal), 1=medium, 0=poor(far)
        igd_bin = (2 if igd < configure_parameters.rl_igd_low else
                   0 if igd > configure_parameters.rl_igd_high else 1)

        # hv_bin: 2=good(high), 1=medium, 0=poor(low)
        hv_bin = (2 if hv > configure_parameters.rl_hv_high else
                  0 if hv < configure_parameters.rl_hv_low else 1)

        return (f1_bin, f2_bin, igd_bin, hv_bin, gen_phase)

    # --- Action selection (full candidate set + Q-learning with decaying epsilon) ---
    def select_action(self, state_key, current_gen, total_gen):
        candidates = self.actions  # All 5 actions always available
        if state_key not in self.q_table:
            self.q_table[state_key] = np.zeros(len(self.actions))

        if len(candidates) == 1:
            return candidates[0]

        epsilon = self.get_epsilon(current_gen, total_gen)
        if random.random() < epsilon:
            return random.choice(candidates)

        q_vals = self.q_table[state_key]
        best_q = max(q_vals[a] for a in candidates)
        best_candidates = [a for a in candidates if q_vals[a] == best_q]
        return random.choice(best_candidates)

    # --- Q-table update ---
    def update_q_table(self, s, a, r, s_next):
        if s not in self.q_table:
            self.q_table[s] = np.zeros(len(self.actions))
        if s_next not in self.q_table:
            self.q_table[s_next] = np.zeros(len(self.actions))
        best_next_q = max(self.q_table[s_next])
        self.q_table[s][a] += self.lr * (r + self.gamma * best_next_q - self.q_table[s][a])

    # --- Reward computation ---
    def compute_reward(self, pre_hv, pre_igd, next_hv, next_igd):
        """Compute reward from Pareto front quality changes.

        reward = 0.5 * HV_improve + 0.5 * IGD_improve
        Both measured as relative improvements.
        """
        hv_improve = (next_hv - pre_hv) / (pre_hv + 1e-9)
        igd_improve = (pre_igd - next_igd) / (pre_igd + 1e-9)
        return 0.5 * hv_improve + 0.5 * igd_improve


# ==============================================================================
# RL-guided environment selection
# ==============================================================================

def _build_offspring_instances(instance, gen):
    """Build a separate set of instances for offspring evaluation.

    For generation s, offspring is evaluated on instances with seeds
    starting at evaluation_seed + (gen + 1 + configure_parameters.gen) * seed_gap_rotation.
    This is offset by one full run from pop instances so they never overlap.
    """
    start_seed = configure_parameters.evaluation_seed + (gen + 1 + configure_parameters.gen) * configure_parameters.seed_gap_rotation
    seeds = [start_seed + i * configure_parameters.seed_gap_instance
             for i in range(configure_parameters.training_sample_num)]
    return [SeededSample(instance, s) for s in seeds]


def _normalize(value, v_min, v_max):
    """Min-max normalize to [0, 1]. Clamp out-of-range values."""
    if v_max == v_min:
        return 0.5
    norm = (value - v_min) / (v_max - v_min)
    return max(0.0, min(1.0, norm))


def _population_normalize(population):
    """Min-max normalize using current population bounds.

    F1_nor(ind) = (F1(ind) - min_F1(pop)) / (max_F1(pop) - min_F1(pop))
    F2_nor(ind) = (F2(ind) - min_F2(pop)) / (max_F2(pop) - min_F2(pop))

    Returns a list of (F1_nor, F2_nor) tuples aligned with population order.
    """
    f1_vals = [ind.fitness.values[0] for ind in population]
    f2_vals = [ind.fitness.values[1] for ind in population]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)

    nor_vals = []
    for f1, f2 in zip(f1_vals, f2_vals):
        n1 = _normalize(f1, min_f1, max_f1)
        n2 = _normalize(f2, min_f2, max_f2)
        nor_vals.append((n1, n2))
    return nor_vals


def _assign_crowding_dist_normalized(individuals):
    """Assign crowding distance using population-level normalized objective values.

    Computes normalized values for the full population first, then assigns
    crowding distance based on those normalized values.
    """
    if len(individuals) == 0:
        return
    nobj = 2
    nor_vals = _population_normalize(individuals)
    indexed = [(nf, idx) for idx, nf in enumerate(nor_vals)]

    distances = [0.0] * len(individuals)

    for obj_i in range(nobj):
        indexed.sort(key=lambda elem: elem[0][obj_i])
        distances[indexed[0][1]] = float("inf")
        distances[indexed[-1][1]] = float("inf")
        denom = nobj * (indexed[-1][0][obj_i] - indexed[0][0][obj_i])
        if denom == 0:
            continue
        for prev_idx, cur_idx, next_idx in zip(
                range(len(indexed) - 2), range(1, len(indexed) - 1), range(2, len(indexed))):
            prev_val = indexed[prev_idx][0][obj_i]
            cur_orig_idx = indexed[cur_idx][1]
            next_val = indexed[next_idx][0][obj_i]
            distances[cur_orig_idx] += (next_val - prev_val) / denom

    for i, dist in enumerate(distances):
        individuals[i].fitness.crowding_dist = dist


def _select_nsga2_pure(combined, n_pop):
    """Pure NSGA-II: non-dominated sort + crowding distance, no extreme reserve."""
    if len(combined) <= n_pop:
        return list(combined)
    fronts = tools.sortNondominated(combined, len(combined))
    selected = []
    for front in fronts:
        if len(selected) + len(front) <= n_pop:
            selected.extend(front)
        else:
            _assign_crowding_dist_normalized(front)
            front_sorted = sorted(front, key=lambda ind: ind.fitness.crowding_dist, reverse=True)
            selected.extend(front_sorted[:n_pop - len(selected)])
            break
    return selected


def _get_first_n_fronts(population, n):
    """Return the first n non-dominated fronts as a list of lists."""
    fronts = tools.sortNondominated(population, len(population))
    return [list(fronts[i]) for i in range(min(n, len(fronts))) if fronts[i]]


def _euclidean_dist(nor_vals):
    """sqrt(F1_nor^2 + F2_nor^2) for each individual."""
    return [(v[0] ** 2 + v[1] ** 2) ** 0.5 for v in nor_vals]


def _hypervolume_2d(nor_vals):
    """Compute hypervolume for 2-objective minimization with reference point (1, 1).

    Returns the total area of non-overlapping rectangles dominated by the
    Pareto points and bounded by (1, 1). Returns 0.0 if no points.
    """
    pts = sorted(set(nor_vals))
    pts = [(f1, f2) for f1, f2 in pts if f1 < 1.0 and f2 < 1.0]
    if not pts:
        return 0.0

    pts.sort(key=lambda x: x[0])

    hv = 0.0
    next_f1 = 1.0
    for i in range(len(pts) - 1, -1, -1):
        f1, f2 = pts[i]
        width = next_f1 - f1
        height = 1.0 - f2
        hv += width * height
        next_f1 = f1

    return hv


def _fill_by_igd(candidates, nor_vals_map, n_select):
    """Select top n_select by sqrt(F1_nor^2+F2_nor^2) ascending.

    nor_vals_map: dict mapping id(ind) -> (F1_nor, F2_nor).
    """
    if not candidates:
        return []
    paired = []
    for ind in candidates:
        nv = nor_vals_map.get(id(ind), (0.5, 0.5))
        d = (nv[0] ** 2 + nv[1] ** 2) ** 0.5
        paired.append((ind, d))
    paired.sort(key=lambda x: x[1])
    return [ind for ind, _ in paired[:n_select]]


def _fill_by_area(candidates, nor_vals_map, n_select):
    """Select top n_select by (1-F1_nor)*(1-F2_nor) descending.

    nor_vals_map: dict mapping id(ind) -> (F1_nor, F2_nor).
    """
    if not candidates:
        return []
    paired = []
    for ind in candidates:
        nv = nor_vals_map.get(id(ind), (0.5, 0.5))
        a = (1.0 - nv[0]) * (1.0 - nv[1])
        paired.append((ind, a))
    paired.sort(key=lambda x: x[1], reverse=True)
    return [ind for ind, _ in paired[:n_select]]


def _pareto_metrics(pareto, population):
    """Compute (pop_avg_f1_nor, pop_avg_f2_nor, pareto_avg_f1_nor, pareto_avg_f2_nor, igd, hv).

    pop avg: mean over the ENTIRE population (used for state space).
    pareto avg: mean over the non-dominated set (used for display).
    igd / hv: computed only on the Pareto front.
    Normalization bounds use the entire population min/max.
    """
    if not population:
        return (0.5, 0.5, 0.5, 0.5, 0.5, 0.5)

    # Compute population normalization bounds
    f1_vals = [ind.fitness.values[0] for ind in population]
    f2_vals = [ind.fitness.values[1] for ind in population]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)

    # Pop avg: mean over ENTIRE population
    pop_nor_vals = []
    for ind in population:
        n1 = _normalize(ind.fitness.values[0], min_f1, max_f1)
        n2 = _normalize(ind.fitness.values[1], min_f2, max_f2)
        pop_nor_vals.append((n1, n2))
    pop_avg_f1 = _mean([v[0] for v in pop_nor_vals])
    pop_avg_f2 = _mean([v[1] for v in pop_nor_vals])

    # Pareto avg + IGD / HV: computed only on Pareto front
    if not pareto:
        return (pop_avg_f1, pop_avg_f2, 0.5, 0.5, 0.5, 0.5)

    pareto_nor_vals = []
    for ind in pareto:
        n1 = _normalize(ind.fitness.values[0], min_f1, max_f1)
        n2 = _normalize(ind.fitness.values[1], min_f2, max_f2)
        pareto_nor_vals.append((n1, n2))
    p_avg_f1 = _mean([v[0] for v in pareto_nor_vals])
    p_avg_f2 = _mean([v[1] for v in pareto_nor_vals])
    igd = _mean(_euclidean_dist(pareto_nor_vals))
    hv = _hypervolume_2d(pareto_nor_vals)
    return (pop_avg_f1, pop_avg_f2, p_avg_f1, p_avg_f2, igd, hv)


def _select_rl_guided(combined, n_pop, action, toolbox_ref, ref_ind):
    """Apply the selected environment selection strategy.

    Returns (selected_population, breakdown_dict).
    breakdown maps stage names to counts of individuals selected at each stage.
    For NSGA2 action, breakdown is empty.
    """
    pareto_fronts = _get_first_n_fronts(combined, configure_parameters.rl_pareto_fronts_num)
    reserve_n = min(configure_parameters.rl_reserve_count, n_pop)

    # Build population normalization map for the combined population
    nor_map = _build_nor_map(combined)

    # ---- strong_F1 ----
    if action == ACTION_STRONG_F1:
        reserved_ids = set()
        result = []
        breakdown = {}

        # S1: reserve top rl_reserve_count by F2 ascending
        s1_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[1])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s1_count += 1
        breakdown["S1_extreme_F2"] = s1_count

        # S2: reserve first three Pareto fronts
        s2_count = 0
        for ind in sum(pareto_fronts, []):
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s2_count += 1
        breakdown["S2_pareto_fronts"] = s2_count

        n_rem = n_pop - len(result)
        if n_rem > 0:
            remainder = [ind for ind in combined if id(ind) not in reserved_ids]
            if len(remainder) <= n_rem:
                result.extend(remainder)
                breakdown["S3_remainder_all"] = len(remainder)
            else:
                s3 = n_rem * 2 // 3
                s4 = n_rem // 6
                s5 = n_rem - s3 - s4

                # S3: by F1 ascending
                by_f1 = sorted(remainder, key=lambda ind: ind.fitness.values[0])
                r3 = by_f1[:s3]; result.extend(r3); r3_ids = {id(i) for i in r3}
                breakdown["S3_F1"] = len(r3)

                # S4: by IGD ascending
                c4 = [i for i in remainder if id(i) not in r3_ids]
                r4 = _fill_by_igd(c4, nor_map, s4); result.extend(r4); r4_ids = {id(i) for i in r4}
                breakdown["S4_IGD"] = len(r4)

                # S5: by HV product descending
                c5 = [i for i in remainder if id(i) not in r3_ids and id(i) not in r4_ids]
                r5 = _fill_by_area(c5, nor_map, s5); result.extend(r5)
                breakdown["S5_area"] = len(r5)
        return result, breakdown

    # ---- strong_F2 ----
    elif action == ACTION_STRONG_F2:
        reserved_ids = set()
        result = []
        breakdown = {}

        # S1: reserve top rl_reserve_count by F1 ascending
        s1_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[0])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s1_count += 1
        breakdown["S1_extreme_F1"] = s1_count

        # S2: reserve first three Pareto fronts
        s2_count = 0
        for ind in sum(pareto_fronts, []):
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s2_count += 1
        breakdown["S2_pareto_fronts"] = s2_count

        n_rem = n_pop - len(result)
        if n_rem > 0:
            remainder = [ind for ind in combined if id(ind) not in reserved_ids]
            if len(remainder) <= n_rem:
                result.extend(remainder)
                breakdown["S3_remainder_all"] = len(remainder)
            else:
                s3 = n_rem * 2 // 3
                s4 = n_rem // 6
                s5 = n_rem - s3 - s4

                # S3: by F2 ascending
                by_f2 = sorted(remainder, key=lambda ind: ind.fitness.values[1])
                r3 = by_f2[:s3]; result.extend(r3); r3_ids = {id(i) for i in r3}
                breakdown["S3_F2"] = len(r3)

                # S4: by IGD ascending
                c4 = [i for i in remainder if id(i) not in r3_ids]
                r4 = _fill_by_igd(c4, nor_map, s4); result.extend(r4); r4_ids = {id(i) for i in r4}
                breakdown["S4_IGD"] = len(r4)

                # S5: by HV product descending
                c5 = [i for i in remainder if id(i) not in r3_ids and id(i) not in r4_ids]
                r5 = _fill_by_area(c5, nor_map, s5); result.extend(r5)
                breakdown["S5_area"] = len(r5)
        return result, breakdown

    # ---- standard_NSGA2 ----
    elif action == ACTION_NSGA2:
        reserved_ids = set()
        result = []
        breakdown = {}

        # S1: reserve top rl_reserve_count by F1 ascending
        s1_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[0])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s1_count += 1
        breakdown["S1_extreme_F1"] = s1_count

        # S2: reserve top rl_reserve_count by F2 ascending
        s2_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[1])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s2_count += 1
        breakdown["S2_extreme_F2"] = s2_count

        # S3: reserve top rl_reserve_count by Area descending: (1-F1_nor)*(1-F2_nor)
        s3_count = 0
        remainder_s3 = [ind for ind in combined if id(ind) not in reserved_ids]
        by_area = sorted(remainder_s3, key=lambda ind: (1.0 - nor_map.get(id(ind), (0.5, 0.5))[0]) * (1.0 - nor_map.get(id(ind), (0.5, 0.5))[1]), reverse=True)
        for ind in by_area[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s3_count += 1
        breakdown["S3_area"] = s3_count

        # S4: reserve top rl_reserve_count by Dis ascending: sqrt(F1_nor^2 + F2_nor^2)
        s4_count = 0
        remainder_s4 = [ind for ind in combined if id(ind) not in reserved_ids]
        by_dis = sorted(remainder_s4, key=lambda ind: (nor_map.get(id(ind), (0.5, 0.5))[0] ** 2 + nor_map.get(id(ind), (0.5, 0.5))[1] ** 2) ** 0.5)
        for ind in by_dis[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s4_count += 1
        breakdown["S4_dis"] = s4_count

        # S5: fill remaining by NSGA-II non-dominated sort + crowding distance
        remainder = [ind for ind in combined if id(ind) not in reserved_ids]
        n_rem = n_pop - len(result)
        s5_count = 0
        if n_rem > 0 and remainder:
            s5_selected = _select_nsga2_pure(remainder, n_rem)
            s5_count = len(s5_selected)
            result.extend(s5_selected)
        breakdown["S5_nsga2"] = s5_count

        return result, breakdown

    # ---- strong_IGD ----
    elif action == ACTION_STRONG_IGD:
        reserved_ids = set()
        result = []
        breakdown = {}

        # S1: reserve top rl_reserve_count by F1 ascending
        s1_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[0])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s1_count += 1
        breakdown["S1_extreme_F1"] = s1_count

        # S2: reserve top rl_reserve_count by F2 ascending
        s2_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[1])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s2_count += 1
        breakdown["S2_extreme_F2"] = s2_count

        # S3: reserve first three Pareto fronts
        s3_count = 0
        for ind in sum(pareto_fronts, []):
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s3_count += 1
        breakdown["S3_pareto_fronts"] = s3_count

        n_rem = n_pop - len(result)
        if n_rem > 0:
            remainder = [ind for ind in combined if id(ind) not in reserved_ids]
            if len(remainder) <= n_rem:
                result.extend(remainder)
                breakdown["S4_remainder_all"] = len(remainder)
            else:
                s4 = n_rem * 2 // 3
                s5 = n_rem - s4

                # S4: by IGD ascending
                r4 = _fill_by_igd(remainder, nor_map, s4); result.extend(r4)
                r4_ids = {id(i) for i in r4}
                breakdown["S4_IGD"] = len(r4)

                # S5: by HV product descending
                c5 = [i for i in remainder if id(i) not in r4_ids]
                r5 = _fill_by_area(c5, nor_map, s5); result.extend(r5)
                breakdown["S5_area"] = len(r5)
        return result, breakdown

    # ---- strong_area ----
    elif action == ACTION_STRONG_AREA:
        reserved_ids = set()
        result = []
        breakdown = {}

        # S1: reserve top rl_reserve_count by F1 ascending
        s1_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[0])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s1_count += 1
        breakdown["S1_extreme_F1"] = s1_count

        # S2: reserve top rl_reserve_count by F2 ascending
        s2_count = 0
        for ind in sorted(combined, key=lambda ind: ind.fitness.values[1])[:reserve_n]:
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s2_count += 1
        breakdown["S2_extreme_F2"] = s2_count

        # S3: reserve first three Pareto fronts
        s3_count = 0
        for ind in sum(pareto_fronts, []):
            if id(ind) not in reserved_ids:
                result.append(ind); reserved_ids.add(id(ind)); s3_count += 1
        breakdown["S3_pareto_fronts"] = s3_count

        n_rem = n_pop - len(result)
        if n_rem > 0:
            remainder = [ind for ind in combined if id(ind) not in reserved_ids]
            if len(remainder) <= n_rem:
                result.extend(remainder)
                breakdown["S4_remainder_all"] = len(remainder)
            else:
                s4 = n_rem * 2 // 3
                s5 = n_rem - s4

                # S4: by area descending
                r4 = _fill_by_area(remainder, nor_map, s4); result.extend(r4)
                r4_ids = {id(i) for i in r4}
                breakdown["S4_area"] = len(r4)

                # S5: by IGD ascending
                c5 = [i for i in remainder if id(i) not in r4_ids]
                r5 = _fill_by_igd(c5, nor_map, s5); result.extend(r5)
                breakdown["S5_IGD"] = len(r5)
        return result, breakdown


def _build_nor_map(population):
    """Build dict: id(ind) -> (F1_nor, F2_nor) using population min-max normalization."""
    f1_vals = [ind.fitness.values[0] for ind in population]
    f2_vals = [ind.fitness.values[1] for ind in population]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)
    nor_map = {}
    for ind in population:
        n1 = _normalize(ind.fitness.values[0], min_f1, max_f1)
        n2 = _normalize(ind.fitness.values[1], min_f2, max_f2)
        nor_map[id(ind)] = (n1, n2)
    return nor_map


def _print_selection_breakdown(breakdown, action_name):
    """Print how many individuals were selected by each stage."""
    if not breakdown:
        return
    total = sum(breakdown.values())
    parts = ", ".join(f"{k}: {v}" for k, v in breakdown.items())
    print(f"  Selection breakdown [{action_name}]: {parts} | total: {total}")


def _plot_population_nor(pop_parent, pop_offspring, pop_combined, pop_selected, action_name, gen_id, plot_dir):
    """Plot population distribution in normalized objective space.

    Top-left:     parent population (before crossover/mutation)
    Top-right:    offspring population (after crossover/mutation)
    Bottom-left:  combined (parent + offspring) population
    Bottom-right: selected population (after RL-guided selection & evaluation)
    Saves one PNG per generation to *plot_dir*.
    """
    all_f1 = ([ind.fitness.values[0] for ind in pop_parent]
              + [ind.fitness.values[0] for ind in pop_offspring]
              + [ind.fitness.values[0] for ind in pop_combined]
              + [ind.fitness.values[0] for ind in pop_selected])
    all_f2 = ([ind.fitness.values[1] for ind in pop_parent]
              + [ind.fitness.values[1] for ind in pop_offspring]
              + [ind.fitness.values[1] for ind in pop_combined]
              + [ind.fitness.values[1] for ind in pop_selected])
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_parent = _raw_vals(pop_parent)
    xy_offspring = _raw_vals(pop_offspring)
    xy_combined = _raw_vals(pop_combined)
    xy_selected = _raw_vals(pop_selected)

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_parent], [v[1] for v in xy_parent],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Parent population  (n={len(pop_parent)})")

    ax_tr.scatter([v[0] for v in xy_offspring], [v[1] for v in xy_offspring],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Offspring population  (n={len(pop_offspring)})")

    ax_bl.scatter([v[0] for v in xy_combined], [v[1] for v in xy_combined],
                  s=8, alpha=0.6, edgecolors="none", color="tab:green")
    ax_bl.set_title(f"Combined population  (n={len(pop_combined)})")

    ax_br.scatter([v[0] for v in xy_selected], [v[1] for v in xy_selected],
                  s=8, alpha=0.6, edgecolors="none", color="tab:red")
    ax_br.set_title(f"New parent population  (n={len(pop_selected)})")

    fig.suptitle(f"Generation {gen_id} — RL action: {action_name}", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_train_test_comparison(pop_train, pop_test, gen_id, plot_dir):
    """Plot population distribution on training vs test sets (4-subplot figure).

    Top-left:     full population on training instances
    Top-right:    full population on test instances
    Bottom-left:  Pareto front (non-dominated) on training instances
    Bottom-right: Pareto front on test instances
    """
    pareto_train = _get_pareto_front(pop_train)
    pareto_test = _get_pareto_front(pop_test)

    all_pops = [pop_train, pop_test, pareto_train, pareto_test]
    all_f1 = [ind.fitness.values[0] for pop in all_pops for ind in pop]
    all_f2 = [ind.fitness.values[1] for pop in all_pops for ind in pop]
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_train = _raw_vals(pop_train)
    xy_test = _raw_vals(pop_test)
    xy_pareto_train = _raw_vals(pareto_train)
    xy_pareto_test = _raw_vals(pareto_test)

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_train], [v[1] for v in xy_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Full population — Train  (n={len(pop_train)})")

    ax_tr.scatter([v[0] for v in xy_test], [v[1] for v in xy_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Full population — Test  (n={len(pop_test)})")

    ax_bl.scatter([v[0] for v in xy_pareto_train], [v[1] for v in xy_pareto_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_bl.set_title(f"Pareto front — Train  (n={len(pareto_train)})")

    ax_br.scatter([v[0] for v in xy_pareto_test], [v[1] for v in xy_pareto_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_br.set_title(f"Pareto front — Test  (n={len(pareto_test)})")

    fig.suptitle(f"Generation {gen_id} — Train vs Test — RL", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"train_vs_test_gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_population_test(pop_tested, plot_dir, filename="test_distribution.png"):
    """Plot population distribution in normalized objective space after testing.

    Single scatter plot showing all individuals evaluated on test instances.
    """
    f1_vals = [ind.fitness.values[0] for ind in pop_tested]
    f2_vals = [ind.fitness.values[1] for ind in pop_tested]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)

    xy_vals = [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop_tested]

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter([v[0] for v in xy_vals], [v[1] for v in xy_vals],
               s=8, alpha=0.6, edgecolors="none", color="tab:purple")
    ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
    ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
    ax.set_xlabel("F1")
    ax.set_ylabel("F2")
    ax.set_title(f"Test population  (n={len(pop_tested)})")
    fig.suptitle("Population on test set", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, filename), dpi=150, bbox_inches="tight")
    plt.close(fig)


# ==============================================================================
# Statistics helpers
# ==============================================================================

def _mean(values):
    if not values:
        return 0.0
    return statistics.fmean(values)


def _std(values):
    if len(values) <= 1:
        return 0.0
    mean = statistics.fmean(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


def _program_size(individual):
    return len(individual)


def _unique_terminal_num(individual):
    terminal_set = set()
    for node in individual:
        node_name = getattr(node, "name", None)
        node_arity = getattr(node, "arity", None)
        if node_name is not None and node_arity == 0:
            terminal_set.add(node_name)
    return len(terminal_set)


def _write_stat_title(file_path):
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(
            "Gen,BestFit1,BestFit2,BestFit1Mean,BestFit1Std,BestFit2Mean,BestFit2Std,"
            "ProgSizeMean,ProgSizeStd,PopSize,ParetoFrontSize,"
            "PreAvgF1,PreAvgF2,NextAvgF1,NextAvgF2,RLAction,RLReward\n"
        )


def _append_stat(file_path, gen_id, population, best_ind, pareto_front_size,
                 action_name, reward_val, pre_f1, pre_f2,
                 next_f1, next_f2, reward):
    prog_size_list = [_program_size(ind) for ind in population]
    fit1_list = [ind.fitness.values[0] for ind in population]
    fit2_list = [ind.fitness.values[1] for ind in population]

    best_fit1 = best_ind.fitness.values[0]
    best_fit2 = best_ind.fitness.values[1]

    with open(file_path, "a", encoding="utf-8") as file:
        file.write(
            f"{gen_id},{best_fit1},{best_fit2},{_mean(fit1_list)},{_std(fit1_list)},"
            f"{_mean(fit2_list)},{_std(fit2_list)},{_mean(prog_size_list)},{_std(prog_size_list)},"
            f"{len(population)},{pareto_front_size},"
            f"{pre_f1:.4f},{pre_f2:.4f},{next_f1:.4f},{next_f2:.4f},"
            f"{action_name},{reward:.4f}\n"
        )


def _append_best_rule(file_path, gen_id, individual, action_name, reward_val):
    with open(file_path, "a", encoding="utf-8") as file:
        file.write(f"Generation {gen_id}\n")
        file.write(f"Fitness1 (total cost): {individual.fitness.values[0]}\n")
        file.write(f"Fitness2 (mileage diff): {individual.fitness.values[1]}\n")
        file.write(f"RL Action: {action_name}, Reward: {reward_val:.4f}\n")
        file.write(f"Rule: {individual}\n\n")


def _get_pareto_front(population):
    """Return the first non-dominated front of the population."""
    fronts = tools.sortNondominated(population, len(population))
    if fronts and fronts[0]:
        return fronts[0]
    return population


def main(SEED, PROBLEM, PATH):

    if SEED is None:
        seed = configure_parameters.seed
    else:
        seed = SEED

    if PROBLEM is None:
        problem_name = configure_parameters.problem
    else:
        problem_name = PROBLEM

    if PATH is None:
        instance_path = configure_parameters.data_path
    else:
        instance_path = PATH

    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)

    instance_name = os.path.splitext(os.path.basename(instance_path))[0]

    # ========== 1. Load instance ==========
    instance = Instance.Instance(instance_path, 0)

    # ========== 2. Toolbox init ==========
    toolbox = toolboxRegister.toolbox_init(seed)

    # Seed RNG once at the start; do NOT re-seed per generation
    random.seed(seed)

    # ========== 3. Population init ==========
    # Reset RNG immediately before population generation so both programs
    # produce the exact same initial population independently.
    random.seed(seed + 42)
    pop = toolbox.population(n=configure_parameters.population_size)
    pop = utils.remove_duplicate_and_refill(pop, toolbox, configure_parameters.max_attempts_unique)

    # ========== 4. Initial fitness evaluation ==========
    if configure_parameters.parallel_eval:
        pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
    else:
        pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

    # ========== 5. Output files init ==========
    out_stat_path = os.path.join(
        current_dir, "train", f"{instance_name}-{seed}-{problem_name}-RL.out.stat"
    )
    stat_csv_path = os.path.join(
        current_dir, "train", f"{instance_name}-{seed}-{problem_name}-RL.stat.csv"
    )
    test_dir = os.path.join(current_dir)
    os.makedirs(test_dir, exist_ok=True)

    open(out_stat_path, "w", encoding="utf-8").close()
    _write_stat_title(stat_csv_path)

    # ========== 8. RL agent init (skip if pure NSGA-II) ==========
    if configure_parameters.pure_nsga2:
        rl_agent = None
        print(f"\n========== Pure NSGA-II Evolution ==========")
    else:
        rl_agent = RLEvolutionController()
        print(f"\n========== RL-NSGA-II Evolution (Balanced F1/F2) ==========")

    # ========== 9. RL-NSGA-II evolution ==========
    best_ind_pop = []
    global_best_ind = None

    last_reward = 0.0
    prev_state = None  # Will be set after first generation's evolution

    for s in range(configure_parameters.gen):
        start_time_gen = time.time()

        # === Step 1: pop_parent is the evaluated population from previous iteration ===
        # --- Record PRE-evolution metrics (from pop_parent) ---
        pre_pareto = _get_pareto_front(pop_parent)
        (pre_pop_f1, pre_pop_f2, pre_par_f1, pre_par_f2, pre_igd, pre_hv) = _pareto_metrics(pre_pareto, pop_parent)

        # --- Compute generation phase (0=early, 1=mid, 2=late) ---
        if configure_parameters.gen > 1:
            phase_ratio = s / (configure_parameters.gen - 1)
            gen_phase = 0 if phase_ratio < 0.33 else 1 if phase_ratio < 0.67 else 2
        else:
            gen_phase = 2

        # --- Action selection ---
        if configure_parameters.pure_nsga2:
            action = ACTION_NSGA2
        elif prev_state is None:
            action = random.choice(rl_agent.actions)
        else:
            action = rl_agent.select_action(prev_state, s, configure_parameters.gen)

        # Force standard_NSGA2 for the last generation to ensure
        # Pareto front quality and diversity.
        if s >= configure_parameters.gen - 1:
            action = ACTION_NSGA2
        action_name = ACTION_NAMES[action]

        # --- Pre-evolution stats ---
        print()
        print(f"================ Train Process in The {s}-th Generation "
              f"[Action: {action_name}] =================")
        print(f"  Pareto front size: {len(pre_pareto)}")
        print(f"  Pareto F1/F2 mean (nor): {pre_par_f1:.4f} / {pre_par_f2:.4f}")
        print(f"  Pop F1/F2 mean (nor): {pre_pop_f1:.4f} / {pre_pop_f2:.4f}")
        phase_name = ["early", "mid", "late"][gen_phase]
        print(f"  State: avgF1={pre_pop_f1:.3f} avgF2={pre_pop_f2:.3f} "
              f"igd={pre_igd:.3f} hv={pre_hv:.3f} phase={phase_name}")

        # Get best individual
        best_ind = min(pre_pareto, key=lambda ind: ind.fitness.values[0])
        best_ind_copy = deepcopy(best_ind)
        best_ind_pop.append(best_ind_copy)

        # Update global best-so-far (by Fitness1)
        if global_best_ind is None:
            global_best_ind = deepcopy(best_ind_copy)
        else:
            if best_ind.fitness.values[0] < global_best_ind.fitness.values[0]:
                global_best_ind = deepcopy(best_ind_copy)

        # Print vehicle routes for best-so-far individual
        if configure_parameters.printVehiclesRoute:
            evaluate.print_vehicle_routes(global_best_ind, instance)

        # Save original parent reference for plotting (before reassignment)
        orig_parent = pop_parent

        # === Step 2: pop_parent produces offspring ===
        offspring = breeding.breeding_population(
            pop_parent, toolbox,
            target_size=configure_parameters.population_size,
        )

        # === Step 3: Evaluate offspring → pop_offspring (on alternate instances) ===
        offspring_instances = _build_offspring_instances(instance, s)
        if configure_parameters.parallel_eval:
            pop_offspring = evaluate.evaluate_population_parallel(offspring, offspring_instances)
        else:
            pop_offspring = evaluate.evaluate_population(offspring, offspring_instances)

        # === Step 4: pop_parent + pop_offspring → pop_combined ===
        pop_combined = pop_parent + pop_offspring

        # === Step 5: Select from pop_combined → pop_selected ===
        pop_selected, breakdown = _select_rl_guided(
            pop_combined, configure_parameters.population_size, action, toolbox, None
        )
        if not configure_parameters.pure_nsga2:
            _print_selection_breakdown(breakdown, action_name)

        # Build new individuals from selected so clearing fitness doesn't affect orig_parent/pop_offspring
        pop = [type(ind)(ind) for ind in pop_selected]

        # === Step 6: Clear fitness on pop so they are in unevaluated state ===
        for ind in pop:
            del ind.fitness.values

        # === Step 7: Rotate eval model before re-evaluation ===
        if configure_parameters.rotate_eval_model:
            instance.resetSeedInstance(seed, configure_parameters, s + 1)

        # === Step 8: Evaluate pop → pop_parent (for next iteration) ===
        if configure_parameters.parallel_eval:
            pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
        else:
            pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

        # Plot population distribution in normalized objective space
        _plot_population_nor(
            orig_parent, pop_offspring, pop_combined, pop_parent, action_name, s,
            os.path.join(current_dir, "train", "plots_nor")
        )

        # --- Compute reward using Pareto front quality changes (from re-evaluated population) ---
        next_pareto = _get_pareto_front(pop_parent)
        (next_pop_f1, next_pop_f2, next_par_f1, next_par_f2, next_igd, next_hv) = _pareto_metrics(next_pareto, pop_parent)
        if configure_parameters.pure_nsga2:
            reward = 0.0
        else:
            reward = rl_agent.compute_reward(pre_hv, pre_igd, next_hv, next_igd)
        last_reward = reward

        print(f"  Reward: {reward:.4f}")

        _append_best_rule(out_stat_path, s, best_ind, action_name, last_reward)
        _append_stat(stat_csv_path, s, pop_parent, best_ind, len(pre_pareto),
                     action_name, last_reward, pre_pop_f1, pre_pop_f2,
                     next_pop_f1, next_pop_f2, reward)

        # --- Update Q-table (skip if pure NSGA-II) ---
        if not configure_parameters.pure_nsga2:
            next_state = rl_agent.get_state_key(next_pop_f1, next_pop_f2, next_igd, next_hv, gen_phase)
            if prev_state is not None:
                rl_agent.update_q_table(prev_state, action, reward, next_state)
            prev_state = next_state

        end_time_gen = time.time()

    # ========== 10. Q-table summary (skip if pure NSGA-II) ==========
    if not configure_parameters.pure_nsga2 and rl_agent is not None:
        print("\n========== Q-Table Summary ==========")
        for state_key, q_vals in sorted(rl_agent.q_table.items()):
            best_a = int(np.argmax(q_vals))
            print(f"  State {state_key}: best_action={ACTION_NAMES[best_a]}, q={q_vals.tolist()}")

    # ========== 11. Testing phase ==========
    print("\n================ Testing Process =================\n")

    final_pareto = _get_pareto_front(pop_parent)
    print(f"Final training Pareto front: {len(final_pareto)} solutions\n")

    # Save full pop_parent fitness (before testing overwrites them)
    pop_train = deepcopy(pop_parent)

    test_sample_list = instance.build_test_samples()
    print('============================================')
    print(test_sample_list)
    print('============================================')
    test_csv_path = os.path.join(
        test_dir, "test", f"{instance_name}-{seed}-{problem_name}-RL.stat.csv"
    )

    # Test the final training Pareto front on test instances
    test_individuals = deepcopy(final_pareto)
    for ind in test_individuals:
        evaluate.evaluate_batch(ind, test_sample_list)
        print(f"  {ind}")
        print(f"    Test Fitness1 (total cost): {ind.fitness.values[0]:.2f}")
        print(f"    Test Fitness2 (mileage diff): {ind.fitness.values[1]:.2f}")

    # Evaluate full pop_parent on test set as well
    test_pop_full = deepcopy(pop_parent)
    for ind in test_pop_full:
        evaluate.evaluate_batch(ind, test_sample_list)

    # Plot train vs test comparison (4-subplot figure)
    _plot_train_test_comparison(
        pop_train, test_pop_full, configure_parameters.gen,
        os.path.join(current_dir, "train", "plots_nor")
    )

    # Find non-dominated front based on TEST fitness values (from full population)
    test_fronts = tools.sortNondominated(test_pop_full, len(test_pop_full))
    test_pareto = test_fronts[0] if test_fronts else test_pop_full
    test_pareto_sorted = sorted(test_pareto, key=lambda ind: ind.fitness.values[0])

    # Write test results CSV (full population evaluated on test set)
    with open(test_csv_path, "w", encoding="utf-8") as file:
        file.write("Index,TestFit1,TestFit2,ProgramSize,UniqueTerminals,Individual\n")
        for idx, ind in enumerate(test_pop_full):
            file.write(
                f"{idx},{ind.fitness.values[0]},{ind.fitness.values[1]},"
                f"{_program_size(ind)},{_unique_terminal_num(ind)},\"{str(ind)}\"\n"
            )

    # Save test-based Pareto front to pareto_fronts/
    pareto_dir = os.path.join(current_dir, "pareto_fronts")
    os.makedirs(pareto_dir, exist_ok=True)
    pareto_csv_path = os.path.join(
        pareto_dir, f"{instance_name}-{seed}-RLNSGA2-pareto.csv"
    )
    with open(pareto_csv_path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Individual", "F1", "F2"])
        for ind in test_pareto_sorted:
            writer.writerow([str(ind), ind.fitness.values[0], ind.fitness.values[1]])
    print(f"\nTest Pareto front ({len(test_pareto_sorted)} solutions) saved to: {pareto_csv_path}")

    print(f"Experiment out.stat saved to: {out_stat_path}")
    print(f"Experiment stat.csv saved to: {stat_csv_path}")
    print(f"Experiment test csv saved to: {test_csv_path}")


if __name__ == "__main__":
    a = time.time()

    SEED = None
    PROBLEM = None
    PATH = None
    main(SEED, PROBLEM, PATH)

    print('total time', time.time() - a)
