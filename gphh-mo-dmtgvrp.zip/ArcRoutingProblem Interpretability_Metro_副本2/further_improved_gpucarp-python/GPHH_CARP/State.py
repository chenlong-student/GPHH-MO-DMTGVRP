class State:
    __slots__ = (
        'vehicle',
        'arc',
        'od',
        'cost_from_here',
        'cost_from_arc_depot',
        'cost_from_otherRoutes_task',
        'cost_from_candidate_others',
        'cost_from_depot_arc',
        'cost_from_depot_location',
        'demand',
        'dem1',
        'deadheading_cost',
        'fullness',
        'fraction_unserved_tasks',
        'fraction_unasigned_tasks',
        'demand_left',
        'remaing_query',
        'serving_cost',
        'random_value'
    )

    def __init__(self):
        # 所有 slot 统一初始化
        for name in self.__slots__:
            setattr(self, name, None)
