import os
import re
import math
import heapq
import random
from copy import deepcopy

import configure_parameters
from Arc import Arc
from Vehicle import Vehicle


class Instance:
    def __init__(self, file_path, gen, seed = configure_parameters.seed):
        # 1. 加载文本
        instance_text = self.load_instance_text(file_path)

        # 2. 解析逻辑 (确保返回 dict)
        if configure_parameters.problem == "CPP":
            instance = self.parse_instance_CPP(instance_text)
        elif configure_parameters.problem == "RPP":
            instance = self.parse_instance_RPP(instance_text)
        elif configure_parameters.problem == "kRPP":
            instance = self.parse_instance_kRPP(instance_text)
        elif configure_parameters.problem == "CARP":
            instance = self.parse_instance_CARP(instance_text)
        elif configure_parameters.problem == "URARP":
            instance = self.parse_instance_URARP(instance_text)

        self.instance = instance.copy()

        # 3. 基础属性赋值
        self.vertices = instance["vertices"]
        self.vehiculos = instance["vehiculos"]
        self.capacidad = instance["capacidad"]
        self.deposito = instance["deposito"]

        # 4. 边和车辆
        self.originalEdges = instance["edges"]

        # URARP-specific attributes
        if configure_parameters.problem == "URARP":
            self.rings = instance.get("rings", {})
            self.bridges = instance.get("bridges", {})
            self.facility_nodes = instance.get("facility_nodes", set())
            self.access_nodes = instance.get("access_nodes", set())
            self.max_running_mileage = instance.get("max_running_mileage", float('inf'))
            self.inter_ring_transfer_cost = instance.get("inter_ring_transfer_cost", 0)

            self.vehicles = [
                Vehicle(
                    vehicle_count=self.vehiculos,
                    start_depot=self.deposito,
                    max_running_mileage=self.max_running_mileage,
                )
                for _ in range(self.vehiculos)
            ]
        else:
            self.rings = {}
            self.bridges = {}
            self.facility_nodes = set()
            self.access_nodes = set()
            self.max_running_mileage = float('inf')
            self.inter_ring_transfer_cost = 0
            self.vehicles = [
                Vehicle(vehicle_count=self.vehiculos, capacity=self.capacidad, start_depot=self.deposito)
                for _ in range(self.vehiculos)
            ]
        self.positions = [self.deposito] * self.vehiculos

        # 5. 区分弧段 (URARP: all ring arcs are required)
        if configure_parameters.problem == "URARP":
            self.original_requiredArc = list(self.originalEdges)
            self.original_noRequiredArc = []
        else:
            self.original_requiredArc = [arc for arc in self.originalEdges if arc.demanda > 0]
            self.original_noRequiredArc = [arc for arc in self.originalEdges if arc.demanda == 0]

        # 6. 计算路网
        self.get_originalGraph()

        # 7. 计算随机种子样本
        self.seedInstance(seed, configure_parameters, gen)


    def load_instance_text(self, file_path: str) -> str:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()


    def parse_instance_CPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_CARP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = int(re.search(r"CAPACIDAD\s*:\s*(\d+)", text).group(1))
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)\s*demanda\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste, demanda = map(int, m.groups())
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_RPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_kRPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_URARP(self, text: str):
        """
        Parse URARP (Uncertain Rich Arc Routing Problem) instance format.

        Expected fields:
            VERTICES_TOTAL : <num>
            VEHICULOS : <num>
            DEPOSITO : <node>          (single depot / start node)
            MAX_RUNNING_MILEAGE : <num>
            FACILITY : <node1>, <node2>, ...
            NODOS_ACCESO : <node1>, <node2>, ...
            INTER_RING_TRANSFER_COST : <num>
            RING <id> : (u,v) coste <c>, (v,w) coste <c>, ...
        """
        vertices = int(re.search(r"VERTICES_TOTAL\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))
        max_running_mileage = int(re.search(r"MAX_RUNNING_MILEAGE\s*:\s*(\d+)", text).group(1))

        # Facilities (depot/recharge nodes)
        facility_match = re.search(r"FACILITY\s*:\s*([\d,\s]+?)(?=\n)", text)
        facility_nodes = [int(x.strip()) for x in facility_match.group(1).split(",") if x.strip()]

        # Access nodes (entry points to rings)
        acceso_match = re.search(r"NODOS_ACCESO\s*:\s*([\d,\s]+?)(?=\n)", text)
        access_nodes = [int(x.strip()) for x in acceso_match.group(1).split(",") if x.strip()]

        # Inter-ring transfer cost (default 0)
        transfer_match = re.search(r"INTER_RING_TRANSFER_COST\s*:\s*(\d+)", text)
        inter_ring_transfer_cost = int(transfer_match.group(1)) if transfer_match else 0

        # Parse RINGs
        edges = []
        rings = {}  # ring_id -> list of Arc objects in sequence
        ring_pattern = re.compile(r"RING\s+(\d+)\s*:\s*(.+?)(?=\n\s*RING|\n\s*$|$)", re.S)

        # Track unique edges to avoid duplicates when edges appear in multiple rings
        unique_edges = {}  # (u, v, cost) -> Arc object

        def _get_or_create_arc(u, v, demanda, coste, ring_id, seq, ring_total):
            key = (u, v, coste)
            if key in unique_edges:
                return unique_edges[key]
            arc = Arc(u, v, demanda, coste)
            arc.ring_id = ring_id
            arc.ring_sequence = seq
            arc.ring_total = ring_total
            unique_edges[key] = arc
            return arc

        for ring_match in ring_pattern.finditer(text):
            ring_id = int(ring_match.group(1))
            ring_body = ring_match.group(2)
            ring_arcs = []

            # Parse individual arcs in the ring
            arc_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            arc_list = list(arc_pattern.finditer(ring_body))

            for seq, m in enumerate(arc_list):
                u, v, coste = map(int, m.groups())
                demanda = 1.0  # ring arcs have unit demand (must be serviced)
                arc_fwd = _get_or_create_arc(u, v, demanda, coste, ring_id, seq, len(arc_list))
                arc_rev = _get_or_create_arc(v, u, demanda, coste, ring_id, seq, len(arc_list))

                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)

                ring_arcs.append(arc_fwd)

            rings[ring_id] = ring_arcs

        # Parse BRIDGEs (non-cycle edges from original CARP that can't form rings)
        bridges = {}
        bridge_pattern = re.compile(r"BRIDGE\s+(\d+)\s*:\s*\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
        for bridge_match in bridge_pattern.finditer(text):
            bridge_id = int(bridge_match.group(1))
            u, v, coste = int(bridge_match.group(2)), int(bridge_match.group(3)), int(bridge_match.group(4))
            demanda = 1.0  # bridge arcs are also required
            # Use same deduplication -- bridges may share edges with rings
            arc_fwd = _get_or_create_arc(u, v, demanda, coste, None, 0, 0)
            arc_rev = _get_or_create_arc(v, u, demanda, coste, None, 0, 0)
            arc_fwd.bridge_id = bridge_id
            arc_rev.bridge_id = bridge_id
            arc_fwd.set_reverse(arc_rev)
            arc_rev.set_reverse(arc_fwd)
            bridges[bridge_id] = (u, v, coste)

        # Collect unique edges into the edge list
        edges = list(unique_edges.values())

        return {
            "vertices": vertices,
            "vehiculos": vehiculos,
            "capacidad": math.inf,  # URARP uses range, not capacity
            "deposito": deposito,
            "edges": edges,
            "rings": rings,
            "bridges": bridges,
            "facility_nodes": set(facility_nodes),
            "access_nodes": set(access_nodes),
            "max_running_mileage": max_running_mileage,
            "inter_ring_transfer_cost": inter_ring_transfer_cost,
        }


    def dijkstra_with_path(self, start_node, vertices, adj):
        distances = [math.inf] * (vertices + 1)
        parents = [None] * (vertices + 1)
        distances[start_node] = 0
        pq = [(0, start_node)]
        while pq:
            curr_dist, u = heapq.heappop(pq)
            if curr_dist > distances[u]: continue
            for v, cost in adj[u]:
                if curr_dist + cost < distances[v]:
                    distances[v] = curr_dist + cost
                    parents[v] = u
                    heapq.heappush(pq, (distances[v], v))
        return distances, parents

    def get_originalGraph(self):
        size = self.vertices + 1
        self.originalGraph = [[math.inf] * size for _ in range(size)]
        self.originalGraphConnected = [[math.inf] * size for _ in range(size)]
        self.originalParentMatrix = [None] * size
        self.originalPathMatrix = [[[] for _ in range(size)] for _ in range(size)]

        adj = [[] for _ in range(size)]
        for arc in self.originalEdges:
            adj[arc.start_vertex].append((arc.end_vertex, arc.coste))
            self.originalGraph[arc.start_vertex][arc.end_vertex] = arc.coste

        for i in range(1, size):
            dist, parents = self.dijkstra_with_path(i, self.vertices, adj)
            self.originalGraphConnected[i] = dist
            self.originalParentMatrix[i] = parents
            for j in range(1, size):
                if dist[j] != math.inf:
                    path, curr = [], j
                    while curr is not None:
                        path.append(curr)
                        curr = parents[curr]
                    self.originalPathMatrix[i][j] = path[::-1]

    def seedInstance(self, seed, configure_parameters, gen):
        start_seed = configure_parameters.evaluation_seed + gen * configure_parameters.seed_gap_rotation
        seedlist = [start_seed + sample_index * configure_parameters.seed_gap_instance for sample_index in range(configure_parameters.training_sample_num)]

        self.instanceSeedList = []
        for seedSample in seedlist:
            sample = SeededSample(self, seedSample)
            self.instanceSeedList.append(sample)

    def resetSeedInstance(self, seed, configure_parameters, gen):
        self.seedInstance(seed, configure_parameters, gen)

    def get_normalization_bounds(self, f1_min_mul=0.8, f1_max_mul=3.6, f2_min_mul=0.0, f2_max_mul=2.0):
        """Compute normalization bounds from arc costs in the .dat file.

        F1 and F2 are normalized via (F - F_min) / (F_max - F_min).

        Args:
            f1_min_mul: Multiplier for total_coste to get F1_min.
            f1_max_mul: Multiplier for total_coste to get F1_max.
            f2_min_mul: Multiplier for total_coste to get F2_min.
            f2_max_mul: Multiplier for total_coste to get F2_max.

        Returns:
            (f1_min, f1_max, f2_min, f2_max).
        """
        total_coste = sum(arc.coste for arc in self.originalEdges)
        return (total_coste * f1_min_mul, total_coste * f1_max_mul,
                total_coste * f2_min_mul, total_coste * f2_max_mul)

    def build_test_samples(self, start_seed = None, sample_num = None):
        if start_seed is None:
            start_seed = configure_parameters.testing_seed

        if sample_num is None:
            sample_num = configure_parameters.testing_sample_num

        return [SeededSample(self, start_seed + i * configure_parameters.seed_gap_instance) for i in range(sample_num)]


class SeededSample:
    """包装类，确保 instanceSeedList[i] 拥有所有 Instance 属性和变量名"""

    def __init__(self, parent, seed):
        self.seed = seed
        self.vertices = parent.vertices
        self.vehiculos = parent.vehiculos
        self.capacidad = parent.capacidad
        self.deposito = parent.deposito
        self.originalGraphConnected = parent.originalGraphConnected

        # URARP-specific attributes
        self.rings = parent.rings
        self.bridges = parent.bridges
        self.facility_nodes = set(parent.facility_nodes)
        self.access_nodes = set(parent.access_nodes)
        self.max_running_mileage = parent.max_running_mileage
        self.inter_ring_transfer_cost = parent.inter_ring_transfer_cost

        # Key: deep copy vehicles so each sample has independent state
        self.vehicles = deepcopy(parent.vehicles)
        self.positions = list(parent.positions)

        rng = random.Random(seed)

        self.seedEdges = [deepcopy(arc) for arc in parent.originalEdges]
        for arc in self.seedEdges:
            arc.randomize(rng = rng)

        self.seed_requiredArc = list(self.seedEdges) if configure_parameters.problem == "URARP" else [arc for arc in self.seedEdges if arc.demanda > 0]
        self.seed_noRequiredArc = [] if configure_parameters.problem == "URARP" else [arc for arc in self.seedEdges if arc.demanda == 0]

        # Rebuild reverse links for deep-copied arcs
        self._rebuild_reverse_links()

        # 重新计算该种子下的路网 (保持原名)
        size = self.vertices + 1
        self.seedGraph = [[math.inf] * size for _ in range(size)]
        self.seedGraphConnected = [[math.inf] * size for _ in range(size)]
        self.seedPathMatrix = [[[] for _ in range(size)] for _ in range(size)]

        adj = [[] for _ in range(size)]
        for arc in self.seedEdges:
            adj[arc.start_vertex].append((arc.end_vertex, arc.coste))
            self.seedGraph[arc.start_vertex][arc.end_vertex] = arc.coste

        for i in range(1, size):
            dist, parents = parent.dijkstra_with_path(i, self.vertices, adj)
            self.seedGraphConnected[i] = dist
            for j in range(1, size):
                if dist[j] != math.inf:
                    path, curr = [], j
                    while curr is not None:
                        path.append(curr)
                        curr = parents[curr]
                    self.seedPathMatrix[i][j] = path[::-1]

    def _rebuild_reverse_links(self):
        """Rebuild reverse arc links for deep-copied arcs in seeded sample."""
        arc_key_map = {}
        for arc in self.seedEdges:
            key = (arc.start_vertex, arc.end_vertex, arc.demanda_original, arc.coste_original)
            arc_key_map[key] = arc

        for arc in self.seedEdges:
            rev_key = (arc.end_vertex, arc.start_vertex, arc.demanda_original, arc.coste_original)
            rev_arc = arc_key_map.get(rev_key)
            if rev_arc:
                arc.reverse_arc = rev_arc
