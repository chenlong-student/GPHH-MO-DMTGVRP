from terminalSetARP import terminal_set
from functionSet import function_set

def psetHold():
    pset = terminal_set()
    f_pset = function_set(pset)
    return f_pset