"""Plot and compare two Pareto fronts from CSV files.

Usage:
    python plot_pareto_compare.py

Reads the two Pareto CSVs from pareto_fronts/ directory by default.
Outputs:
    - Terminal: comparison statistics
    - pareto_fronts/*.png: scatter plot image
"""

import os
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

seed_inx = 0
# ============================================================
# Config -- change these to compare different files
# ============================================================
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARETO_DIR = os.path.join(CURRENT_DIR, "pareto_fronts")

FILE_STANDARD = os.path.join(PARETO_DIR, f"gdb1-{seed_inx}-NSGA2-pareto.csv")
FILE_RL = os.path.join(PARETO_DIR, f"gdb1-{seed_inx}-RLNSGA2-pareto.csv")

LABEL_STANDARD = "Standard NSGA-II"
LABEL_RL = "RL-NSGA-II"
COLOR_STANDARD = "#1f77b4"
COLOR_RL = "#ff7f0e"


def load_pareto(csv_path):
    """Return list of (F1, F2) tuples."""
    points = []
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or len(row) < 3:
                continue
            try:
                f1 = float(row[1])
                f2 = float(row[2])
                points.append((f1, f2))
            except ValueError:
                continue
    return points


def compute_stats(points, label):
    if not points:
        print(f"  {label}: no data")
        return {}

    f1s = [p[0] for p in points]
    f2s = [p[1] for p in points]
    avg_f1 = sum(f1s) / len(f1s)
    avg_f2 = sum(f2s) / len(f2s)
    min_f1 = min(f1s)
    min_f2 = min(f2s)
    max_f1 = max(f1s)
    max_f2 = max(f2s)

    # Average Euclidean distance to ideal point (minF1, minF2)
    avg_dist = sum(((p[0] - min_f1) ** 2 + (p[1] - min_f2) ** 2) ** 0.5 for p in points) / len(points)

    # Bounding-box area: (maxF1 - minF1) * (maxF2 - minF2)
    area = (max_f1 - min_f1) * (max_f2 - min_f2)

    print(f"\n  {label}")
    print(f"    Pareto size:         {len(points)}")
    print(f"    Avg F1:              {avg_f1:.2f}")
    print(f"    Avg F2:              {avg_f2:.2f}")
    print(f"    Min F1:              {min_f1:.2f}")
    print(f"    Min F2:              {min_f2:.2f}")
    print(f"    Max F1:              {max_f1:.2f}")
    print(f"    Max F2:              {max_f2:.2f}")
    print(f"    Avg dist to ideal:   {avg_dist:.2f}")
    print(f"    Bounding-box area:   {area:.2f}")

    return {
        "size": len(points),
        "avg_f1": avg_f1,
        "avg_f2": avg_f2,
        "min_f1": min_f1,
        "min_f2": min_f2,
        "max_f1": max_f1,
        "max_f2": max_f2,
        "avg_dist": avg_dist,
        "area": area,
    }


def plot_pareto(std_pts, rl_pts, std_stats, rl_stats, out_path):
    fig, ax = plt.subplots(figsize=(8, 6))

    # Scatter points
    if std_pts:
        f1s, f2s = zip(*std_pts)
        ax.scatter(f1s, f2s, c=COLOR_STANDARD, marker="o", s=60,
                   label=LABEL_STANDARD, alpha=0.8, zorder=3)
    if rl_pts:
        f1s, f2s = zip(*rl_pts)
        ax.scatter(f1s, f2s, c=COLOR_RL, marker="x", s=60,
                   label=LABEL_RL, alpha=0.8, zorder=3, linewidths=1.5)

    # Ideal point marker
    ideal_f1 = min(std_stats["min_f1"], rl_stats["min_f1"])
    ideal_f2 = min(std_stats["min_f2"], rl_stats["min_f2"])
    ax.scatter([ideal_f1], [ideal_f2], c="red", marker="*", s=150,
               label="Ideal point", zorder=4, edgecolors="darkred")

    # Annotation box with stats
    lines = [
        f"{LABEL_STANDARD}:  avgF1={std_stats['avg_f1']:.1f}  avgF2={std_stats['avg_f2']:.1f}",
        f"  dist_ideal={std_stats['avg_dist']:.1f}  area={std_stats['area']:.1f}",
        f"{LABEL_RL}:  avgF1={rl_stats['avg_f1']:.1f}  avgF2={rl_stats['avg_f2']:.1f}",
        f"  dist_ideal={rl_stats['avg_dist']:.1f}  area={rl_stats['area']:.1f}",
    ]
    ax.text(0.02, 0.98, "\n".join(lines), transform=ax.transAxes,
            fontsize=9, va="top", family="monospace",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="white", alpha=0.85))

    ax.set_xlabel("F1 (total cost)", fontsize=12)
    ax.set_ylabel("F2 (mileage diff)", fontsize=12)
    ax.set_title("Pareto Front Comparison: Standard NSGA-II vs RL-NSGA-II", fontsize=13)
    ax.legend(loc="lower right", fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()
    print(f"\n  Plot saved to: {out_path}")


def main():
    print("Loading Pareto fronts...")

    std_pts = load_pareto(FILE_STANDARD)
    rl_pts = load_pareto(FILE_RL)

    print(f"\n  {LABEL_STANDARD}: {len(std_pts)} points  ({os.path.basename(FILE_STANDARD)})")
    print(f"  {LABEL_RL}: {len(rl_pts)} points  ({os.path.basename(FILE_RL)})")

    print("\n" + "=" * 60)
    print("  Pareto Front Statistics")
    print("=" * 60)

    std_stats = compute_stats(std_pts, LABEL_STANDARD)
    rl_stats = compute_stats(rl_pts, LABEL_RL)

    # Delta comparison
    if std_stats and rl_stats:
        print("\n" + "-" * 60)
        print("  Comparison (RL - Standard)")
        print("-" * 60)
        print(f"    Avg F1 delta:      {rl_stats['avg_f1'] - std_stats['avg_f1']:+.2f}")
        print(f"    Avg F2 delta:      {rl_stats['avg_f2'] - std_stats['avg_f2']:+.2f}")
        print(f"    Avg dist delta:    {rl_stats['avg_dist'] - std_stats['avg_dist']:+.2f}")
        print(f"    Area delta:        {rl_stats['area'] - std_stats['area']:+.2f}")

    out_path = os.path.join(PARETO_DIR, f"gdb1-{seed_inx}-URARP-compare.png")
    plot_pareto(std_pts, rl_pts, std_stats, rl_stats, out_path)


if __name__ == "__main__":

    main()
