"""Convert CARP instances to URARP format with 100% edge coverage.

For each CARP instance:
1. Find bridges using Tarjan's algorithm
2. Decompose non-bridge edges into simple cycles (rings) using BFS
3. Bridges are written as BRIDGE entries (parsed by Instance.py)
4. All original CARP edges are preserved (in rings or bridges)
"""
from collections import defaultdict, deque
import re
import os
import glob


def parse_carp(path):
    """Parse CARP .dat file. Returns (edges_dict, vertices, deposito, vehicles, capacidad)."""
    edges = {}
    vertices = 0
    deposito = 1
    vehicles = 5
    capacidad = 0
    with open(path) as f:
        text = f.read()
    m = re.search(r'VERTICES\s*:\s*(\d+)', text)
    vertices = int(m.group(1)) if m else 0
    m = re.search(r'VEHICULOS\s*:\s*(\d+)', text)
    vehicles = int(m.group(1)) if m else 5
    m = re.search(r'DEPOSITO\s*:\s*(\d+)', text)
    deposito = int(m.group(1)) if m else 1
    m = re.search(r'CAPACIDAD\s*:\s*(\d+)', text)
    capacidad = int(m.group(1)) if m else 0
    for mo in re.finditer(
        r'\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s+(\d+)\s*demanda\s+(\d+)', text
    ):
        u, v, c, d = int(mo.group(1)), int(mo.group(2)), int(mo.group(3)), int(mo.group(4))
        edges[(min(u, v), max(u, v))] = (c, d)
    return edges, vertices, deposito, vehicles, capacidad


def find_bridges(edge_set, all_vertices):
    """Tarjan's bridge-finding algorithm."""
    adj = defaultdict(list)
    for (u, v) in edge_set:
        adj[u].append(v)
        adj[v].append(u)
    visited = set()
    disc = {}
    low = {}
    bridges = set()
    timer = [0]
    parent_map = {}

    def dfs(u):
        visited.add(u)
        disc[u] = low[u] = timer[0]
        timer[0] += 1
        for v in adj[u]:
            if v == parent_map.get(u):
                continue
            if v not in visited:
                parent_map[v] = u
                dfs(v)
                low[u] = min(low[u], low[v])
                if low[v] > disc[u]:
                    bridges.add((min(u, v), max(u, v)))
            else:
                low[u] = min(low[u], disc[v])

    for v in sorted(all_vertices):
        if v not in visited:
            parent_map = {}
            dfs(v)
    return bridges


def find_cycle_through_edge(edge_set, u, v):
    """Find a simple cycle containing edge (u,v) using BFS, avoiding direct backtrack."""
    adj = defaultdict(list)
    for (a, b) in edge_set:
        if (a, b) != (u, v) and (a, b) != (v, u):
            adj[a].append(b)
            adj[b].append(a)

    queue = deque([(v, [v])])
    visited = {v}

    while queue:
        node, path = queue.popleft()
        for nb in sorted(adj[node]):
            if nb == u:
                cycle = [(u, v)]
                for i in range(len(path) - 1):
                    cycle.append((path[i], path[i + 1]))
                cycle.append((node, u))
                return cycle
            if nb not in visited:
                visited.add(nb)
                queue.append((nb, path + [nb]))
    return None


def cover_edges_with_cycles(edge_set):
    """Cover all non-bridge edges with cycles. Returns (bridges, uncovered, cycles)."""
    all_v = set()
    for (u, v) in edge_set:
        all_v.add(u)
        all_v.add(v)

    bridges = find_bridges(edge_set, all_v)
    non_bridge = edge_set - bridges

    cycles = []
    covered = set()

    for edge in sorted(non_bridge):
        if edge in covered:
            continue
        u, v = edge
        cycle = find_cycle_through_edge(edge_set, u, v)
        if cycle is None:
            continue
        for (a, b) in cycle:
            covered.add((min(a, b), max(a, b)))
        cycles.append(cycle)

    return bridges, non_bridge - covered, cycles


def find_facility_nodes(cycles, deposito):
    """Find nodes that belong to 2+ rings, plus the deposito."""
    node_ring_count = defaultdict(int)
    for cycle in cycles:
        ring_nodes = set()
        for a, b in cycle:
            ring_nodes.add(a)
            ring_nodes.add(b)
        for node in ring_nodes:
            node_ring_count[node] += 1

    facilities = {deposito}
    for node, count in node_ring_count.items():
        if count >= 2:
            facilities.add(node)
    return sorted(facilities)


def convert_carp_to_urarp(carp_path, urarp_path):
    """Convert a single CARP instance to URARP format. Returns stats dict."""
    edges, vertices, deposito, vehicles, capacidad = parse_carp(carp_path)
    edge_set = set(edges.keys())
    name = os.path.splitext(os.path.basename(carp_path))[0]

    bridges, uncovered, cycles = cover_edges_with_cycles(edge_set)

    covered_in_cycles = set()
    for cycle in cycles:
        for (a, b) in cycle:
            covered_in_cycles.add((min(a, b), max(a, b)))

    n_covered = len(covered_in_cycles) + len(bridges)
    n_total = len(edge_set)
    coverage = n_covered / n_total * 100 if n_total > 0 else 0

    facilities = find_facility_nodes(cycles, deposito)
    all_nodes = sorted(range(1, vertices + 1))

    # Max running mileage
    max_ring_cost = 0
    for cycle in cycles:
        cost = sum(edges[(min(a, b), max(a, b))][0] for a, b in cycle)
        if cost > max_ring_cost:
            max_ring_cost = cost
    max_mileage = max(int(max_ring_cost * 1.2 + 10), 50)

    transfer_cost = 3

    with open(urarp_path, 'w') as f:
        f.write(f"NOMBRE : {name}_urarp\n")
        f.write(
            f"COMENTARIO : {name} converted. "
            f"{len(cycles)} rings, {len(bridges)} bridges. "
            f"Coverage: {coverage:.1f}% ({n_covered}/{n_total}).\n"
        )
        f.write(f"VERTICES_TOTAL : {vertices}\n")
        f.write(f"VEHICULOS : {vehicles}\n")
        f.write(f"DEPOSITO : {deposito}\n")
        f.write(f"MAX_RUNNING_MILEAGE : {max_mileage}\n")
        f.write(f"FACILITY : {', '.join(str(x) for x in facilities)}\n")
        f.write(f"NODOS_ACCESO : {', '.join(str(x) for x in all_nodes)}\n")
        f.write(f"INTER_RING_TRANSFER_COST : {transfer_cost}\n")

        for i, cycle in enumerate(cycles):
            parts = []
            for a, b in cycle:
                c = edges[(min(a, b), max(a, b))][0]
                parts.append(f"({a}, {b}) coste {c}")
            f.write(f"RING {i + 1} : {', '.join(parts)}\n")

        for j, (u, v) in enumerate(sorted(bridges)):
            c = edges[(u, v)][0]
            f.write(f"BRIDGE {j + 1} : ({u}, {v}) coste {c}\n")

    return {
        'name': name,
        'total': n_total,
        'covered': n_covered,
        'rings': len(cycles),
        'bridges': len(bridges),
        'coverage': coverage,
        'facilities': len(facilities),
    }


def convert_all(base_dir=None):
    """Convert all CARP instances to URARP. Prints summary table."""
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    print(f"{'Name':<12} {'Subdir':<8} {'Total':>5} {'Covered':>7} "
          f"{'Rings':>5} {'Bridges':>7} {'Cov%':>6} {'Fac':>4}")
    print("-" * 60)

    for subdir in ['gdb', 'kshs', 'val', 'egl']:
        carp_dir = os.path.join(base_dir, f"data_CARP/{subdir}")
        urarp_dir = os.path.join(base_dir, f"data_URARP/{subdir}")
        os.makedirs(urarp_dir, exist_ok=True)

        for carp_path in sorted(glob.glob(os.path.join(carp_dir, "*.dat"))):
            name = os.path.splitext(os.path.basename(carp_path))[0]
            urarp_path = os.path.join(urarp_dir, f"{name}.dat")
            stats = convert_carp_to_urarp(carp_path, urarp_path)
            print(
                f"{stats['name']:<12} {subdir:<8} {stats['total']:>5} "
                f"{stats['covered']:>7} {stats['rings']:>5} "
                f"{stats['bridges']:>7} {stats['coverage']:>5.1f}% "
                f"{stats['facilities']:>4}"
            )


if __name__ == '__main__':
    convert_all()
