import os
import time
import random
import statistics
import csv
import math
from copy import deepcopy

import numpy as np
import hdbscan

import toolboxRegister
import configure_parameters_test as configure_parameters
import breeding
import evaluate
import utils
import Instance
import psetHoldCARP
from deap import tools
from deap import gp
from deap import creator
from Instance import SeededSample
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import breeding


def _build_offspring_instances(instance, gen):
    """Build a separate set of instances for offspring evaluation.

    For generation s, offspring is evaluated on instances with seeds
    starting at evaluation_seed + (gen + 1 + configure_parameters.gen) * seed_gap_rotation.
    This is offset by one full run from pop instances so they never overlap.
    """
    start_seed = configure_parameters.evaluation_seed + (gen + 1 + configure_parameters.gen) * configure_parameters.seed_gap_rotation
    seeds = [start_seed + i * configure_parameters.seed_gap_instance
             for i in range(configure_parameters.training_sample_num)]
    return [SeededSample(instance, s) for s in seeds]


# =========================================================================
# Elite & Sparse 选择策略 — 小波降噪 + PELT 变点聚类
# =========================================================================

def _non_dominated_sorting(population, n_fronts=None):
    """Perform non-dominated sorting on *population*.

    Returns a list of fronts (each front is a list of individuals).
    If *n_fronts* is given, only compute up to that many fronts.
    """
    fronts = tools.sortNondominated(population, len(population))
    if n_fronts is not None and n_fronts > 0:
        return fronts[:n_fronts] if n_fronts < len(fronts) else fronts
    return fronts


def _normalize_objectives(population):
    """Min-max normalize F1 and F2 of *population* to [0, 1].

    Returns (f1_norm, f2_norm) as two lists of same length as *population*.
    If all values are identical for an objective, returns 0.5 for all.
    """
    f1_vals = [ind.fitness.values[0] for ind in population]
    f2_vals = [ind.fitness.values[1] for ind in population]

    def _norm(vals):
        lo, hi = min(vals), max(vals)
        if hi == lo:
            return [0.5] * len(vals)
        return [(v - lo) / (hi - lo) for v in vals]

    return _norm(f1_vals), _norm(f2_vals)


def _average_distance_all(population, f1_norm, f2_norm):
    """For each individual, compute the average Euclidean distance to
    ALL other (M-1) individuals in normalized objective space.

    Returns (avg_distances, dist_matrix).
        avg_distances: list of average distances per individual.
        dist_matrix: (n, n) numpy array of pairwise distances.
    """
    n = len(population)
    coords = np.column_stack([f1_norm, f2_norm])
    # Full pairwise distance matrix
    dist_matrix = np.sqrt(
        (coords[:, None, 0] - coords[None, :, 0]) ** 2
        + (coords[:, None, 1] - coords[None, :, 1]) ** 2
    )
    # Average distance excluding self
    avg_distances = (dist_matrix.sum(axis=1) - np.diag(dist_matrix)) / (n - 1) if n > 1 else [0.0] * n

    return avg_distances.tolist(), dist_matrix


def _cluster_hdbscan(individuals, f1_norm, f2_norm, ave_dists):
    """Cluster individuals using HDBSCAN in normalized (F1, F2) space.

    Returns list of clusters, where each cluster is a list of
    (individual, aveDis) tuples.  Unclustered (noise) points are
    placed in a separate cluster.
    """
    if len(individuals) < 3:
        return [list(zip(individuals, ave_dists))]

    # Build feature matrix: normalized F1, F2
    coords = np.column_stack([f1_norm, f2_norm])

    # HDBSCAN parameters
    min_cluster_size = getattr(configure_parameters, 'hdbscan_min_cluster_size', 5)
    min_samples = getattr(configure_parameters, 'hdbscan_min_samples', None)
    metric = getattr(configure_parameters, 'hdbscan_metric', 'euclidean')

    try:
        clusterer = hdbscan.HDBSCAN(
            min_cluster_size=min_cluster_size,
            min_samples=min_samples,
            metric=metric,
            cluster_selection_epsilon=0.0,
        )
        labels = clusterer.fit_predict(coords)
    except Exception:
        # Fallback: treat all as one cluster
        return [list(zip(individuals, ave_dists))]

    # Group by label; noise points (label == -1) go into their own cluster
    clusters_dict = {}
    noise = []
    for ind, label, ave_dis in zip(individuals, labels, ave_dists):
        if label == -1:
            noise.append((ind, ave_dis))
        else:
            clusters_dict.setdefault(label, []).append((ind, ave_dis))

    clusters = list(clusters_dict.values())
    if noise:
        clusters.append(noise)

    # If HDBSCAN found no clusters (all noise), treat as single cluster
    if not clusters:
        return [list(zip(individuals, ave_dists))]

    return clusters


def _identify_elite_sparse(population):
    """Identify "Elite & Sparse" individuals via HDBSCAN clustering.

    Step 1: Non-dominated sorting, collect ranks 1..elite_max_rank
    Step 2: Normalize objectives, compute pairwise distances
    Step 3: HDBSCAN clustering in normalized (F1, F2) space

    Returns:
        (clusters, dist_matrix, candidate_pool)
        clusters: list of clusters, each cluster is a list of
                  (individual, aveDis) tuples.
        dist_matrix: (M, M) numpy array of pairwise distances in
                     normalized objective space (same order as candidate_pool).
        candidate_pool: list of individuals corresponding to dist_matrix rows.
    """
    # Step 1: non-dominated sorting
    fronts = _non_dominated_sorting(population,
                                    n_fronts=configure_parameters.elite_max_rank)
    candidate_pool = []
    for front in fronts:
        candidate_pool.extend(front)

    if len(candidate_pool) <= 1:
        clusters = [[(ind, 0.0) for ind in candidate_pool]]
        dist_matrix = np.zeros((1, 1)) if candidate_pool else np.zeros((0, 0))
        return clusters, dist_matrix, candidate_pool

    # Step 2: normalize objectives, compute distances
    f1_norm, f2_norm = _normalize_objectives(candidate_pool)
    avg_dists, dist_matrix = _average_distance_all(candidate_pool, f1_norm, f2_norm)

    # Step 3: HDBSCAN clustering in normalized (F1, F2) space
    clusters = _cluster_hdbscan(candidate_pool, f1_norm, f2_norm, avg_dists)

    return clusters, dist_matrix, candidate_pool


# =========================================================================
# RNG-isolated random helper
# =========================================================================

# A separate Random instance for Elite & Sparse decisions.
# Seeded once at module load so it never interferes with the main RNG flow.
_elite_rng = random.Random(getattr(configure_parameters, 'elite_sparse_rng_seed', 20260610))


def _select_from_clusters(clusters):
    """Select parent(s) from clusters per the new strategy.

    For mutation: pick 1 random cluster, return its max-aveDis individual.
    For crossover: pick 2 random clusters, return their max-aveDis individuals.

    Returns:
        For mutation: a single individual.
        For crossover: a tuple of two (possibly identical) individuals.
    """
    if not clusters:
        return None, None

    # Mutation: select 1 cluster
    cluster_idx = _elite_rng.randint(0, len(clusters) - 1)
    cluster = clusters[cluster_idx]
    # Find individual with max aveDis in this cluster
    p1 = max(cluster, key=lambda x: x[1])[0]
    return p1, None


def _cluster_non_dominated_front(cluster):
    """Extract the non-dominated (Pareto) front from a single cluster.

    Each cluster element is (individual, aveDis).  Returns a list of
    (individual, aveDis) tuples that form the first non-dominated front
    based on fitness values (F1, F2).
    """
    individuals = [item[0] for item in cluster]
    if len(individuals) <= 1:
        return cluster

    fronts = tools.sortNondominated(individuals, len(individuals))
    if not fronts or not fronts[0]:
        return cluster

    front_ids = {id(ind) for ind in fronts[0]}
    return [item for item in cluster if id(item[0]) in front_ids]


def _select_from_clusters_crossover(clusters, dist_matrix=None, candidate_pool=None):
    """Select two parents for crossover from clusters.

    Pick 2 random clusters (may be the same if only 1 cluster exists),
    extract the non-dominated front from each cluster, then find the
    pair of individuals (one from each front) that are closest in
    normalized objective space.

    If dist_matrix and candidate_pool are provided, uses the cached
    pairwise distances instead of recomputing them.
    """
    if not clusters:
        return None, None

    if len(clusters) >= 2:
        idx1, idx2 = _elite_rng.sample(range(len(clusters)), 2)
    else:
        idx1 = idx2 = 0

    # Step 1: extract non-dominated front from each cluster
    front1 = _cluster_non_dominated_front(clusters[idx1])
    front2 = _cluster_non_dominated_front(clusters[idx2])

    if not front1 or not front2:
        return None, None

    # Step 2: find closest pair between the two fronts
    if dist_matrix is not None and candidate_pool is not None:
        id_to_idx = {id(ind): i for i, ind in enumerate(candidate_pool)}
        best_dist = float("inf")
        best_p1 = front1[0][0]
        best_p2 = front2[0][0]

        for ind1, _ in front1:
            i = id_to_idx.get(id(ind1))
            if i is None:
                continue
            for ind2, _ in front2:
                j = id_to_idx.get(id(ind2))
                if j is None:
                    continue
                dist = dist_matrix[i, j]
                if dist < best_dist:
                    best_dist = dist
                    best_p1 = ind1
                    best_p2 = ind2
    else:
        # Fallback: recompute normalized distances
        all_inds = [ind for ind, _ in front1] + [ind for ind, _ in front2]
        f1_norm, f2_norm = _normalize_objectives(all_inds)
        norm_map = {id(ind): (fn1, fn2) for ind, fn1, fn2 in zip(all_inds, f1_norm, f2_norm)}

        best_dist = float("inf")
        best_p1 = front1[0][0]
        best_p2 = front2[0][0]

        for ind1, _ in front1:
            n1_1, n1_2 = norm_map[id(ind1)]
            for ind2, _ in front2:
                n2_1, n2_2 = norm_map[id(ind2)]
                dist = math.sqrt((n1_1 - n2_1) ** 2 + (n1_2 - n2_2) ** 2)
                if dist < best_dist:
                    best_dist = dist
                    best_p1 = ind1
                    best_p2 = ind2

    return best_p1, best_p2


def _tournament_selection(pool, k):
    """Tournament selection from a pool. Returns a single individual.

    Uses crowding distance if available (consistent with
    selTournamentDCD used in main_gphh_metro_nsga2.py), falls back to F1.
    """
    if not pool:
        return None
    if len(pool) == 1:
        return pool[0]
    k = min(k, len(pool))
    best = None
    for _ in range(k):
        cand = _elite_rng.choice(pool)
        best = _better_individual(best, cand)
    return best


def _better_individual(a, b):
    """Return the better of two individuals.

    If either has crowding distance, prefer larger crowding distance.
    Otherwise, prefer smaller F1.
    """
    if a is None:
        return b
    if b is None:
        return a

    a_cd = getattr(a.fitness, 'crowding_distance', None)
    b_cd = getattr(b.fitness, 'crowding_distance', None)

    if a_cd is not None and b_cd is not None:
        return a if a_cd >= b_cd else b

    # Fallback: smaller F1 is better
    return a if a.fitness.values[0] <= b.fitness.values[0] else b


def _tournament_selection_different(pool, k):
    """Tournament-select two DIFFERENT individuals from the pool."""
    if len(pool) < 2:
        return None, None
    p1 = _tournament_selection(pool, k)
    # Select p2 from individuals other than p1
    remaining = [ind for ind in pool if ind is not p1]
    if not remaining:
        return None, None
    p2 = _tournament_selection(remaining, k)
    return p1, p2




def _deduplicate_selected(population, toolbox, target_size, source_pop=None):
    """Remove individuals with identical (F1, F2) pairs, keep one per pair.
    Fill freed slots by crossing over parents drawn from the top-1/3 by F1
    and the top-1/3 by F2 of *source_pop*.

    Called on *pop_selected* (which still has fitness), BEFORE copying
    into the unevaluated *pop*.  Returns the deduplicated+filled population.
    """
    # --- Phase 1: Identify and remove duplicates (all individuals have fitness) ---
    seen = {}
    dup_indices = []
    for i, ind in enumerate(population):
        key = (ind.fitness.values[0], ind.fitness.values[1])
        if key in seen:
            dup_indices.append(i)
        else:
            seen[key] = i
    if not dup_indices:
        return population
    # Remove in reverse order so indices remain valid
    for i in reversed(dup_indices):
        population.pop(i)

    n_missing = target_size - len(population)
    if n_missing <= 0:
        return population

    # --- Phase 2: Build parent pool from top performers ---
    pool = source_pop if source_pop is not None else population
    by_f1 = sorted(pool, key=lambda ind: ind.fitness.values[0])
    by_f2 = sorted(pool, key=lambda ind: ind.fitness.values[1])
    top_n = max(1, int(len(by_f1) * configure_parameters.dedup_crossover_parent_ratio))
    # Use id() for dedup since DEAP individuals are unhashable
    pool_f1_ids = {id(ind) for ind in by_f1[:top_n]}
    pool_f2_ids = {id(ind) for ind in by_f2[:top_n]}
    parent_ids = pool_f1_ids | pool_f2_ids
    id_to_ind = {id(ind): ind for ind in pool}
    parent_pool = [id_to_ind[i] for i in parent_ids if i in id_to_ind]

    max_cross = configure_parameters.max_cross_depth

    # --- Phase 3: Fill empty slots via crossover (children have no fitness) ---
    children = []
    while len(children) < n_missing:
        if len(parent_pool) < 2:
            # Not enough parents — fall back to random
            children.extend(toolbox.population(n=n_missing - len(children)))
            break

        p1, p2 = _elite_rng.sample(parent_pool, 2)

        child1 = breeding._copy_individual_new(p1)
        child2 = breeding._copy_individual_new(p2)
        toolbox.mate(child1, child2)

        if breeding._tree_depth(child1) <= max_cross and breeding._tree_depth(child2) <= max_cross:
            children.append(child1)
            if len(children) < n_missing:
                children.append(child2)
        else:
            # Depth exceeded — clone a parent instead
            children.append(breeding._copy_individual(_elite_rng.choice(parent_pool)))

    population.extend(children[:n_missing])
    return population


def _filter_inferior_clusters(clusters, population):
    """Remove clusters whose average normalized F1 > 0.5 or average normalized F2 > 0.5.

    Returns a new list of clusters (each still a list of (ind, aveDis) tuples).
    """
    if not clusters:
        return []

    f1_norm, f2_norm = _normalize_objectives(population)
    ind_to_norm = {}
    for ind, fn1, fn2 in zip(population, f1_norm, f2_norm):
        ind_to_norm[id(ind)] = (fn1, fn2)

    filtered = []
    for cluster in clusters:
        norm_vals = [ind_to_norm.get(id(ind_tuple[0])) for ind_tuple in cluster]
        norm_vals = [v for v in norm_vals if v is not None]
        if not norm_vals:
            continue
        ave_f1 = sum(v[0] for v in norm_vals) / len(norm_vals)
        ave_f2 = sum(v[1] for v in norm_vals) / len(norm_vals)
        if ave_f1 <= 0.5 and ave_f2 <= 0.5:
            filtered.append(cluster)

    return filtered


def _breeding_population_elite_sparse(pop, toolbox, target_size=None):
    """Generate offspring using Elite & Sparse parent selection.

    Replaces breeding.breeding_population when elite_sparse_enabled is True.
    Uses the same cxpb/mutpb/reppb probabilities but selects parents via
    the Elite & Sparse clustering mechanism (with RNG isolation).
    """
    cxpb = configure_parameters.crossover_probability
    mutpb = configure_parameters.mutate_probability
    reppb = configure_parameters.reproduct_probability
    max_cross = configure_parameters.max_cross_depth
    max_mut = configure_parameters.max_mutate_depth
    max_attempts = configure_parameters.max_attempts_unique

    assert abs(cxpb + mutpb + reppb - 1.0) < 1e-8, \
        "cxpb + mutpb + reppb must sum to 1"

    target = target_size if target_size is not None else configure_parameters.population_size

    # Identify Elite & Sparse clusters, then filter out inferior ones
    clusters, dist_matrix, candidate_pool = (
        _identify_elite_sparse(pop) if configure_parameters.elite_sparse_enabled
        else ([], None, [])
    )
    clusters_filtered = _filter_inferior_clusters(clusters, pop) if clusters else []
    has_clusters = bool(clusters_filtered)

    new_pop = []

    while len(new_pop) < target:
        r_op = _elite_rng.random()

        # --- Crossover: produces 2 offspring ---
        if r_op < cxpb and len(new_pop) <= target - 2:
            if has_clusters and _elite_rng.random() <= configure_parameters.elite_sparse_prob:
                # Select from 2 random filtered clusters (uses cached dist_matrix)
                p1, p2 = _select_from_clusters_crossover(
                    clusters_filtered, dist_matrix, candidate_pool
                )
                if p1 is None or p2 is None:
                    # p1, p2 = _tournament_selection_different(pop, configure_parameters.tourn_size)
                    parents = breeding._select_parents_dcd(pop, 2, toolbox, configure_parameters.tourn_size)
                    p1, p2 = parents[0], parents[1]

            else:
                # Tournament selection from full population
                # p1, p2 = _tournament_selection_different(pop, configure_parameters.tourn_size)
                parents = breeding._select_parents_dcd(pop, 2, toolbox, configure_parameters.tourn_size)
                p1, p2 = parents[0], parents[1]

            if p1 is None or p2 is None:
                fresh = toolbox.population(n=min(2, target - len(new_pop)))
                new_pop.extend(fresh)
                continue

            # Crossover with depth retry
            child1 = breeding._copy_individual_new(p1)
            child2 = breeding._copy_individual_new(p2)
            toolbox.mate(child1, child2)

            if (breeding._tree_depth(child1) <= max_cross
                    and breeding._tree_depth(child2) <= max_cross):
                new_pop.append(child1)
                if len(new_pop) < target:
                    new_pop.append(child2)
            else:
                new_pop.append(breeding._copy_individual(p1))
                if len(new_pop) < target:
                    new_pop.append(breeding._copy_individual(p2))

        # --- Mutation: produces 1 offspring ---
        elif r_op < cxpb + mutpb:
            if has_clusters and _elite_rng.random() <= configure_parameters.elite_sparse_prob:
                p1, _ = _select_from_clusters(clusters_filtered)
                if p1 is None:
                    # p1 = _tournament_selection(pop, configure_parameters.tourn_size)
                    p1 = breeding._select_parents_dcd(pop, 1, toolbox, configure_parameters.tourn_size)[0]
            else:
                # p1 = _tournament_selection(pop, configure_parameters.tourn_size)
                p1 = breeding._select_parents_dcd(pop, 1, toolbox, configure_parameters.tourn_size)[0]
            if p1 is None:
                fresh = toolbox.population(n=min(1, target - len(new_pop)))
                new_pop.extend(fresh)
                continue

            child = breeding._mutate_with_retry(p1, max_mut, max_attempts, toolbox)
            new_pop.append(child)

        # --- Reproduction: produces 1 clone ---
        else:
            if has_clusters and _elite_rng.random() <= configure_parameters.elite_sparse_prob:
                p1, _ = _select_from_clusters(clusters_filtered)
                if p1 is None:
                    # p1 = _tournament_selection(pop, configure_parameters.tourn_size)
                    p1 = breeding._select_parents_dcd(pop, 1, toolbox, configure_parameters.tourn_size)[0]
            else:
                # p1 = _tournament_selection(pop, configure_parameters.tourn_size)
                p1 = breeding._select_parents_dcd(pop, 1, toolbox, configure_parameters.tourn_size)[0]
            if p1 is None:
                fresh = toolbox.population(n=min(1, target - len(new_pop)))
                new_pop.extend(fresh)
                continue

            new_pop.append(breeding._copy_individual(p1))

    return new_pop[:target]


def _plot_population_nor(SEED, PROBLEM, PATH, instance_ele, pop_parent, pop_offspring, pop_combined, pop_selected, gen_id, plot_dir, front_info=None):
    """Plot population distribution in normalized objective space.

    Top-left:     parent population (before crossover/mutation)
    Top-right:    offspring population (after crossover/mutation)
    Bottom-left:  combined (parent + offspring) population
    Bottom-right: selected population (after NSGA-II selection & evaluation)
    Saves one PNG per generation to *plot_dir*.
    """
    all_f1 = ([ind.fitness.values[0] for ind in pop_parent]
              + [ind.fitness.values[0] for ind in pop_offspring]
              + [ind.fitness.values[0] for ind in pop_combined]
              + [ind.fitness.values[0] for ind in pop_selected])
    all_f2 = ([ind.fitness.values[1] for ind in pop_parent]
              + [ind.fitness.values[1] for ind in pop_offspring]
              + [ind.fitness.values[1] for ind in pop_combined]
              + [ind.fitness.values[1] for ind in pop_selected])
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_parent = _raw_vals(pop_parent)
    xy_offspring = _raw_vals(pop_offspring)
    xy_combined = _raw_vals(pop_combined)
    xy_selected = _raw_vals(pop_selected)

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_parent], [v[1] for v in xy_parent],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Parent population  (n={len(pop_parent)})")

    ax_tr.scatter([v[0] for v in xy_offspring], [v[1] for v in xy_offspring],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Offspring population  (n={len(pop_offspring)})")

    ax_bl.scatter([v[0] for v in xy_combined], [v[1] for v in xy_combined],
                  s=8, alpha=0.6, edgecolors="none", color="tab:green")
    ax_bl.set_title(f"Combined population  (n={len(pop_combined)})")

    ax_br.scatter([v[0] for v in xy_selected], [v[1] for v in xy_selected],
                  s=8, alpha=0.6, edgecolors="none", color="tab:red")
    ax_br.set_title(f"New parent population  (n={len(pop_selected)})")

    title = f"Generation {gen_id} — Elite&Sparse NSGA-II"
    if front_info:
        title += f" — {front_info}"
    fig.suptitle(title, fontsize=13, y=0.995)
    fig.tight_layout()


    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"{PROBLEM}-{instance_ele}-{SEED}-gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_train_test_comparison(pop_train, pop_test, gen_id, plot_dir, problem_name, instance_ele, seed):
    """Plot population distribution on training vs test sets (4-subplot figure).

    Top-left:     full population on training instances
    Top-right:    full population on test instances
    Bottom-left:  Pareto front (non-dominated) on training instances
    Bottom-right: Pareto front on test instances
    """
    pareto_train = _get_pareto_front(pop_train)
    pareto_test = _get_pareto_front(pop_test)

    all_pops = [pop_train, pop_test, pareto_train, pareto_test]
    all_f1 = [ind.fitness.values[0] for pop in all_pops for ind in pop]
    all_f2 = [ind.fitness.values[1] for pop in all_pops for ind in pop]
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_train = _raw_vals(pop_train)
    xy_test = _raw_vals(pop_test)
    xy_pareto_train = _raw_vals(pareto_train)
    xy_pareto_test = _raw_vals(pareto_test)

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_train], [v[1] for v in xy_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Full population — Train  (n={len(pop_train)})")

    ax_tr.scatter([v[0] for v in xy_test], [v[1] for v in xy_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Full population — Test  (n={len(pop_test)})")

    ax_bl.scatter([v[0] for v in xy_pareto_train], [v[1] for v in xy_pareto_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_bl.set_title(f"Pareto front — Train  (n={len(pareto_train)})")

    ax_br.scatter([v[0] for v in xy_pareto_test], [v[1] for v in xy_pareto_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_br.set_title(f"Pareto front — Test  (n={len(pareto_test)})")

    fig.suptitle(f"Generation {gen_id} — Train vs Test — Elite&Sparse NSGA-II", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"{problem_name}-{instance_ele}-{seed}-train_vs_test_gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_population_test(pop_tested, plot_dir, filename="test_distribution.png"):
    """Plot population distribution in normalized objective space after testing.

    Single scatter plot showing all individuals evaluated on test instances.
    """
    f1_vals = [ind.fitness.values[0] for ind in pop_tested]
    f2_vals = [ind.fitness.values[1] for ind in pop_tested]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)

    xy_vals = [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop_tested]

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter([v[0] for v in xy_vals], [v[1] for v in xy_vals],
               s=8, alpha=0.6, edgecolors="none", color="tab:purple")
    ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
    ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
    ax.set_xlabel("F1")
    ax.set_ylabel("F2")
    ax.set_title(f"Test population  (n={len(pop_tested)})")
    fig.suptitle("Population on test set", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, filename), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _mean(values):
    if not values:
        return 0.0
    return statistics.fmean(values)


def _std(values):
    if len(values) <= 1:
        return 0.0
    mean = statistics.fmean(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


def _program_size(individual):
    return len(individual)


def _unique_terminal_num(individual):
    terminal_set = set()

    for node in individual:
        node_name = getattr(node, "name", None)
        node_arity = getattr(node, "arity", None)

        if node_name is not None and node_arity == 0:
            terminal_set.add(node_name)

    return len(terminal_set)


def _write_stat_title(file_path):
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(
            "Gen,BestFit1,BestFit2,BestFit1Mean,BestFit1Std,BestFit2Mean,BestFit2Std,"
            "ProgSizeMean,ProgSizeStd,PopSize,ParetoFrontSize\n"
        )


def _append_stat(file_path, gen_id, population, best_ind, pareto_front_size):
    prog_size_list = [_program_size(ind) for ind in population]
    fit1_list = [ind.fitness.values[0] for ind in population]
    fit2_list = [ind.fitness.values[1] for ind in population]

    best_fit1 = best_ind.fitness.values[0]
    best_fit2 = best_ind.fitness.values[1]

    with open(file_path, "a", encoding="utf-8") as file:
        file.write(
            f"{gen_id},{best_fit1},{best_fit2},{_mean(fit1_list)},{_std(fit1_list)},"
            f"{_mean(fit2_list)},{_std(fit2_list)},{_mean(prog_size_list)},{_std(prog_size_list)},"
            f"{len(population)},{pareto_front_size}\n"
        )


def _append_best_rule(file_path, gen_id, individual):
    with open(file_path, "a", encoding="utf-8") as file:
        file.write(f"Generation {gen_id}\n")
        file.write(f"Fitness1 (total cost): {individual.fitness.values[0]}\n")
        file.write(f"Fitness2 (mileage diff): {individual.fitness.values[1]}\n")
        file.write(f"Rule: {individual}\n\n")


def _get_pareto_front(population):
    """Return the first non-dominated front of the population."""
    fronts = tools.sortNondominated(population, len(population))
    if fronts and fronts[0]:
        return fronts[0]
    return population


def _build_cfh_individual(primitive_set):
    """Build a manual 'CFH' individual -- nearest-neighbor heuristic."""
    from deap import creator
    cfh_terminal = None
    for node in primitive_set.terminals[object]:
        if node.name == "CFH":
            cfh_terminal = node
            break
    if cfh_terminal is None:
        raise ValueError("CFH terminal not found in primitive set")
    tree_nodes = [cfh_terminal]
    tree = gp.PrimitiveTree(tree_nodes)
    ind = creator.IndividualMO(tree)
    return ind


def main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE):
    from deap import gp, creator

    if SEED is None:
        seed = configure_parameters.seed
    else:
        seed = SEED

    if PROBLEM is None:
        problem_name = configure_parameters.problem
    else:
        problem_name = PROBLEM

    if PATH is None:
        instance_path = configure_parameters.data_path
    else:
        instance_path = PATH

    if INSTANCE_SET is None:
        instance_set = configure_parameters.instance_set
    else:
        instance_set = INSTANCE_SET

    if INSTANCE_ELE is None:
        instance_ele = configure_parameters.instance_ele
    else:
        instance_ele = INSTANCE_ELE

    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)

    # ------------------------------------------------------------------
    # All output files go under output_test/ to avoid colliding with
    # main_gphh_metro_nsga2.py results (which use train/, test/,
    # pareto_fronts/, etc. directly under the project root).
    # ------------------------------------------------------------------
    output_base = os.path.join(current_dir, "output_test")
    os.makedirs(output_base, exist_ok=True)

    instance_name = os.path.splitext(os.path.basename(instance_path))[0]

    # ========== 1. Load instance ==========
    instance = Instance.Instance(instance_path, 0)

    # ========== 2. Toolbox init ==========
    toolbox = toolboxRegister.toolbox_init(seed)

    # Seed RNG once at the start; do NOT re-seed per generation
    random.seed(seed)

    # ========== 3. Population init ==========
    # Reset RNG immediately before population generation so both programs
    # produce the exact same initial population independently.
    random.seed(seed + 42)
    pop = toolbox.population(n=configure_parameters.population_size)
    pop = utils.remove_duplicate_and_refill(pop, toolbox, configure_parameters.max_attempts_unique)

    # ========== 4. Initial fitness evaluation ==========
    if configure_parameters.parallel_eval:
        pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
    else:
        pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

    # ========== 5. Output files init ==========
    out_stat_path = os.path.join(output_base, "train", f"{instance_name}-{seed}-{problem_name}.out.stat")
    stat_csv_path = os.path.join(output_base, "train", f"{instance_name}-{seed}-{problem_name}.stat.csv")
    os.makedirs(os.path.dirname(out_stat_path), exist_ok=True)

    open(out_stat_path, "w", encoding="utf-8").close()
    _write_stat_title(stat_csv_path)

    # ========== 6. NSGA-II evolution ==========
    archive = []
    best_ind_pop = []
    global_best_ind = None  # Track best-so-far by Fitness1

    for s in range(configure_parameters.gen):
        start_time_gen = time.time()

        # === Step 1: pop_parent is the evaluated population from previous iteration ===
        # Get Pareto front and best individual (lowest Fitness1 on front)
        pareto_front = _get_pareto_front(pop_parent)

        archive.append(pareto_front)

        best_ind = min(pareto_front, key=lambda ind: ind.fitness.values[0])
        best_ind_copy = deepcopy(best_ind)
        best_ind_pop.append(best_ind_copy)

        # Update global best-so-far (by Fitness1)
        if global_best_ind is None:
            global_best_ind = deepcopy(best_ind_copy)
        else:
            if best_ind.fitness.values[0] < global_best_ind.fitness.values[0]:
                global_best_ind = deepcopy(best_ind_copy)

        _append_best_rule(out_stat_path, s, best_ind)
        _append_stat(stat_csv_path, s, pop_parent, best_ind, len(pareto_front))

        print()
        print(f"================ Train Process in The {s}-th Generation =================")
        print(f"Pareto front size: {len(pareto_front)}")
        print("Best individual (lowest total cost on Pareto front):")
        print(best_ind)
        print(f"  Fitness1 (total cost): {best_ind.fitness.values[0]:.2f}")
        print(f"  Fitness2 (mileage diff): {best_ind.fitness.values[1]:.2f}")

        # Print vehicle routes for best-so-far individual
        if configure_parameters.printVehiclesRoute:
            evaluate.print_vehicle_routes(global_best_ind, instance)

        # Save original parent reference for plotting (before reassignment)
        orig_parent = pop_parent

        # === Step 2: pop_parent produces offspring via Elite & Sparse crossover/mutation ===
        if configure_parameters.elite_sparse_enabled:
            offspring = _breeding_population_elite_sparse(
                pop_parent, toolbox,
                target_size=configure_parameters.population_size,
            )
        else:
            offspring = breeding.breeding_population(
                pop_parent, toolbox,
                target_size=configure_parameters.population_size,
            )

        # === Step 3: Evaluate offspring → pop_offspring (on alternate instances) ===
        offspring_instances = _build_offspring_instances(instance, s)
        if configure_parameters.parallel_eval:
            pop_offspring = evaluate.evaluate_population_parallel(offspring, offspring_instances)
        else:
            pop_offspring = evaluate.evaluate_population(offspring, offspring_instances)

        pareto_front = _get_pareto_front(pop_offspring)
        archive.append(pareto_front)
        # === Step 4: pop_parent + pop_offspring → pop_combined ===
        pop_combined = pop_parent + pop_offspring

        # === Step 5: NSGA-II survivor selection → pop_selected ===
        pop_selected = toolbox.select(pop_combined, configure_parameters.population_size)

        # Compute front info for plotting
        fronts = tools.sortNondominated(pop_combined, len(pop_combined))
        N = configure_parameters.population_size
        cumulative = 0
        last_front_idx = 0
        last_front_total = 0
        last_front_selected = 0
        for i, front in enumerate(fronts):
            if cumulative + len(front) <= N:
                cumulative += len(front)
                last_front_idx = i + 1
                last_front_total = len(front)
                last_front_selected = len(front)
            else:
                remaining = N - cumulative
                last_front_idx = i + 1
                last_front_total = len(front)
                last_front_selected = remaining
                break
        if last_front_selected < last_front_total:
            front_info = f"The {last_front_idx} -th front (count_selected / total_count {last_front_selected}/{last_front_total})"
        else:
            front_info = f"The {last_front_idx} -th front"

        # Build new individuals from selected so clearing fitness doesn't affect orig_parent/pop_offspring
        # Deduplicate pop_selected first (still has fitness), then copy.
        pop_selected = _deduplicate_selected(
            pop_selected, toolbox, configure_parameters.population_size,
            source_pop=pop_offspring,
        )
        pop = [type(ind)(ind) for ind in pop_selected]

        # === Step 6: Clear fitness on pop so they are in unevaluated state ===
        for ind in pop:
            del ind.fitness.values

        # === Step 7: Rotate eval model before re-evaluation ===
        if configure_parameters.rotate_eval_model:
            instance.resetSeedInstance(seed, configure_parameters, s + 1)

        # === Step 8: Evaluate pop → pop_parent (for next iteration) ===
        if configure_parameters.parallel_eval:
            pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
        else:
            pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

        # Plot population distribution in normalized objective space
        _plot_population_nor(
            seed,
            problem_name,
            instance_path,
            instance_ele,
            orig_parent, pop_offspring, pop_combined, pop_parent, s,
            os.path.join(output_base, "train", "plots_nor_elite_sparse", f"{instance_set}", f"{instance_ele}"),
            front_info=front_info,
        )

        end_time_eval = time.time()

        # Print average statistics
        avg_fit1 = _mean([ind.fitness.values[0] for ind in pop_parent])
        avg_fit2 = _mean([ind.fitness.values[1] for ind in pop_parent])
        print(f"The average Fitness1 (total cost): {avg_fit1:.2f}")
        print(f"The average Fitness2 (mileage diff): {avg_fit2:.2f}")

        end_time_gen = time.time()

    # ========== 7. Testing phase ==========
    # Step 1: flatten archive into a single list
    archived_individuals = [ind for front in archive for ind in front]

    # Step 2: remove duplicates (same program tree structure) from archive
    seen = set()
    deduped_archive = []
    for ind in archived_individuals:
        key = str(ind)
        if key not in seen:
            seen.add(key)
            deduped_archive.append(ind)
    archived_individuals = deduped_archive
    A = len(archived_individuals)
    N = configure_parameters.population_size

    # Step 3: merge — always keep top K Pareto fronts from pop_parent,
    # fill remaining slots from archived_individuals (back to front)
    fronts = tools.sortNondominated(pop_parent, len(pop_parent))
    keep_fronts = getattr(configure_parameters, 'archive_test_fronts_keep', 3)
    selected = []
    for i in range(min(keep_fronts, len(fronts))):
        selected.extend(fronts[i])

    kept_from_parent = len(selected)
    slots_left = N - kept_from_parent
    if slots_left > 0 and archived_individuals:
        selected += archived_individuals[-slots_left:]

    pop_parent = selected
    print(f"\nArchive (deduped): {A} individuals, kept {kept_from_parent} from pop_parent, "
          f"filled {min(slots_left, A) if archived_individuals else 0} from archive, total: {len(pop_parent)}")


    print("\n================ Testing Process =================\n")
    final_pareto = _get_pareto_front(pop_parent)
    print(f"Final training Pareto front: {len(final_pareto)} solutions\n")

    # Save full pop_parent fitness (before testing overwrites them)
    pop_train = deepcopy(pop_parent)

    test_sample_list = instance.build_test_samples()
    test_csv_path = os.path.join(output_base, "test", f"{instance_name}-{seed}-{problem_name}.stat.csv")
    os.makedirs(os.path.dirname(test_csv_path), exist_ok=True)

    # Test the final training Pareto front on test instances
    test_individuals = deepcopy(final_pareto)
    if configure_parameters.parallel_eval_test:
        test_individuals = evaluate.evaluate_population_parallel_test(test_individuals, test_sample_list)
    else:
        for ind in test_individuals:
            evaluate.evaluate_batch(ind, test_sample_list)
    for ind in test_individuals:
        print(f"  {ind}")
        print(f"    Test Fitness1 (total cost): {ind.fitness.values[0]:.2f}")
        print(f"    Test Fitness2 (mileage diff): {ind.fitness.values[1]:.2f}")

    # Evaluate full pop_parent on test set as well
    test_pop_full = deepcopy(pop_parent)
    if configure_parameters.parallel_eval_test:
        test_pop_full = evaluate.evaluate_population_parallel_test(test_pop_full, test_sample_list)
    else:
        for ind in test_pop_full:
            evaluate.evaluate_batch(ind, test_sample_list)

    # Plot train vs test comparison (4-subplot figure)
    _plot_train_test_comparison(
        pop_train, test_pop_full, configure_parameters.gen,
        os.path.join(output_base, "train", "plots_nor_elite_sparse", f"{instance_set}", f"{instance_ele}"),
        problem_name, instance_ele, seed
    )

    # Find non-dominated front based on TEST fitness values (from full population)
    test_fronts = tools.sortNondominated(test_pop_full, len(test_pop_full))
    test_pareto = test_fronts[0] if test_fronts else test_pop_full
    test_pareto_sorted = sorted(test_pareto, key=lambda ind: ind.fitness.values[0])

    # Write test results CSV (full population evaluated on test set)
    with open(test_csv_path, "w", encoding="utf-8") as file:
        file.write("Index,TestFit1,TestFit2,ProgramSize,UniqueTerminals,Individual\n")
        for idx, ind in enumerate(test_pop_full):
            file.write(
                f"{idx},{ind.fitness.values[0]},{ind.fitness.values[1]},"
                f"{_program_size(ind)},{_unique_terminal_num(ind)},\"{str(ind)}\"\n"
            )

    # Save test-based Pareto front to pareto_fronts/ under output_test/
    pareto_dir = os.path.join(output_base, "pareto_fronts", f"{instance_set}-elite-sparse")
    os.makedirs(pareto_dir, exist_ok=True)
    pareto_csv_path = os.path.join(
        pareto_dir, f"{instance_name}-{seed}-elite-sparse-NSGA2-pareto.csv"
    )
    with open(pareto_csv_path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Individual", "F1", "F2"])
        for ind in test_pareto_sorted:
            writer.writerow([str(ind), ind.fitness.values[0], ind.fitness.values[1]])
    print(f"\nTest Pareto front ({len(test_pareto_sorted)} solutions) saved to: {pareto_csv_path}")

    print(f"Experiment out.stat saved to: {out_stat_path}")
    print(f"Experiment stat.csv saved to: {stat_csv_path}")
    print(f"Experiment test csv saved to: {test_csv_path}")


if __name__ == "__main__":
    a = time.time()

    SEED = None
    PROBLEM = None
    PATH = None
    INSTANCE_SET = None
    INSTANCE_ELE = None

    main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)

    print('total time', time.time() - a)
