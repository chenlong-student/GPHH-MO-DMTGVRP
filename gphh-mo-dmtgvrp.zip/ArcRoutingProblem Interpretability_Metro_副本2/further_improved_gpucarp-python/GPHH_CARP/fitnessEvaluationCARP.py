from deap import gp
import psetHoldCARP
from toolBoxCARP import toolbox


def register_fitness_function(toolbox = toolbox):

    def evaluate_gp_tree(individual):
        """
        使用 terminal_value_map 计算 GP 树的值（基于 gp.compile）
        [Parameters]
        individual : deap.gp.PrimitiveTree GP 个体
        terminal_value_map : dict terminal 名 -> 实际数值

        [Returns]
        result : float or any GP 树的计算结果
        """

        # 1. 获取 pset
        pset = psetHoldCARP.psetHold()

        # 2. 编译 GP 树
        priority = gp.compile(expr=individual, pset=pset)

        return (priority, )

    # toolbox.register("compile", gp.compile, pset=toolbox.pset)
    toolbox.register("compile", gp.compile, pset=psetHoldCARP.psetHold())
    toolbox.register("evaluate", evaluate_gp_tree)