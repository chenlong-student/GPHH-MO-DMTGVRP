#!/usr/bin/env python3
"""Smoke test for egl .dat instances with minimal parameters."""

import os, sys, time, glob, traceback

import configure_parameters
configure_parameters.gen = 1
configure_parameters.population_size = 4
configure_parameters.training_sample_num = 1
configure_parameters.testing_sample_num = 1
configure_parameters.seed_gap_rotation = 1
configure_parameters.evaluate_seed = 0
configure_parameters.testing_seed = 0
configure_parameters.parallel_eval = False
configure_parameters.rotate_eval_model = False
configure_parameters.printVehiclesRoute = False
configure_parameters.population_generation_way = "genHalfAndHalf"
configure_parameters.min_depth_initial_genGrow = 2
configure_parameters.max_depth_initial_genGrow = 2
configure_parameters.min_depth_initial_genFull = 1
configure_parameters.max_depth_initial_genFull = 2
configure_parameters.max_cross_depth = 4
configure_parameters.max_mutate_depth = 4
configure_parameters.max_mutate_subtree_depth = 2
configure_parameters.selection_way = "selTournament"
configure_parameters.tourn_size = 2
configure_parameters.mutate_probability = 0.15
configure_parameters.crossover_probability = 0.80
configure_parameters.terminals_from = "basic"
configure_parameters.include_erc = False
configure_parameters.max_attempts_unique = 50

from main_gphh_metro_nsga2000 import main

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_URARP", "egl")
dat_files = sorted(glob.glob(os.path.join(DATA_DIR, "egl*.dat")))

print(f"Found {len(dat_files)} egl .dat files to test.\n")

passed = 0; failed = 0; fail_list = []
for i, fpath in enumerate(dat_files, 1):
    fname = os.path.basename(fpath)
    print(f"\n[{i}/{len(dat_files)}] Testing {fname} ... ", end="", flush=True)
    t0 = time.time()
    try:
        main(SEED=42, PROBLEM="URARP", PATH=fpath)
        print(f"PASSED ({time.time()-t0:.1f}s)")
        passed += 1
    except Exception as e:
        print(f"FAILED ({time.time()-t0:.1f}s)")
        print(f"  Error: {e}")
        traceback.print_exc()
        failed += 1
        fail_list.append(fname)

print(f"\nResults: {passed} passed, {failed} failed out of {len(dat_files)}")
if fail_list: print(f"Failed: {', '.join(fail_list)}")
else: print("All instances passed!")
sys.exit(0 if failed == 0 else 1)
