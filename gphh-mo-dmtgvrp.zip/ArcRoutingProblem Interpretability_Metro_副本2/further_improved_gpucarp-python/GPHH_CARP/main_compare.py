"""
Comparison script for NSGA-II vs NSGA-II-RL multi-objective optimization.

Computes HV and IGD metrics for each algorithm across multiple random seeds,
then performs statistical significance testing (Wilcoxon signed-rank or Friedman test).

Usage:
    # Compare gdb1 with seeds 0-29 (default):
        python main_compare.py
    # Compare gdb1 with seeds 0-9:
        python main_compare.py --instances gdb1 --seeds 0 10
    # Compare gdb1-gdb3 with seeds 5-14:
        python main_compare.py --instances gdb1 gdb2 gdb3 --seeds 5 15
    # Compare gdb1 with seeds 0,3,6,9 (explicit list):
        python main_compare.py --instances gdb1 --seed-list 0 3 6 9

Output format (per instance):
                    NSGA-II-RL           NSGA-II            Wilcoxon/Friedman
              HV              IGD        HV      IGD        P-value(HV)  P-value(IGD)
    gdb1    0.928(0.232)    0.028(0.132)  0.728(0.532)  0.328(0.232)    0.012        0.004
"""

import os
import csv
import math
import argparse
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ==============================================================================
# Configuration (defaults, overridable via CLI)
# ==============================================================================

# Statistical test: True = Wilcoxon signed-rank test, False = Friedman test
# NOTE: Friedman test requires >= 3 groups (algorithms). For 2-algorithm comparison,
#       it will automatically fall back to Wilcoxon with a warning.
DEFAULT_USE_WILCOXON = True

# Default instances to evaluate
DEFAULT_INSTANCES = [f"gdb{i}" for i in range(1, 2)]

# Default seed range: [0, N_SEEDS)
DEFAULT_SEED_START = 0
DEFAULT_SEED_END = 30

# HV reference point (r1, r2) — must dominate all possible solutions.
# If None, computed automatically as (1.0, 1.0) in normalized space.
DEFAULT_HV_REF_POINT = None

# Base directory where pareto_fronts/ is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARETO_DIR = os.path.join(BASE_DIR, "pareto_fronts")


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Compare NSGA-II vs NSGA-II-RL on CARP instances."
    )
    parser.add_argument(
        "--instances", nargs="+", default=None,
        help="Instances to evaluate (default: gdb1-gdb7). E.g., --instances gdb1 gdb2"
    )
    seed_group = parser.add_mutually_exclusive_group()
    seed_group.add_argument(
        "--seeds", nargs=2, type=int, default=None, metavar=("START", "END"),
        help="Seed range [START, END). E.g., --seeds 0 30"
    )
    seed_group.add_argument(
        "--seed-list", nargs="+", type=int, default=None,
        help="Explicit list of seeds. E.g., --seed-list 0 3 6 9"
    )
    parser.add_argument(
        "--friedman", action="store_true", default=None,
        help="Use Friedman test instead of Wilcoxon"
    )
    parser.add_argument(
        "--hv-ref-point", nargs=2, type=float, default=None, metavar=("R1", "R2"),
        help="HV reference point in normalized space. E.g., --hv-ref-point 1.1 1.1"
    )
    return parser.parse_args()

# ==============================================================================
# Metric computation
# ==============================================================================


def load_pareto_front(csv_path):
    """Load a Pareto front CSV and return list of (F1, F2) tuples.

    Expected format: Individual,F1,F2  (columns 0, 1, 2)
    """
    points = []
    if not os.path.exists(csv_path):
        return points
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)  # skip header
        for row in reader:
            if len(row) >= 3:
                try:
                    points.append((float(row[1]), float(row[2])))
                except ValueError:
                    continue
    return points


def _non_dominated(points):
    """Return the non-dominated subset of points (2-objective minimization)."""
    pts = list(set(points))
    if not pts:
        return pts
    front = []
    for p in pts:
        dominated = False
        for q in pts:
            if q[0] <= p[0] and q[1] <= p[1] and (q[0] < p[0] or q[1] < p[1]):
                dominated = True
                break
        if not dominated:
            front.append(p)
    front.sort(key=lambda x: x[0])
    return front


def compute_hv(front, ref_point):
    """
    Compute hypervolume for a 2-objective minimization problem.

    Args:
        front: list of (F1, F2) tuples.
        ref_point: (r1, r2) reference point that dominates all solutions.

    Returns:
        Hypervolume value. Returns 0.0 if front is empty.
    """
    pts = _non_dominated(front)
    if not pts:
        return 0.0

    r1, r2 = ref_point
    hv = 0.0

    for i in range(len(pts)):
        f1, f2 = pts[i]
        if f1 >= r1 or f2 >= r2:
            continue
        # Width extends from current point to next point (or r1 for the last)
        if i < len(pts) - 1:
            width = pts[i + 1][0] - f1
        else:
            width = r1 - f1
        height = r2 - f2
        hv += width * height

    return hv


def compute_igd(front, ref_front):
    """
    Compute Inverted Generational Distance.

    For each point in ref_front, find the minimum Euclidean distance
    to any point in front. IGD = mean of these distances.

    Args:
        front: list of (F1, F2) tuples from the algorithm.
        ref_front: list of (F1, F2) tuples representing the true Pareto front.

    Returns:
        IGD value. Returns inf if front is empty.
    """
    if not front:
        return float("inf")
    if not ref_front:
        return 0.0

    distances = []
    for rp in ref_front:
        min_dist = min(
            math.sqrt((rp[0] - p[0]) ** 2 + (rp[1] - p[1]) ** 2) for p in front
        )
        distances.append(min_dist)

    return np.mean(distances)


def compute_reference_front(all_fronts):
    """
    Build the reference Pareto front from all algorithm fronts.

    Combines all points, removes duplicates, and extracts the
    non-dominated set.
    """
    all_points = []
    for front in all_fronts:
        all_points.extend(front)
    return _non_dominated(all_points)


def compute_normalization_bounds(all_fronts):
    """
    Compute min/max bounds from all solutions for min-max normalization.

    Returns (min_f1, max_f1, min_f2, max_f2).
    """
    min_f1 = float("inf")
    max_f1 = float("-inf")
    min_f2 = float("inf")
    max_f2 = float("-inf")
    for front in all_fronts:
        for f1, f2 in front:
            min_f1 = min(min_f1, f1)
            max_f1 = max(max_f1, f1)
            min_f2 = min(min_f2, f2)
            max_f2 = max(max_f2, f2)
    return (min_f1, max_f1, min_f2, max_f2)


def normalize_point(point, bounds):
    """
    Min-max normalize a point (F1, F2) into [0, 1] range.

    If max == min for an objective, returns 0.5 (no spread).
    """
    min_f1, max_f1, min_f2, max_f2 = bounds
    n1 = (point[0] - min_f1) / (max_f1 - min_f1 + 1e-16)
    n2 = (point[1] - min_f2) / (max_f2 - min_f2 + 1e-16)
    return (n1, n2)


def normalize_front(front, bounds):
    """Normalize all points in a front."""
    return [normalize_point(p, bounds) for p in front]


def compute_auto_ref_point(all_fronts):
    """
    Automatically compute an HV reference point.

    Uses max(F1) * 1.1 and max(F2) * 1.1 across all fronts.
    """
    max_f1 = 0.0
    max_f2 = 0.0
    for front in all_fronts:
        for f1, f2 in front:
            max_f1 = max(max_f1, f1)
            max_f2 = max(max_f2, f2)
    return (max_f1 * 1.1, max_f2 * 1.1)


# ==============================================================================
# Plotting
# ==============================================================================


def plot_algorithm_comparison(
    algorithm_fronts, ref_front, instance_name, plot_dir
):
    """Scatter plot of all algorithm Pareto fronts in raw objective space.

    All points from all seeds are overlaid; different algorithms use different
    colors. The combined reference front is highlighted in black with square
    markers.

    Args:
        algorithm_fronts: dict {algo_name: [(f1, f2), ...]} — points from
            all seeds combined.
        ref_front: combined non-dominated reference front [(f1, f2), ...].
        instance_name: str, used in title and filename.
        plot_dir: directory to save the plot.
    """
    fig, ax = plt.subplots(figsize=(10, 7))

    colors = {"NSGA-II": "tab:blue", "NSGA-II-RL": "tab:red"}
    sizes = {"NSGA-II": 20, "NSGA-II-RL": 20}

    for algo_name, pts in algorithm_fronts.items():
        if not pts:
            continue
        f1_vals = [p[0] for p in pts]
        f2_vals = [p[1] for p in pts]
        color = colors.get(algo_name, None)
        ax.scatter(
            f1_vals, f2_vals,
            s=sizes.get(algo_name, 20),
            alpha=0.5,
            edgecolors="none",
            color=color,
            label=f"{algo_name}",
        )

    # Reference front
    if ref_front:
        ref_f1 = [p[0] for p in ref_front]
        ref_f2 = [p[1] for p in ref_front]
        ax.scatter(
            ref_f1, ref_f2,
            s=60, alpha=0.9, edgecolors="black",
            facecolors="none", linewidths=1.5, marker="s",
            label="Reference front",
        )

    ax.set_xlabel("F1", fontsize=12)
    ax.set_ylabel("F2", fontsize=12)
    ax.set_title(f"Pareto fronts — {instance_name}", fontsize=13)
    ax.legend(fontsize=10, framealpha=0.8)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(
        os.path.join(plot_dir, f"{instance_name}_comparison.png"),
        dpi=200, bbox_inches="tight",
    )
    plt.close(fig)


# ==============================================================================
# Statistical tests
# ==============================================================================


def wilcoxon_test(values_a, values_b):
    """
    Wilcoxon signed-rank test for paired samples.

    Tests whether the median difference between paired observations
    is significantly different from zero.

    Returns p-value.
    """
    if len(values_a) != len(values_b):
        raise ValueError("Paired samples must have the same length")
    # zero_method='pratt' handles zero differences
    _, p_value = stats.wilcoxon(values_a, values_b, zero_method="pratt")
    return p_value


def friedman_test(values_a, values_b):
    """
    Friedman test for paired samples.

    NOTE: scipy.stats.friedmanchisquare requires >= 3 groups.
    For 2-algorithm comparison, this falls back to Wilcoxon signed-rank test
    and prints a warning. The Friedman test is designed for comparing
    3 or more algorithms across the same instances.

    Returns p-value.
    """
    print("  [WARNING] Friedman test requires >= 3 algorithms. "
          "Falling back to Wilcoxon signed-rank test for 2-algorithm comparison.")
    return wilcoxon_test(values_a, values_b)


# ==============================================================================
# Main
# ==============================================================================


def main(
    instances=None,
    seeds=None,
    use_wilcoxon=None,
    hv_ref_point=None,
):
    """
    Run the comparison.

    Args:
        instances: list of instance names (e.g., ["gdb1", "gdb2"])
        seeds: list of seed integers (e.g., [0, 1, 2, ..., 29])
        use_wilcoxon: bool, which statistical test to use
        hv_ref_point: tuple or None, HV reference point in normalized space
    """
    if instances is None:
        instances = DEFAULT_INSTANCES
    if seeds is None:
        seeds = list(range(DEFAULT_SEED_START, DEFAULT_SEED_END))
    if use_wilcoxon is None:
        use_wilcoxon = DEFAULT_USE_WILCOXON
    if hv_ref_point is None:
        hv_ref_point = DEFAULT_HV_REF_POINT

    print("=" * 80)
    test_name = "Wilcoxon signed-rank test" if use_wilcoxon else "Friedman test"
    print(f"Multi-objective algorithm comparison ({test_name})")
    print(f"Seeds: {seeds[0]}-{seeds[-1]} ({len(seeds)} seeds), Instances: {len(instances)}")
    print("=" * 80)

    for inst in instances:
        hv_nsga2_list = []
        hv_rl_list = []
        igd_nsga2_list = []
        igd_rl_list = []

        all_fronts_nsga2 = []
        all_fronts_rl = []
        valid_seeds = []

        # --- Phase 1: Load all Pareto fronts ---
        for seed in seeds:
            csv_nsga2 = os.path.join(
                PARETO_DIR, "gdb-nsga2", f"{inst}-{seed}-NSGA2-pareto.csv"
            )
            csv_rl = os.path.join(

                PARETO_DIR, "gdb-elite-sparse", f"{inst}-{seed}-elite-sparse-NSGA2-pareto.csv"
                # PARETO_DIR, f"{inst}-{seed}-NSGA2-Test-pareto.csv"

                # PARETO_DIR, f"{inst}-{seed}-RLNSGA2-pareto.csv"
            )

            front_nsga2 = load_pareto_front(csv_nsga2)
            front_rl = load_pareto_front(csv_rl)

            front_nsga2 = list(set(front_nsga2))
            front_rl = list(set(front_rl))

            if not front_nsga2 or not front_rl:
                print(f"  [WARN] {inst} seed={seed}: missing pareto front data "
                      f"(NSGA-II: {len(front_nsga2)} pts, RL: {len(front_rl)} pts)")
                continue

            valid_seeds.append(seed)
            all_fronts_nsga2.append(front_nsga2)
            all_fronts_rl.append(front_rl)

        if not valid_seeds:
            print(f"{inst:<10} [NO DATA]")
            continue

        # --- Phase 2: Compute reference structures ---
        ref_front = compute_reference_front(all_fronts_nsga2 + all_fronts_rl)

        # Normalization bounds from all solutions (used for both HV and IGD)
        norm_bounds = compute_normalization_bounds(all_fronts_nsga2 + all_fronts_rl)
        ref_front_norm = normalize_front(ref_front, norm_bounds)

        # HV reference point in normalized space
        if hv_ref_point is not None:
            ref_point_norm = hv_ref_point
        else:
            ref_point_norm = (1.0, 1.0)

        # --- Phase 3: Compute metrics per seed (on normalized fronts) ---
        per_seed_results = []  # (seed, hv_rl, hv_nsga2, igd_rl, igd_nsga2)
        for idx, seed in enumerate(valid_seeds):
            front_nsga2_norm = normalize_front(all_fronts_nsga2[idx], norm_bounds)
            front_rl_norm = normalize_front(all_fronts_rl[idx], norm_bounds)

            hv = compute_hv(front_nsga2_norm, ref_point_norm)
            hv_rl = compute_hv(front_rl_norm, ref_point_norm)
            igd = compute_igd(front_nsga2_norm, ref_front_norm)
            igd_rl = compute_igd(front_rl_norm, ref_front_norm)

            hv_nsga2_list.append(hv)
            hv_rl_list.append(hv_rl)
            igd_nsga2_list.append(igd)
            igd_rl_list.append(igd_rl)
            per_seed_results.append((seed, hv_rl, hv, igd_rl, igd))

        # --- Phase 3b: Print per-seed results ---
        print(f"\n  Instance: {inst}  --  Per-seed results")
        print(f"  {'Seed':>6}  {'NSGA-II-RL HV':>15}  {'NSGA-II HV':>15}  "
              f"{'NSGA-II-RL IGD':>15}  {'NSGA-II IGD':>15}")
        print(f"  {'-'*74}")
        for seed, hv_rl, hv_nsga2, igd_rl, igd_nsga2 in per_seed_results:
            print(f"  {seed:>6}  {hv_rl:>15.6f}  {hv_nsga2:>15.6f}  "
                  f"{igd_rl:>15.6f}  {igd_nsga2:>15.6f}")
        print()

        # --- Phase 3c: Plot comparison scatter ---
        comparison_dir = os.path.join(BASE_DIR, "comparison_plots")
        plot_algorithm_comparison(
            algorithm_fronts={
                "NSGA-II": [p for front in all_fronts_nsga2 for p in front],
                "NSGA-II-RL": [p for front in all_fronts_rl for p in front],
            },
            ref_front=ref_front,
            instance_name=inst,
            plot_dir=comparison_dir,
        )
        print(f"  Comparison plot saved to: {comparison_dir}/{inst}_comparison.png")

        # --- Phase 4: Statistics ---
        hv_nsga2_mean = np.mean(hv_nsga2_list)
        hv_nsga2_std = np.std(hv_nsga2_list, ddof=0)
        hv_rl_mean = np.mean(hv_rl_list)
        hv_rl_std = np.std(hv_rl_list, ddof=0)

        igd_nsga2_mean = np.mean(igd_nsga2_list)
        igd_nsga2_std = np.std(igd_nsga2_list, ddof=0)
        igd_rl_mean = np.mean(igd_rl_list)
        igd_rl_std = np.std(igd_rl_list, ddof=0)

        if use_wilcoxon:
            p_hv = wilcoxon_test(hv_rl_list, hv_nsga2_list)
            p_igd = wilcoxon_test(igd_rl_list, igd_nsga2_list)
        else:
            p_hv = friedman_test(hv_rl_list, hv_nsga2_list)
            p_igd = friedman_test(igd_rl_list, igd_nsga2_list)

        # --- Phase 5: Output summary ---
        sig_hv = "*" if p_hv < 0.05 else ""
        sig_igd = "*" if p_igd < 0.05 else ""

        hv_rl_str = f"{hv_rl_mean:.4f}({hv_rl_std:.4f})"
        hv_nsga2_str = f"{hv_nsga2_mean:.4f}({hv_nsga2_std:.4f})"
        igd_rl_str = f"{igd_rl_mean:.4f}({igd_rl_std:.4f})"
        igd_nsga2_str = f"{igd_nsga2_mean:.4f}({igd_nsga2_std:.4f})"

        print(f"  Instance: {inst}  --  Summary ({len(valid_seeds)} seeds)")
        print(f"  {'NSGA-II-RL HV':<20} {'NSGA-II HV':<20} P-value(HV)    "
              f"{'NSGA-II-RL IGD':<20} {'NSGA-II IGD':<20} P-value(IGD)")
        print(f"  {'-'*110}")
        print(f"  {hv_rl_str:<20} {hv_nsga2_str:<20} {p_hv:<14.6f} "
              f"{igd_rl_str:<20} {igd_nsga2_str:<20} {p_igd:.6f}{sig_igd}")
        print(f"  {'='*110}")


if __name__ == "__main__":
    args = parse_args()

    instances = args.instances if args.instances is not None else DEFAULT_INSTANCES

    if args.seed_list is not None:
        seeds = sorted(args.seed_list)
    elif args.seeds is not None:
        seeds = list(range(args.seeds[0], args.seeds[1]))
    else:
        seeds = list(range(DEFAULT_SEED_START, DEFAULT_SEED_END))

    use_wilcoxon = DEFAULT_USE_WILCOXON
    if args.friedman:
        use_wilcoxon = False

    hv_ref_point = DEFAULT_HV_REF_POINT
    if args.hv_ref_point is not None:
        hv_ref_point = tuple(args.hv_ref_point)

    main(
        instances=instances,
        seeds=seeds,
        use_wilcoxon=use_wilcoxon,
        hv_ref_point=hv_ref_point,
    )
