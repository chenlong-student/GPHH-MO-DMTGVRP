import math
import configure_parameters


if configure_parameters.fitnessType == 'MIN':
    default_value = math.inf
    weight_value = -1.0
if configure_parameters.fitnessType == 'MAX':
    default_value = -math.inf
    weight_value = 1.0
