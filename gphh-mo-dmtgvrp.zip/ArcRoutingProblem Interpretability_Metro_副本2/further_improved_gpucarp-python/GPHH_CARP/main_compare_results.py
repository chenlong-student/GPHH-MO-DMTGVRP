"""
Comparison script for Elite-Sparse vs Standard NSGA-II multi-objective optimization.

Computes HV and IGD metrics for each algorithm across multiple random seeds,
then performs statistical significance testing (Wilcoxon signed-rank test).

Usage:
    # Compare all kshs instances (kshs1, kshs2, kshs3), seeds 0-29:
        python main_compare_results.py --prefix kshs
    # Compare gdb instances (gdb1..gdbN), seeds 0-9:
        python main_compare_results.py --prefix gdb --seeds 0 10
    # Compare kshs1 only, seeds 0,5,10,15:
        python main_compare_results.py --prefix kshs --instances kshs1 --seed-list 0 5 10 15

Output format (per instance):
                    Elite-Sparse          NSGA-II             Wilcoxon
              HV              IGD        HV      IGD        P-value(HV)  P-value(IGD)
    kshs1   0.928(0.232)    0.028(0.132)  0.728(0.532)  0.328(0.232)    0.012        0.004
"""

import os
import csv
import math
import argparse
import glob
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

# ==============================================================================
# Configuration
# ==============================================================================

# ==============================================================================
# User Configuration  (直接修改这里即可运行，无需命令行参数)
# ==============================================================================

# 实例前缀：输入 "kshs" 自动展开为 kshs1,kshs2,kshs3；输入 "kshs1" 只跑 kshs1
PREFIX = "kshs"

# 也可以显式指定实例列表，优先级高于 PREFIX 自动展开
# INSTANCES = ["kshs1"]  # None 表示自动展开
INSTANCES = None

# 种子列表：直接写 list(range(30)) 或 [0, 5, 10, 15]
SEEDS = list(range(30))
# SEEDS = [0, 1, 2]  # 也可以显式指定

# 统计检验：True = Wilcoxon, False = Friedman
USE_WILCOXON = True

# HV 参考点，None 表示自动 (1.0, 1.0)
HV_REF_POINT = None

# ==============================================================================
# Internal defaults (overridable via CLI args)
# ==============================================================================

DEFAULT_PREFIX = "kshs"
DEFAULT_SEED_START = 0
DEFAULT_SEED_END = 30
DEFAULT_USE_WILCOXON = True
DEFAULT_HV_REF_POINT = None

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Directory mapping: algorithm_name -> relative subdir under {output_X}/pareto_fronts/
ALGO_CONFIG = {
    "Elite-Sparse": {
        "output_root": "output_test",
        "subdir": "kshs-elite-sparse",  # prefix replaced dynamically
        "file_pattern": "{inst}-{seed}-elite-sparse-NSGA2-pareto.csv",
    },
    "NSGA-II": {
        "output_root": "output_stand",
        "subdir": "kshs-nsga2",  # prefix replaced dynamically
        "file_pattern": "{inst}-{seed}-NSGA2-pareto.csv",
    },
}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Compare Elite-Sparse vs Standard NSGA-II on arc routing instances."
    )
    parser.add_argument(
        "--prefix", type=str, default="kshs",
        help="Dataset prefix (default: 'kshs'). "
             "Auto-expands to kshs1,kshs2,kshs3. Also supports 'gdb', 'val', etc."
    )
    parser.add_argument(
        "--instances", nargs="+", default=None,
        help="Explicit instance list. Overrides auto-expand. "
             "E.g., --instances kshs1 kshs2"
    )
    parser.add_argument(
        "--seeds", nargs=2, type=int, default=None, metavar=("START", "END"),
        help="Seed range [START, END). E.g., --seeds 0 30"
    )
    parser.add_argument(
        "--seed-list", nargs="+", type=int, default=None,
        help="Explicit list of seeds. E.g., --seed-list 0 3 6 9"
    )
    parser.add_argument(
        "--hv-ref-point", nargs=2, type=float, default=None, metavar=("R1", "R2"),
        help="HV reference point in normalized space."
    )
    parser.add_argument(
        "--friedman", action="store_true", default=False,
        help="Use Friedman test instead of Wilcoxon."
    )
    return parser.parse_args()


def _extract_base_prefix(prefix):
    """Strip trailing digits to get directory-level prefix.

    E.g. 'kshs1' -> 'kshs', 'kshs' -> 'kshs', 'gdb3' -> 'gdb'
    """
    import re
    return re.sub(r'\d+$', '', prefix)


def auto_expand_instances(prefix):
    """Scan output directories to find all instance names matching the prefix.

    E.g. prefix='kshs' -> finds kshs1, kshs2, kshs3 by listing files in
    output_test/pareto_fronts/kshs-elite-sparse/ and extracting unique prefixes.
    """
    base = _extract_base_prefix(prefix)
    elite_dir = os.path.join(BASE_DIR, "output_test", "pareto_fronts", f"{base}-elite-sparse")
    if not os.path.isdir(elite_dir):
        print(f"  [WARN] Directory not found: {elite_dir}")
        return [prefix]

    # Extract instance names from filenames like "kshs1-0-elite-sparse-NSGA2-pareto.csv"
    instances = set()
    for fname in os.listdir(elite_dir):
        if not fname.endswith(".csv"):
            continue
        parts = fname.split("-")
        if len(parts) >= 2:
            # First part(s) before the seed number form the instance name
            # Heuristic: try kshs1, kshs2, etc. by matching prefix + digits
            inst = parts[0]
            if inst.startswith(prefix):
                instances.add(inst)

    return sorted(instances)


# ==============================================================================
# Metric computation
# ==============================================================================


def load_pareto_front(csv_path):
    """Load a Pareto front CSV and return list of (F1, F2) tuples."""
    points = []
    if not os.path.exists(csv_path):
        return points
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) >= 3:
                try:
                    points.append((float(row[1]), float(row[2])))
                except ValueError:
                    continue
    return points


def _non_dominated(points):
    """Return the non-dominated subset (2-objective minimization)."""
    pts = list(set(points))
    if not pts:
        return pts
    front = []
    for p in pts:
        dominated = False
        for q in pts:
            if q[0] <= p[0] and q[1] <= p[1] and (q[0] < p[0] or q[1] < p[1]):
                dominated = True
                break
        if not dominated:
            front.append(p)
    front.sort(key=lambda x: x[0])
    return front


def compute_hv(front, ref_point):
    """Hypervolume for 2-objective minimization."""
    pts = _non_dominated(front)
    if not pts:
        return 0.0
    r1, r2 = ref_point
    hv = 0.0
    for i in range(len(pts)):
        f1, f2 = pts[i]
        if f1 >= r1 or f2 >= r2:
            continue
        width = (pts[i + 1][0] - f1) if i < len(pts) - 1 else (r1 - f1)
        height = r2 - f2
        hv += width * height
    return hv


def compute_igd(front, ref_front):
    """Inverted Generational Distance."""
    if not front:
        return float("inf")
    if not ref_front:
        return 0.0
    distances = [
        min(math.sqrt((rp[0] - p[0]) ** 2 + (rp[1] - p[1]) ** 2) for p in front)
        for rp in ref_front
    ]
    return np.mean(distances)


def compute_reference_front(all_fronts):
    """Combined non-dominated front from all algorithm fronts."""
    all_points = []
    for front in all_fronts:
        all_points.extend(front)
    return _non_dominated(all_points)


def compute_normalization_bounds(all_fronts):
    """Min-max bounds for normalization."""
    min_f1 = min_f2 = float("inf")
    max_f1 = max_f2 = float("-inf")
    for front in all_fronts:
        for f1, f2 in front:
            min_f1 = min(min_f1, f1)
            max_f1 = max(max_f1, f1)
            min_f2 = min(min_f2, f2)
            max_f2 = max(max_f2, f2)
    return (min_f1, max_f1, min_f2, max_f2)


def normalize_point(point, bounds):
    """Min-max normalize to [0, 1]."""
    min_f1, max_f1, min_f2, max_f2 = bounds
    n1 = (point[0] - min_f1) / (max_f1 - min_f1 + 1e-16)
    n2 = (point[1] - min_f2) / (max_f2 - min_f2 + 1e-16)
    return (n1, n2)


def normalize_front(front, bounds):
    return [normalize_point(p, bounds) for p in front]


# ==============================================================================
# Plotting
# ==============================================================================


def plot_algorithm_comparison(algorithm_fronts, ref_front, instance_name, plot_dir):
    """Scatter plot of all algorithm Pareto fronts."""
    fig, ax = plt.subplots(figsize=(10, 7))

    color_cycle = plt.get_cmap("tab10").colors
    colors = {}
    for i, name in enumerate(algorithm_fronts):
        colors[name] = color_cycle[i % len(color_cycle)]

    for algo_name, pts in algorithm_fronts.items():
        if not pts:
            continue
        ax.scatter(
            [p[0] for p in pts], [p[1] for p in pts],
            s=20, alpha=0.5, edgecolors="none",
            color=colors[algo_name], label=algo_name,
        )

    if ref_front:
        ax.scatter(
            [p[0] for p in ref_front], [p[1] for p in ref_front],
            s=60, alpha=0.9, edgecolors="black",
            facecolors="none", linewidths=1.5, marker="s",
            label="Reference front",
        )

    ax.set_xlabel("F1", fontsize=12)
    ax.set_ylabel("F2", fontsize=12)
    ax.set_title(f"Pareto fronts -- {instance_name}", fontsize=13)
    ax.legend(fontsize=10, framealpha=0.8)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(
        os.path.join(plot_dir, f"{instance_name}_comparison.png"),
        dpi=200, bbox_inches="tight",
    )
    plt.close(fig)


# ==============================================================================
# Statistical tests
# ==============================================================================


def wilcoxon_test(values_a, values_b):
    if len(values_a) != len(values_b):
        raise ValueError("Paired samples must have the same length")
    _, p_value = stats.wilcoxon(values_a, values_b, zero_method="pratt")
    return p_value


# ==============================================================================
# Excel output
# ==============================================================================

def _style_header_row(ws, row, cols, font_color="FFFFFF", bg_color="4472C4"):
    """Style a header row with bold white text on blue background."""
    header_font = Font(bold=True, color=font_color, size=11)
    header_fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )
    for col_idx in range(1, cols + 1):
        cell = ws.cell(row=row, column=col_idx)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin_border


def _style_data_cell(ws, row, col, fmt="0.0000"):
    """Style a data cell with border and number format."""
    cell = ws.cell(row=row, column=col)
    cell.number_format = fmt
    cell.alignment = Alignment(horizontal="center")
    cell.border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )


def write_comparison_excel(all_results, output_path):
    """Write comparison results to a multi-sheet Excel file.

    all_results: list of dicts, one per instance, each containing:
        - instance: str
        - algo_names: list of str
        - valid_seeds: list of int
        - per_seed: {algo_name: {"hv": [...], "igd": [...]}}
        - summary: {algo_name: (hv_mean, hv_std, igd_mean, igd_std)}
        - p_hv, p_igd: float or None
    """
    wb = Workbook()

    # --- Sheet 1: Per-seed results ---
    ws1 = wb.active
    ws1.title = "Per-Seed Results"

    # Header
    header = ["Instance", "Seed"]
    for res in all_results:
        for name in res["algo_names"]:
            header.extend([f"{name} HV", f"{name} IGD"])
    ws1.append(header)
    _style_header_row(ws1, 1, len(header))

    # Data
    for res in all_results:
        inst = res["instance"]
        n_algos = len(res["algo_names"])
        for idx, seed in enumerate(res["valid_seeds"]):
            row = [inst, seed]
            for name in res["algo_names"]:
                row.extend([
                    res["per_seed"][name]["hv"][idx],
                    res["per_seed"][name]["igd"][idx],
                ])
            ws1.append(row)
            r = ws1.max_row
            for c in range(1, len(row) + 1):
                _style_data_cell(ws1, r, c)

    # Column widths
    ws1.column_dimensions["A"].width = 12
    ws1.column_dimensions["B"].width = 8
    for c in range(3, len(header) + 1):
        col_letter = _col_letter(c)
        ws1.column_dimensions[col_letter].width = 14

    # --- Sheet 2: Summary statistics ---
    ws2 = wb.create_sheet("Summary")
    header2 = ["Instance"]
    for name in all_results[0]["algo_names"]:
        header2.extend([
            f"{name} HV Mean", f"{name} HV Std",
            f"{name} IGD Mean", f"{name} IGD Std",
        ])
    header2.extend(["N Seeds"])
    ws2.append(header2)
    _style_header_row(ws2, 1, len(header2))

    for res in all_results:
        row = [res["instance"]]
        for name in res["algo_names"]:
            hv_m, hv_s, igd_m, igd_s = res["summary"][name]
            row.extend([hv_m, hv_s, igd_m, igd_s])
        row.append(len(res["valid_seeds"]))
        ws2.append(row)
        r = ws2.max_row
        for c in range(1, len(row) + 1):
            _style_data_cell(ws2, r, c, "0.0000")

    ws2.column_dimensions["A"].width = 12
    for c in range(2, len(header2) + 1):
        col_letter = _col_letter(c)
        ws2.column_dimensions[col_letter].width = 16

    # --- Sheet 3: Wilcoxon p-values ---
    ws3 = wb.create_sheet("Wilcoxon Test")
    header3 = ["Instance", "Comparison", "P-value (HV)", "P-value (IGD)", "Significant (HV)", "Significant (IGD)"]
    ws3.append(header3)
    _style_header_row(ws3, 1, len(header3))

    for res in all_results:
        if res["p_hv"] is not None:
            other = res["algo_names"][0]
            baseline = res["algo_names"][-1]
            row = [
                res["instance"],
                f"{other} vs {baseline}",
                res["p_hv"],
                res["p_igd"],
                "Yes" if res["p_hv"] < 0.05 else "No",
                "Yes" if res["p_igd"] < 0.05 else "No",
            ]
            ws3.append(row)
            r = ws3.max_row
            _style_data_cell(ws3, r, 3, "0.000000")
            _style_data_cell(ws3, r, 4, "0.000000")
            for c in [1, 2, 5, 6]:
                _style_data_cell(ws3, r, c, "@")
        else:
            row = [res["instance"], "--", "--", "--", "--", "--"]
            ws3.append(row)
            r = ws3.max_row
            for c in range(1, len(row) + 1):
                _style_data_cell(ws3, r, c, "@")

    for col_letter in ["A", "B"]:
        ws3.column_dimensions[col_letter].width = 18
    for col_letter in ["C", "D", "E", "F"]:
        ws3.column_dimensions[col_letter].width = 18

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    return output_path


def _col_letter(col_idx):
    """Convert 1-based column index to Excel column letter."""
    result = ""
    while col_idx > 0:
        col_idx -= 1
        result = chr(col_idx % 26 + 65) + result
        col_idx //= 26
    return result


# ==============================================================================
# Main
# ==============================================================================


def main(prefix, instances=None, seeds=None, use_wilcoxon=None, hv_ref_point=None):
    if instances is None:
        instances = auto_expand_instances(prefix)
    if seeds is None:
        seeds = list(range(DEFAULT_SEED_START, DEFAULT_SEED_END))
    if use_wilcoxon is None:
        use_wilcoxon = DEFAULT_USE_WILCOXON

    print("=" * 80)
    print(f"Elite-Sparse vs NSGA-II comparison (Wilcoxon signed-rank test)")
    print(f"Prefix: {prefix} | Instances: {instances} | Seeds: {seeds[0]}-{seeds[-1]} ({len(seeds)})")
    print("=" * 80)

    algo_names = list(ALGO_CONFIG.keys())  # ["Elite-Sparse", "NSGA-II"]
    all_results = []

    for inst in instances:
        algo_fronts = {name: [] for name in algo_names}
        algo_per_seed = {name: [] for name in algo_names}
        valid_seeds = []

        # --- Phase 1: Load all Pareto fronts ---
        for seed in seeds:
            seed_ok = True
            for name, cfg in ALGO_CONFIG.items():
                # Derive subdir from base prefix (strip trailing digits)
                base = _extract_base_prefix(prefix)
                subdir = cfg["subdir"].replace("kshs", base)
                csv_path = os.path.join(
                    BASE_DIR, cfg["output_root"], "pareto_fronts", subdir,
                    cfg["file_pattern"].format(inst=inst, seed=seed),
                )
                front = load_pareto_front(csv_path)
                if not front:
                    seed_ok = False
                algo_per_seed[name].append(front)

            if not seed_ok:
                missing = []
                for name in algo_names:
                    if not algo_per_seed[name][-1]:
                        missing.append(name)
                print(f"  [WARN] {inst} seed={seed}: missing data for {', '.join(missing)}")
                # Remove the empty entries
                for name in algo_names:
                    algo_per_seed[name].pop()
                continue

            valid_seeds.append(seed)
            for name in algo_names:
                algo_fronts[name].extend(algo_per_seed[name][-1])

        if not valid_seeds:
            print(f"{inst:<10} [NO DATA]")
            continue

        # --- Phase 2: Compute reference structures ---
        all_fronts_combined = [algo_fronts[name] for name in algo_names]
        ref_front = compute_reference_front(all_fronts_combined)
        norm_bounds = compute_normalization_bounds(all_fronts_combined)
        ref_front_norm = normalize_front(ref_front, norm_bounds)
        ref_point_norm = hv_ref_point if hv_ref_point else (1.0, 1.0)

        # --- Phase 3: Compute metrics per seed ---
        per_seed = {name: {"hv": [], "igd": []} for name in algo_names}
        for idx, seed in enumerate(valid_seeds):
            for name in algo_names:
                front_norm = normalize_front(algo_per_seed[name][idx], norm_bounds)
                hv = compute_hv(front_norm, ref_point_norm)
                igd = compute_igd(front_norm, ref_front_norm)
                per_seed[name]["hv"].append(hv)
                per_seed[name]["igd"].append(igd)

        # Print per-seed results
        hdr = f"  {'Seed':>6}"
        for name in algo_names:
            hdr += f"  {name + ' HV':>15}  {name + ' IGD':>15}"
        print(f"\n  Instance: {inst}")
        print(hdr)
        print(f"  {'-' * (10 + 34 * len(algo_names))}")
        for idx, seed in enumerate(valid_seeds):
            line = f"  {seed:>6}"
            for name in algo_names:
                line += f"  {per_seed[name]['hv'][idx]:>15.6f}  {per_seed[name]['igd'][idx]:>15.6f}"
            print(line)

        # --- Phase 4: Plot ---
        plot_dir = os.path.join(BASE_DIR, "comparison_plots", prefix)
        plot_algorithm_comparison(
            algorithm_fronts={n: list(set(algo_fronts[n])) for n in algo_names},
            ref_front=ref_front,
            instance_name=inst,
            plot_dir=plot_dir,
        )
        print(f"  Plot saved: {plot_dir}/{inst}_comparison.png")

        # --- Phase 5: Statistics ---
        print(f"\n  Instance: {inst}  --  Summary ({len(valid_seeds)} seeds)")
        algo_stats = {}
        for name in algo_names:
            hv_m = np.mean(per_seed[name]["hv"])
            hv_s = np.std(per_seed[name]["hv"], ddof=0)
            igd_m = np.mean(per_seed[name]["igd"])
            igd_s = np.std(per_seed[name]["igd"], ddof=0)
            algo_stats[name] = (hv_m, hv_s, igd_m, igd_s)

        # Wilcoxon: compare each algo against the first (NSGA-II as baseline)
        baseline = algo_names[-1]  # NSGA-II
        p_hv = p_igd = None
        if len(algo_names) == 2:
            other = algo_names[0]
            p_hv = wilcoxon_test(per_seed[other]["hv"], per_seed[baseline]["hv"])
            p_igd = wilcoxon_test(per_seed[other]["igd"], per_seed[baseline]["igd"])

        # Header
        hdr2 = f"  {'HV':<20} {'IGD':<20}"
        if p_hv is not None:
            hdr2 += " P-value(HV)   P-value(IGD)"
        print(hdr2)
        for name in algo_names:
            hv_m, hv_s, igd_m, igd_s = algo_stats[name]
            row = f"  {name:<8} {hv_m:.4f}({hv_s:.4f})     {igd_m:.4f}({igd_s:.4f})"
            if name == algo_names[0] and p_hv is not None:
                row += f"    {p_hv:.6f}{'*' if p_hv < 0.05 else '':>2}      {p_igd:.6f}{'*' if p_igd < 0.05 else '':>2}"
            else:
                row += "   --          --"
            print(row)
        print(f"  {'=' * 110}")

        # --- Collect results for Excel ---
        all_results.append({
            "instance": inst,
            "algo_names": list(algo_names),
            "valid_seeds": list(valid_seeds),
            "per_seed": per_seed,
            "summary": algo_stats,
            "p_hv": p_hv,
            "p_igd": p_igd,
        })

    # --- Phase 6: Save Excel ---
    if all_results:
        excel_path = os.path.join(BASE_DIR, "comparison_results", f"{prefix}_comparison.xlsx")
        write_comparison_excel(all_results, excel_path)
        print(f"\nExcel results saved to: {excel_path}")


if __name__ == "__main__":
    prefix = "real"
    seeds = list(range(30))

    main(prefix=prefix, seeds=seeds)
