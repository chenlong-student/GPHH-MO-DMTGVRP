import main_gphh_metro_nsga2
import main_gphh_metro_nsga2_test


if __name__ == "__main__":

    PROBLEM = "URARP"

    INSTANCE_SET = "realWorldApplication"
    for INSTANCE_ELE in ['real']:
        PATH = f"data_{PROBLEM}/{INSTANCE_SET}/{INSTANCE_ELE}.dat"
        for SEED in range(30):
            main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
            main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)

    # INSTANCE_SET = "kshs"
    # for INSTANCE_ELE in ['kshs1', 'kshs2', 'kshs3']:
    #     PATH = f"data_{PROBLEM}/{INSTANCE_SET}/{INSTANCE_ELE}.dat"
    #     for SEED in range(30):
    #         main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
    #         main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)

    # INSTANCE_SET = "gdb"
    # for INSTANCE_ELE in ['gdb1', 'gdb2', 'gdb3']:
    #     PATH = f"data_{PROBLEM}/{INSTANCE_SET}/{INSTANCE_ELE}.dat"
    #     for SEED in range(30):
    #         main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
    #         main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)


    # INSTANCE_SET = "val"
    # for INSTANCE_ELE in ['val1A', 'val2A', 'val3A']:
    #     PATH = f"data_{PROBLEM}/{INSTANCE_SET}/{INSTANCE_ELE}.dat"
    #     for SEED in range(30):
    #         main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
    #         main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
    #
    # INSTANCE_SET = "egl"
    # for INSTANCE_ELE in ['egl-e1-A', 'egl-e2-A', 'egl-e3-A']:
    #     PATH = f"data_{PROBLEM}/{INSTANCE_SET}/{INSTANCE_ELE}.dat"
    #     for SEED in range(30):
    #         main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)
    #         main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)