## NSGA-II-Test 参照点选择参数配置
## 此文件导入 configure_parameters.py 中的所有基础 GPHH 参数，
## 并额外提供 Elite & Sparse 选择策略专用参数。
## main_gphh_metro_nsga2_test.py 应导入此文件而非 configure_parameters。

## ========== 导入基础 GPHH 参数 ==========
from configure_parameters import *  # noqa: F401,F403


# =========================================================================
# Elite & Sparse 选择策略参数
#
# 核心思想：识别 Pareto 前沿上"优良且孤独"的个体（高非支配等级 + 低局部密度），
# 在交叉/变异时以一定概率从这些个体中选择父代，从而增加目标空间
# 稀疏区域的搜索密度，防止归一化后的目标空间出现"留白"。
#
# 个体在归一化 (F1, F2) 空间中通过 HDBSCAN 密度聚类进行分组，
# 从每个簇中选取 aveDis 最大的个体作为"优良孤独"父代。
# =========================================================================

# 是否启用 Elite & Sparse 策略
elite_sparse_enabled = True

# 非支配等级上限（1-based）。等级 <= 此值的个体纳入候选集合 M
elite_max_rank = 6

# ---- HDBSCAN 聚类参数 ----
hdbscan_min_cluster_size = 5       # 簇最小个体数（越大簇越少）
hdbscan_min_samples = None         # 核心点判定阈值；None 则等于 min_cluster_size
hdbscan_metric = 'euclidean'       # 距离度量：'euclidean' / 'manhattan' 等

# ---- 父代选择概率 ----
elite_sparse_prob = 0.1              # 从 Elite & Sparse 聚类选父代的概率

# ---- 测试阶段 Archive 合并参数 ----
# 当 archive 去重后个体数 A >= 种群规模 N 时，从 pop_parent 中保留
# 前 N 级 Pareto 前沿的个体，剩余席位从 archive 末尾（最新世代）往前填充。
archive_test_fronts_keep = 4

# ---- 去重补位交叉父代池参数 ----
# 去重后空位由交叉产生的个体填补，交叉父代从 F1 排名前 N 和 F2 排名前 N 的个体
# 组成的并集池中随机抽取。此参数控制 N 的比例（相对于 source_pop 的大小）。
dedup_crossover_parent_ratio = 1 / 10  # 可改为 0.25, 0.2, 0.5 等

# ---- RNG 隔离种子 ----
# 独立随机种子，不污染主流程的 random.seed()
elite_sparse_rng_seed = 20260610
