import main_gphh_metro_nsga2
import main_gphh_metro_nsga2_test


if __name__ == "__main__":

    PROBLEM = "URARP"
    for INX in ["2", "3", "4", "5", "6", "7", "8", "9"]:
        PATH = f"data_{PROBLEM}/gdb/gdb{INX}.dat"

        for SEED in range(30):
            main_gphh_metro_nsga2.main(SEED, PROBLEM, PATH)
            main_gphh_metro_nsga2_test.main(SEED, PROBLEM, PATH)