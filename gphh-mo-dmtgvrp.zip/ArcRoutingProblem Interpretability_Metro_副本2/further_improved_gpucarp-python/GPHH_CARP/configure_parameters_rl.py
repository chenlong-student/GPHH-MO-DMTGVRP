## RL-NSGA-II 强化学习参数配置
## 此文件导入 configure_parameters.py 中的所有基础 GPHH 参数，
## 并额外提供 RL 专用参数。
## main_gphh_metro_nsga2_RL.py 应导入此文件而非 configure_parameters。

## ========== 导入基础 GPHH 参数 ==========
from configure_parameters import *  # noqa: F401,F403

## ========== RL 专用参数汇总 ==========

## ---------- Q-learning 超参数 ----------
rl_epsilon         = 0.15   # 探索率：每代有 epsilon 概率随机选择动作
rl_learning_rate   = 0.10   # 学习率：Q 值更新的步长
rl_gamma           = 0.90   # 折扣因子：对未来奖励的重视程度

## ---------- 状态空间离散化 ----------
## State = (avg_f1_nor_bin, avg_f2_nor_bin, igd_bin, hv_bin)，各 3 档 → 3^4 = 81 种状态
##
##   维度             低(0)      中(1)      高(2)
##   avgF1_nor        > 0.50    0.30~0.50   < 0.30   (越小越好)
##   avgF2_nor        > 0.50    0.30~0.50   < 0.30   (越小越好)
##   igd              > 0.50    0.30~0.50   < 0.30   (越小越好)
##   hv               < 0.85    0.85~0.90   > 0.90   (越大越好)

# avgF1_nor 阈值（越小越好）
rl_avgF1_nor_low   = 0.30   # < 0.30 → bin 2 (good)
rl_avgF1_nor_high  = 0.50   # > 0.50 → bin 0 (poor)

# avgF2_nor 阈值（越小越好）
rl_avgF2_nor_low   = 0.30   # < 0.30 → bin 2 (good)
rl_avgF2_nor_high  = 0.50   # > 0.50 → bin 0 (poor)

# igd 阈值（越小越好）
rl_igd_low   = 0.10   # < 0.30 → bin 2 (good)
rl_igd_high  = 0.30   # > 0.50 → bin 0 (poor)

# hv 阈值（越大越好）
rl_hv_low    = 0.85   # < 0.85 → bin 0 (poor)
rl_hv_high   = 0.90   # > 0.90 → bin 2 (good)

## ---------- Strong 策略参数 ----------
rl_reserve_count     = 100  # strong_* 动作下保底保留的对立目标极端个体数量
rl_pareto_fronts_num = 5    # strong_* 动作下保底保留的非支配前沿层数


pure_nsga2 = False
