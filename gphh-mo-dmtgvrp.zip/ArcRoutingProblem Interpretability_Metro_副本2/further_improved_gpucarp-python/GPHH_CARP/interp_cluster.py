"""
Population Clustering & Representative-based Fitness2 Evaluation
================================================================
Reduces LLM calls by:
1. Computing AST structural similarity matrix (matrix_s2)
2. Single-view Spectral Clustering
3. All clusters get representatives selected via two-stage method
4. LLM scoring for representatives + proxy model interpolation
5. Global archive of LLM-scored individuals enriches proxy training
   and similarity-based correction across generations
"""

import math
import time
from collections import defaultdict, Counter
from copy import deepcopy

# Global archive storing all LLM-scored individuals across generations.
# {canon_str: {"f2": float, "features": tuple, "ast": AST|None}}
F2_LLM_ARCHIVE = {}

# Canonicalization helpers (imported lazily to avoid circular deps)
_individual_canonical = None
_primitive_tree_to_ast = None


def _import_canonicalizers():
    global _individual_canonical, _primitive_tree_to_ast
    if _individual_canonical is not None:
        return True
    try:
        from main_interpretability import (
            _primitive_tree_to_ast as _pta,
            _individual_canonical as _ic,
        )
        _primitive_tree_to_ast = _pta
        _individual_canonical = _ic
        return True
    except ImportError:
        return False


def _get_canonical(ind):
    """Return (canon_str, canon_ast) for an individual, skipping if already simplest."""
    if getattr(ind, 'simpest', False):
        s = str(ind)
        ast = _primitive_tree_to_ast(ind) if _primitive_tree_to_ast is not None else None
        return s, ast
    if _individual_canonical is not None:
        try:
            return _individual_canonical(ind)
        except Exception:
            pass
    # Fallback
    if _primitive_tree_to_ast is not None:
        return str(ind), _primitive_tree_to_ast(ind)
    return str(ind), None


def _parse_canonical_string(s):
    """Parse a canonical prefix string back into an AST.

    Canonical format:
      - Plain constant/variable: "5", "CFH"
      - Prefix: "(op_name child1 child2)"

    Returns AST in ('const', val), ('var', name), or ('op', name, children) form.
    """
    s = s.strip()
    if not s.startswith('('):
        # Terminal or constant
        try:
            return ('const', float(s))
        except ValueError:
            return ('var', s)

    # Parse "(op_name child1 child2)"
    # Remove outer parens
    inner = s[1:-1].strip()
    # Extract op_name (everything up to first space that's not inside parens)
    paren_depth = 0
    name_end = -1
    for i, ch in enumerate(inner):
        if ch == '(':
            paren_depth += 1
        elif ch == ')':
            paren_depth -= 1
        elif ch == ' ' and paren_depth == 0:
            name_end = i
            break
    op_name = inner[:name_end]
    rest = inner[name_end + 1:].strip()

    # Parse children
    children = []
    paren_depth = 0
    child_start = 0
    for i, ch in enumerate(rest):
        if ch == '(':
            paren_depth += 1
        elif ch == ')':
            paren_depth -= 1
        elif ch == ' ' and paren_depth == 0:
            child_str = rest[child_start:i].strip()
            if child_str:
                children.append(_parse_canonical_string(child_str))
            child_start = i + 1
    # Last child
    child_str = rest[child_start:].strip()
    if child_str:
        children.append(_parse_canonical_string(child_str))

    return ('op', op_name, children)


def _ast_structural_similarity_from_string(canon_a, canon_b):
    """Compute structural similarity between two canonical strings."""
    try:
        ast_a = _parse_canonical_string(canon_a)
        ast_b = _parse_canonical_string(canon_b)
        return _ast_structural_similarity(ast_a, ast_b)
    except Exception:
        return 0.0


# ===========================================================================
# 1. Similarity computation (3 dimensions)
# ===========================================================================

def _ast_to_string_canonical(ast):
    """Convert AST to string, sorting commutative args deterministically."""
    if ast[0] == 'const':
        v = ast[1]
        return str(int(v)) if abs(v - int(v)) < 1e-12 else repr(float(v))
    if ast[0] == 'var':
        return ast[1]
    name = ast[1]
    child_strs = [_ast_to_string_canonical(ch) for ch in ast[2]]
    if name in ('add', 'mul', 'max', 'min'):
        child_strs.sort()
    return f"{name}({', '.join(child_strs)})"


def _ast_node_set(ast):
    """Extract multiset of all subtree string representations."""
    subtrees = []

    def _walk(node):
        subtrees.append(_ast_to_string_canonical(node))
        if node[0] == 'op':
            for ch in node[2]:
                _walk(ch)

    _walk(ast)
    return subtrees


def _ast_structural_similarity(ast_a, ast_b):
    """Structural similarity between two canonical ASTs.

    Combines:
    - Subtree multiset Jaccard (0.5 weight)
    - Terminal set Jaccard (0.3 weight)
    - Height similarity (0.2 weight)
    """
    subtrees_a = _ast_node_set(ast_a)
    subtrees_b = _ast_node_set(ast_b)
    bag_a = defaultdict(int)
    bag_b = defaultdict(int)
    for s in subtrees_a:
        bag_a[s] += 1
    for s in subtrees_b:
        bag_b[s] += 1

    all_keys = set(bag_a.keys()) | set(bag_b.keys())
    if not all_keys:
        return 1.0
    intersection = sum(min(bag_a.get(k, 0), bag_b.get(k, 0)) for k in all_keys)
    union = sum(max(bag_a.get(k, 0), bag_b.get(k, 0)) for k in all_keys)
    subtree_sim = intersection / union if union > 0 else 0.0

    terms_a, terms_b = set(), set()

    def _collect_terms(node, terms):
        if node[0] == 'var':
            terms.add(node[1])
        elif node[0] == 'op':
            for ch in node[2]:
                _collect_terms(ch, terms)

    _collect_terms(ast_a, terms_a)
    _collect_terms(ast_b, terms_b)
    if terms_a or terms_b:
        terminal_sim = len(terms_a & terms_b) / len(terms_a | terms_b)
    else:
        terminal_sim = 1.0

    def _height(node):
        if node[0] in ('const', 'var'):
            return 1
        if node[0] == 'op':
            return 1 + max(_height(ch) for ch in node[2]) if node[2] else 1
        return 1

    h_a, h_b = _height(ast_a), _height(ast_b)
    max_h = max(h_a, h_b, 1)
    height_sim = 1.0 - abs(h_a - h_b) / max_h

    return 0.5 * subtree_sim + 0.3 * terminal_sim + 0.2 * height_sim


def _get_embeddings(texts, api_key=None, batch_size=5, embed_model=None):
    """Get embedding vectors.

    Supports two backends:
    - api_key: DashScope text-embedding-v3 API (cloud)
    - embed_model: Local Qwen3Embedding instance (from Qwen3-Embedding project)

    Returns list of vectors (or None for failed items).
    """
    if embed_model is not None:
        # Local embedding: batch encode with instructions
        instruction = (
            'Given a web search query, retrieve relevant passages '
            'that answer the query'
        )
        embeddings = [None] * len(texts)
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            try:
                vecs = embed_model.encode(batch, is_query=True, dim=1024)
                import numpy as np
                for j, v in enumerate(vecs):
                    embeddings[i + j] = v.tolist()
            except Exception as e:
                print(f"[Embedding] Local model failed for batch {i}: {e}")
        return embeddings

    if api_key is None:
        return [None] * len(texts)

    import urllib.request
    import json as _json

    embeddings = [None] * len(texts)
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        payload = _json.dumps({
            "model": "text-embedding-v3",
            "input": batch,
            "dimensions": 1024,
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://dashscope.aliyuncs.com/compatible-mode/v1/embeddings",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )

        for attempt in range(3):
            try:
                timeout = 30 + 15 * attempt
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    raw = resp.read().decode("utf-8")
                data = _json.loads(raw)
                for item in data["data"]:
                    embeddings[i + item["index"]] = item["embedding"]
                break
            except Exception as e:
                if attempt == 2:
                    print(f"[Embedding] Failed for batch {i}: {e}")
                else:
                    time.sleep(2 ** attempt)

    return embeddings


def _cosine_similarity(a, b):
    """Cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a < 1e-12 or norm_b < 1e-12:
        return 0.0
    return dot / (norm_a * norm_b)


def _embedding_similarity(emb_a, emb_b):
    """s3: Embedding similarity. Returns cosine similarity in [-1, 1] clipped to [0, 1]."""
    if emb_a is None or emb_b is None:
        return None  # fallback to 0 when one is missing
    return max(0.0, _cosine_similarity(emb_a, emb_b))


def _ast_terminal_set(ast):
    """Extract set of terminal names from AST."""
    terms = set()

    def _walk(node):
        if node[0] == 'var':
            terms.add(node[1])
        elif node[0] == 'op':
            for ch in node[2]:
                _walk(ch)

    _walk(ast)
    return terms


def _ast_contains_erc(ast):
    if ast[0] == 'var':
        return ast[1] == 'ERC'
    if ast[0] == 'op':
        return any(_ast_contains_erc(ch) for ch in ast[2])
    return False


def _ast_node_count(node):
    if node[0] == 'const':
        return 1
    if node[0] == 'var':
        return 1
    if node[0] == 'op':
        return 1 + sum(_ast_node_count(ch) for ch in node[2])
    return 1


def _evaluate_ast(ast, values):
    """Evaluate AST on given terminal values. Returns float or None."""
    if ast[0] == 'const':
        return float(ast[1])
    if ast[0] == 'var':
        return values.get(ast[1], 0.0)
    name, children = ast[1], ast[2]
    child_vals = [_evaluate_ast(ch, values) for ch in children]
    if any(v is None for v in child_vals):
        return None
    if any(not math.isfinite(v) for v in child_vals):
        return None
    try:
        if name == 'add': return child_vals[0] + child_vals[1]
        if name == 'sub': return child_vals[0] - child_vals[1]
        if name == 'mul': return child_vals[0] * child_vals[1]
        if name == 'div':
            return None if abs(child_vals[1]) < 1e-12 else child_vals[0] / child_vals[1]
        if name == 'max': return max(child_vals[0], child_vals[1])
        if name == 'min': return min(child_vals[0], child_vals[1])
        if name == 'abs': return abs(child_vals[0])
        if name == 'sqrt': return math.sqrt(abs(child_vals[0]))
        if name == 'exp': return math.exp(min(child_vals[0], 500))
        if name == 'ln':
            v = abs(child_vals[0]) if child_vals[0] <= 0 else child_vals[0]
            return math.log(v) if v > 0 else 0.0
        if name == 'sin': return math.sin(child_vals[0])
        if name == 'cos': return math.cos(child_vals[0])
        if name == 'neg': return -child_vals[0]
        return None
    except Exception:
        return None


def _compute_behavioral_hash(ast, seed=42):
    """Compute behavioral hash via Monte Carlo rank-vector hashing."""
    import random, hashlib

    if _ast_contains_erc(ast):
        return None
    if ast[0] == 'const':
        return f"BH_CONST_{ast[1]:.6f}"
    if ast[0] == 'var':
        return f"BH_VAR_{ast[1]}"

    terminals_in_tree = set()

    def _collect(node):
        if node[0] == 'var':
            terminals_in_tree.add(node[1])
        elif node[0] == 'op':
            for ch in node[2]:
                _collect(ch)

    _collect(ast)
    terminals_in_tree.discard('ERC')

    if not terminals_in_tree:
        val = _evaluate_ast(ast, {})
        return f"BH_CONST_{val:.6f}" if val is not None else None

    n_samples = 200 if _ast_node_count(ast) <= 7 else 500
    rng = random.Random(seed)
    scores = []
    for i in range(n_samples):
        values = {t: rng.uniform(0, 1000) for t in terminals_in_tree}
        result = _evaluate_ast(ast, values)
        if result is not None and math.isfinite(result):
            scores.append((i, result))

    if len(scores) < 2:
        return None

    # Quantize values to avoid floating-point rank instability
    rounded = [(i, round(v, 6)) for i, v in scores]
    sorted_scores = sorted(rounded, key=lambda x: x[1])
    ranks = [0] * len(sorted_scores)
    for rank, (orig_idx, _) in enumerate(sorted_scores):
        ranks[orig_idx] = rank

    quantized = [r // 10 for r in ranks]
    h = hashlib.md5(f"R:{','.join(map(str, quantized))}".encode()).hexdigest()[:16]
    return f"BH_{h}"


# ===========================================================================
# 2. Similarity matrix construction
# ===========================================================================


def _get_cost(ind):
    """Extract routing cost from an individual, handling DEAP fitness or raw float."""
    fit = ind.fitness
    if isinstance(fit, float):
        return fit
    if hasattr(fit, 'wvalues'):
        w = getattr(fit, 'weights', ())
        if w and w[0] != 0:
            return fit.wvalues[0] / w[0]
        return fit.wvalues[0]
    return float(fit)


def build_similarity_matrix(population, scorer, pset):
    """Build pairwise AST structural similarity matrix for a population.

    Returns a single n×n matrix:
        matrix_s2: AST structural similarity — subtree Jaccard + terminal Jaccard + height

    Args:
        population: list of DEAP individuals
        scorer: LLMBasedInterpretabilityScorer instance (for canonical AST)
        pset: primitive set for AST parsing

    Returns:
        matrix_s2: n×n AST structural similarity matrix
    """
    n = len(population)

    # Extract canonical ASTs
    _import_canonicalizers()
    if _primitive_tree_to_ast is not None:
        asts = []
        for ind in population:
            try:
                _, canon_ast = _get_canonical(ind)
                if canon_ast is not None:
                    asts.append(canon_ast)
                else:
                    asts.append(_primitive_tree_to_ast(ind))
            except Exception:
                asts.append(_primitive_tree_to_ast(ind))
    else:
        asts = None

    # Build structural similarity matrix
    matrix_s2 = [[0.0] * n for _ in range(n)]

    for i in range(n):
        matrix_s2[i][i] = 1.0

    for i in range(n):
        for j in range(i + 1, n):
            s2 = 0.0
            if asts:
                s2 = _ast_structural_similarity(asts[i], asts[j])
            matrix_s2[i][j] = matrix_s2[j][i] = s2

    return matrix_s2


# ===========================================================================
# 3. Co-regularized Spectral Clustering (multi-view)
# ===========================================================================

def cluster_by_spectral(matrix_s2, n_clusters, max_iter=20, seed=42):
    """Single-view Spectral Clustering on AST structural similarity matrix.

    Algorithm:
      - Compute normalized Laplacian L from S
      - Take K smallest eigenvectors → row-normalize
      - K-Means on embedding → cluster labels

    Args:
        matrix_s2: n×n AST structural similarity matrix
        n_clusters: K — target number of clusters
        max_iter: unused, kept for backward compatibility
        seed: random seed for reproducibility

    Returns:
        clusters: list of lists, each containing individual indices
    """
    import numpy as np

    S = np.array(matrix_s2, dtype=float)
    n = S.shape[0]

    if n <= n_clusters:
        return [[i] for i in range(n)]
    if n <= 1:
        return [[0]] if n == 1 else []

    # Normalized Laplacian: L = I - D^{-1/2} S D^{-1/2}
    D = np.diag(S.sum(axis=1))
    D_inv_sqrt = np.zeros_like(D)
    for i in range(n):
        if D[i, i] > 1e-12:
            D_inv_sqrt[i, i] = 1.0 / np.sqrt(D[i, i])
    L = np.eye(n) - D_inv_sqrt @ S @ D_inv_sqrt
    L = 0.5 * (L + L.T)  # symmetrize

    # Eigendecomposition: smallest eigenvalues
    _, V = np.linalg.eigh(L)
    V = V[:, :n_clusters]

    # Row-normalize
    norms = np.linalg.norm(V, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    V = V / norms

    # K-Means
    from sklearn.cluster import KMeans
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed, max_iter=300)
    labels = km.fit_predict(V)

    clusters = [[] for _ in range(n_clusters)]
    for i in range(n):
        clusters[labels[i]].append(i)
    return [c for c in clusters if c]  # remove empty clusters


# ===========================================================================
# 4. Representative-based Fitness2 evaluation with proxy model
# ===========================================================================

def _ast_eq(a, b):
    if a[0] != b[0] or a[1] != b[1]:
        return False
    if a[0] == 'op':
        if len(a[2]) != len(b[2]):
            return False
        return all(_ast_eq(ac, bc) for ac, bc in zip(a[2], b[2]))
    return True


def _ast_to_string(ast):
    """Convert AST to a prefix expression string."""
    if ast[0] == 'const':
        return str(int(ast[1])) if isinstance(ast[1], float) and abs(ast[1] - int(ast[1])) < 1e-12 else str(ast[1])
    if ast[0] == 'var':
        return ast[1]
    return f"({' '.join([ast[1]] + [_ast_to_string(ch) for ch in ast[2]])})"


def _simplify_ast(node):
    """Recursively simplify an AST by evaluating constant subexpressions and
    applying algebraic identities."""
    if node[0] != 'op':
        return node
    name = node[1]
    children = [_simplify_ast(ch) for ch in node[2]]

    if all(ch[0] == 'const' for ch in children):
        vals = [ch[1] for ch in children]
        try:
            if name == 'add': result = sum(vals)
            elif name == 'mul':
                result = 1.0
                for v in vals: result *= v
            elif name == 'sub': result = vals[0] - vals[1]
            elif name == 'div': result = vals[0] / vals[1] if abs(vals[1]) > 1e-12 else float('inf')
            elif name == 'max': result = max(vals)
            elif name == 'min': result = min(vals)
            else: return ('op', name, children)
            if not math.isfinite(result):
                return ('op', name, children)
            return ('const', result)
        except Exception:
            return ('op', name, children)

    if name == 'add':
        children = [ch for ch in children if not (ch[0] == 'const' and ch[1] == 0)]
        if not children: return ('const', 0)
        if len(children) == 1: return children[0]
        return ('op', 'add', children)
    elif name == 'mul':
        non_one = [ch for ch in children if not (ch[0] == 'const' and abs(ch[1] - 1.0) < 1e-12)]
        if any(ch[0] == 'const' and abs(ch[1]) < 1e-12 for ch in children):
            return ('const', 0)
        if not non_one: return ('const', 1)
        if len(non_one) == 1: return non_one[0]
        return ('op', 'mul', non_one)
    elif name == 'sub':
        if children[1][0] == 'const' and abs(children[1][1]) < 1e-12:
            return children[0]
        if _ast_eq(children[0], children[1]):
            return ('const', 0)
        return ('op', 'sub', children)
    elif name in ('max', 'min'):
        if _ast_eq(children[0], children[1]):
            return children[0]
        return ('op', name, children)
    elif name == 'div':
        if children[1][0] == 'const' and abs(children[1][1] - 1.0) < 1e-12:
            return children[0]
        if _ast_eq(children[0], children[1]):
            return ('const', 1)
        return ('op', 'div', children)

    return ('op', name, children)


def _build_balanced_tree(op_name, leaves):
    if len(leaves) == 1:
        return leaves[0]
    if len(leaves) == 2:
        return ('op', op_name, leaves)
    mid = len(leaves) // 2
    left = _build_balanced_tree(op_name, leaves[:mid])
    right = _build_balanced_tree(op_name, leaves[mid:])
    return ('op', op_name, [left, right])


def _flatten_associative(node):
    if node[0] != 'op' or node[1] not in ('add', 'mul'):
        return node
    name = node[1]
    flat_children = []
    for ch in node[2]:
        if ch[0] == 'op' and ch[1] == name:
            flat_children.extend(ch[2])
        else:
            flat_children.append(ch)
    if len(flat_children) <= 2:
        return ('op', name, flat_children)
    return _build_balanced_tree(name, flat_children)


def _combine_like_terms(node):
    if node[0] != 'op' or node[1] != 'add':
        return node
    const_sum = 0.0
    grouped = defaultdict(list)
    for ch in node[2]:
        if ch[0] == 'const':
            const_sum += ch[1]
        else:
            grouped[_ast_to_string_canonical(ch)].append(ch)
    new_children = []
    if abs(const_sum) > 1e-12:
        new_children.append(('const', const_sum))
    for key, chs in grouped.items():
        if len(chs) > 1:
            new_children.append(('op', 'mul', [('const', float(len(chs))), chs[0]]))
        else:
            new_children.append(chs[0])
    if not new_children:
        return ('const', 0)
    if len(new_children) == 1:
        return new_children[0]
    return ('op', 'add', new_children)


def _normalize_scalar_invariance(node):
    if node[0] == 'op' and node[1] == 'mul' and len(node[2]) == 2:
        a, b = node[2]
        if a[0] == 'const' and a[1] > 0:
            return b
        if b[0] == 'const' and b[1] > 0:
            return a
    return node


def _normalize_commutative_order(node):
    if node[0] != 'op':
        return node
    name, children = node[1], [_normalize_commutative_order(ch) for ch in node[2]]
    if name in ('add', 'mul', 'max', 'min'):
        children.sort(key=_ast_to_string)
        if name in ('add', 'mul') and len(children) > 2:
            return _flatten_associative(('op', name, children))
        return ('op', name, children)
    return ('op', name, children)


def _canonicalize_ast(ind_ast):
    """Apply the same simplification pipeline as _individual_canonical_enhanced."""
    prev = ind_ast
    for _ in range(5):
        ind_ast = _simplify_ast(ind_ast)
        ind_ast = _flatten_associative(ind_ast)
        ind_ast = _combine_like_terms(ind_ast)
        if _ast_eq(ind_ast, prev):
            break
        prev = ind_ast
    ind_ast = _normalize_scalar_invariance(ind_ast)
    ind_ast = _normalize_commutative_order(ind_ast)
    return ind_ast


def _ast_height(node):
    """Height of AST node (leaf = 1)."""
    if node[0] == 'op':
        return 1 + max(_ast_height(ch) for ch in node[2])
    return 1


def _extract_struct_features(individual):
    """Extract 6 structural features from a DEAP individual, based on the
    canonicalized (simplified) AST rather than the raw tree.

    Returns (p1, p2, p3, p4, p5, p6):
        p1: total nodes (excl. constants)
        p2: terminal (var) nodes count
        p3: function (op) nodes count
        p4: unique terminal types (deduplicated)
        p5: unique function types (deduplicated)
        p6: tree height
    """
    _import_canonicalizers()
    try:
        if _primitive_tree_to_ast is not None:
            raw_ast = _primitive_tree_to_ast(individual)
            ast = _canonicalize_ast(raw_ast)
        else:
            _, ast = _get_canonical(individual)
    except Exception:
        # Fallback: use raw DEAP individual
        p1 = len(individual)
        p2 = 0
        p3 = 0
        term_set = set()
        func_set = set()
        for node in individual:
            name = getattr(node, "name", "")
            arity = getattr(node, "arity", 0)
            if arity == 0:
                p2 += 1
                term_set.add(name)
            else:
                p3 += 1
                func_set.add(name)
        return (p1, p2, p3, len(term_set), len(func_set), individual.height)

    # Count from canonical AST
    def _count_vars(node):
        if node[0] == 'var': return 1
        if node[0] == 'op': return sum(_count_vars(ch) for ch in node[2])
        return 0

    def _count_ops(node):
        if node[0] == 'op':
            return 1 + sum(_count_ops(ch) for ch in node[2])
        return 0

    def _collect_terms(node):
        result = set()
        if node[0] == 'var': result.add(node[1])
        elif node[0] == 'op':
            for ch in node[2]: result |= _collect_terms(ch)
        return result

    def _collect_funcs(node):
        result = set()
        if node[0] == 'op':
            result.add(node[1])
            for ch in node[2]: result |= _collect_funcs(ch)
        return result

    p1 = _ast_node_count(ast)
    p2 = _count_vars(ast)
    p3 = _count_ops(ast)
    p4 = len(_collect_terms(ast))
    p5 = len(_collect_funcs(ast))
    p6 = _ast_height(ast)
    return (p1, p2, p3, p4, p5, p6)


def _learn_proxy_model(rep_features_list, rep_fitness2_list):
    """Learn a linear proxy model: F_est = w0 + w1*p1 + ... + w6*p6.

    Uses ridge regression from representatives' (features, F2) pairs.
    Falls back to a simple heuristic if too few samples.
    """
    n = len(rep_features_list)
    if n < 2:
        # Not enough data: return a simple heuristic based on p1 (total nodes)
        def _heuristic(feats):
            p1 = feats[0]
            if p1 <= 3: return 0.0
            if p1 <= 7: return 10.0
            if p1 <= 15: return 25.0
            if p1 <= 30: return 45.0
            return 70.0
        return _heuristic

    # Build design matrix: [1, p1, p2, p3, p4, p5, p6]
    X = [[1.0] + list(f) for f in rep_features_list]
    y = rep_fitness2_list
    n_feat = len(X[0])  # 7 (intercept + 6 features)

    # Ridge regression: w = (X^T X + lambda*I)^(-1) X^T y
    lam = 1.0  # regularization strength

    # X^T X
    XtX = [[0.0] * n_feat for _ in range(n_feat)]
    for i in range(n_feat):
        for j in range(n_feat):
            s = 0.0
            for k in range(n):
                s += X[k][i] * X[k][j]
            XtX[i][j] = s + (lam if i == j else 0.0)

    # X^T y
    Xty = [0.0] * n_feat
    for i in range(n_feat):
        for k in range(n):
            Xty[i] += X[k][i] * y[k]

    # Solve linear system via Gaussian elimination
    w = _solve_linear_system(XtX, Xty)
    if w is None:
        # Singular: fall back to mean
        mean_f2 = sum(y) / n
        return lambda feats: mean_f2

    def _predict(feats):
        val = w[0]
        for i in range(1, n_feat):
            val += w[i] * feats[i - 1]
        return max(0.0, min(100.0, val))

    return _predict


def _solve_linear_system(A, b):
    """Solve Ax = b via Gaussian elimination with partial pivoting. Returns x or None."""
    n = len(b)
    # Augmented matrix
    mat = [row[:] + [b[i]] for i, row in enumerate(A)]

    for col in range(n):
        # Partial pivoting
        max_row = col
        max_val = abs(mat[col][col])
        for row in range(col + 1, n):
            if abs(mat[row][col]) > max_val:
                max_val = abs(mat[row][col])
                max_row = row
        mat[col], mat[max_row] = mat[max_row], mat[col]

        pivot = mat[col][col]
        if abs(pivot) < 1e-12:
            return None  # Singular

        for row in range(col + 1, n):
            factor = mat[row][col] / pivot
            for j in range(col, n + 1):
                mat[row][j] -= factor * mat[col][j]

    # Back substitution
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = mat[i][n]
        for j in range(i + 1, n):
            x[i] -= mat[i][j] * x[j]
        x[i] /= mat[i][i]
    return x


def evaluate_fitness2_by_clustering(population, scorer, behavior_instance,
                                     matrix_s2, clusters,
                                     archive=None,
                                     api_key=None, k_representatives=1,
                                     k_knn=3, k_candidates=20,
                                     canon_map=None,
                                     permanent_f2_cache=None,
                                     permanent_llm_canons=None):
    """Evaluate Fitness2 via clustering + representative LLM + proxy model.

    Uses only AST structural similarity (matrix_s2) for clustering and correction.
    A global archive of LLM-scored individuals enriches proxy training and
    similarity-based correction.

    ┌──────────────────────────────────────────────────────────────────────┐
    │  Phase 1: Representative selection + LLM scoring                     │
    │    For each cluster:                                                 │
    │      ① Fitness1 ascending → top-K candidates (best cost)             │
    │      ② From candidates, pick N most central (highest avg S)          │
    │      ③ LLM evaluates representatives → true Fitness2                 │
    │                                                                      │
    │  Phase 2: Learn ONE shared proxy model L from ALL reps + ALL archive │
    │    F_est = L(p1, p2, p3, p4, p5, p6)                                 │
    │                                                                      │
    │  Phase 3: Estimate Fitness2 for non-representatives                  │
    │    F2(i) = F_est(i) + sim_max × (best_f2 - F_est(i))                 │
    │    where sim_max = max S(i, s) over reps + archive                   │
    └──────────────────────────────────────────────────────────────────────┘

    Args:
        population: list of DEAP individuals
        scorer: LLMBasedInterpretabilityScorer
        behavior_instance: instance for behavior data extraction
        matrix_s2: n×n AST structural similarity matrix
        clusters: list of clusters (lists of indices)
        archive: F2_LLM_ARCHIVE dict {canon_str: {f2, features, ast}}
        api_key: DashScope API key
        k_representatives: N — number of representatives per cluster
        k_knn: unused, kept for backward compatibility
        k_candidates: K — pool size for representative selection
        canon_map: optional dict {id(individual): canonical_str} for consistent keying
        permanent_f2_cache: dict {canon_str: f2_value} from previous generations.
        permanent_llm_canons: set {canon_str} subset of permanent_f2_cache keys that
            were originally scored by LLM (not Proxy).

    Returns:
        interp_cache: dict of {canonical_str: fitness2_value}
        stats: dict with clustering statistics
        llm_canons: set of canonical strings scored by LLM this generation
    """
    # Use structural similarity directly (no averaging with cost sim)
    sim_matrix = matrix_s2
    n = len(population)

    interp_cache = {}
    total_llm_calls = 0
    total_knn_preds = 0
    llm_canons = set()
    llm_scored_indices = set()
    llm_scored_canons = set()

    # Ensure canonicalization helpers are available
    _import_canonicalizers()

    # Local fallback: extract behavioral data for an individual
    def _extract_behavior_data_local(ind, behavior_instance):
        try:
            from evaluate import evaluate_individual
            evaluate_individual(deepcopy(ind), behavior_instance)
        except Exception:
            pass
        return {"decision_entropy": 0.5, "score_consistency": 0.5}

    if permanent_f2_cache is None:
        permanent_f2_cache = {}
    if permanent_llm_canons is None:
        permanent_llm_canons = set()
    if archive is None:
        archive = {}

    n_clusters = len(clusters)

    # ──────────────────────────────────────────────────────────────────
    # Phase 1: Select reps per cluster + LLM score them
    # ──────────────────────────────────────────────────────────────────
    # Global collections for proxy training:
    all_rep_feats = []     # structural features of all representatives
    all_rep_f2s = []       # F2 values of all representatives
    all_rep_f2 = {}        # {pop_idx: F2_value} for similarity correction
    # Track non-representatives globally: {pop_idx: cluster_index}
    all_non_rep = {}

    for ci, cluster in enumerate(clusters):
        cluster_size = len(cluster)
        n_rep = min(k_representatives, cluster_size)
        print(f"  [Cluster {ci + 1}/{n_clusters}] "
              f"{cluster_size} individuals, "
              f"selecting {n_rep} representative(s)")

        # Stage 1: Representative selection (two-stage)
        # ① Fitness1 ascending → top-K candidates (lowest cost)
        candidates = sorted(cluster, key=lambda idx: _get_cost(population[idx]))
        top_k = min(k_candidates, len(candidates))
        candidates = candidates[:top_k]

        # ② From candidates, pick N most central by average S to all cluster members
        if len(candidates) > n_rep:
            centrality = []
            for cidx in candidates:
                avg_sim = sum(sim_matrix[cidx][midx] for midx in cluster) / cluster_size
                centrality.append((cidx, avg_sim))
            centrality.sort(key=lambda x: x[1], reverse=True)
            rep_indices = [c for c, _ in centrality[:n_rep]]
        else:
            rep_indices = candidates

        non_rep_indices = [idx for idx in cluster if idx not in rep_indices]
        for idx in non_rep_indices:
            all_non_rep[idx] = ci

        # Stage 2: LLM evaluates representatives → true Fitness2
        for idx in rep_indices:
            ind = population[idx]
            if canon_map is not None and id(ind) in canon_map:
                canon_str = canon_map[id(ind)]
            else:
                try:
                    canon_str, _ = _get_canonical(ind)
                except Exception:
                    canon_str = str(ind)

            # Rule 1: LLM-scored in this gen (earlier cluster) → reuse, skip
            if canon_str in interp_cache and canon_str in llm_scored_canons:
                f2 = interp_cache[canon_str]
                all_rep_f2[idx] = f2
                all_rep_feats.append(_extract_struct_features(ind))
                all_rep_f2s.append(f2)
                llm_scored_indices.add(idx)
                continue

            # Rule 2: LLM-scored in a previous generation → reuse, skip
            if canon_str in permanent_llm_canons:
                fitness2 = permanent_f2_cache[canon_str]
                interp_cache[canon_str] = fitness2
                all_rep_f2[idx] = fitness2
                all_rep_feats.append(_extract_struct_features(ind))
                all_rep_f2s.append(fitness2)
                llm_scored_indices.add(idx)
                llm_scored_canons.add(canon_str)
                continue

            # Rule 3: Not LLM-scored (Proxy-only or never scored) → call LLM
            try:
                behavior_data = _extract_behavior_data_local(ind, behavior_instance)
            except Exception:
                behavior_data = {"decision_entropy": 0.5, "consistency_score": 0.5}

            full_result = scorer.get_full_result(ind, behavior_data, canonical_text=canon_str)
            fitness2 = full_result["final_complexity"]
            # Store full LLM result on individual for later retrieval (Pareto export)
            ind._llm_full_result = full_result
            total_llm_calls += 1
            llm_canons.add(canon_str)
            llm_scored_indices.add(idx)
            interp_cache[canon_str] = fitness2
            llm_scored_canons.add(canon_str)
            all_rep_f2[idx] = fitness2
            all_rep_feats.append(_extract_struct_features(ind))
            all_rep_f2s.append(fitness2)
            f1 = _get_cost(ind)
            print(f"    [LLM] Individual {idx}: {canon_str[:50]} -> F1={f1:.2f}, F2={fitness2:.2f}")

    # ──────────────────────────────────────────────────────────────────
    # Phase 2: Learn ONE shared proxy model from ALL reps + ALL archive
    # ──────────────────────────────────────────────────────────────────
    archive_feats = []
    archive_f2s = []
    for akey, aentry in archive.items():
        archive_feats.append(aentry["features"])
        archive_f2s.append(aentry["f2"])

    all_train_feats = all_rep_feats + archive_feats
    all_train_f2s = all_rep_f2s + archive_f2s
    print(f"  [Proxy] Training shared model: "
          f"{len(all_rep_feats)} reps + {len(archive_feats)} archive = "
          f"{len(all_train_feats)} samples")
    proxy_model = _learn_proxy_model(all_train_feats, all_train_f2s)

    # ──────────────────────────────────────────────────────────────────
    # Phase 3: Estimate F2 for non-representatives using shared proxy
    #          + similarity correction from reps + archive
    # ──────────────────────────────────────────────────────────────────
    for idx in all_non_rep:
        ind = population[idx]
        if canon_map is not None and id(ind) in canon_map:
            canon_str = canon_map[id(ind)]
        else:
            try:
                canon_str, _ = _get_canonical(ind)
            except Exception:
                canon_str = str(ind)

        # Rule 1: LLM-scored in this gen → skip
        if canon_str in interp_cache and canon_str in llm_scored_canons:
            llm_scored_indices.add(idx)
            total_knn_preds += 1
            continue

        # Rule 2: LLM-scored in a previous generation → skip, reuse permanent value
        if canon_str in permanent_llm_canons:
            fitness2 = permanent_f2_cache[canon_str]
            interp_cache[canon_str] = fitness2
            llm_scored_indices.add(idx)
            llm_scored_canons.add(canon_str)
            continue

        # Rule 3: Not LLM-scored → predict with proxy + similarity correction
        feats = _extract_struct_features(ind)
        f_est = proxy_model(feats)

        # Find the single most similar individual from reps + archive
        best_sim = -1.0
        best_f2 = f_est  # default to proxy estimate if no match

        # (a) current-gen representatives
        for rep_idx, rep_f2 in all_rep_f2.items():
            s = sim_matrix[idx][rep_idx]
            if s > best_sim:
                best_sim = s
                best_f2 = rep_f2

        # (b) archive individuals (cross-generation, parsed from canonical string)
        for akey, aentry in archive.items():
            s = _ast_structural_similarity_from_string(canon_str, akey)
            if s > best_sim:
                best_sim = s
                best_f2 = aentry["f2"]

        if best_sim >= 0:
            pred_fitness2 = f_est + best_sim * (best_f2 - f_est)
        else:
            pred_fitness2 = f_est
        pred_fitness2 = max(0.0, min(100.0, pred_fitness2))

        interp_cache[canon_str] = pred_fitness2
        total_knn_preds += 1

        f1 = _get_cost(ind)
        print(f"    [Proxy] Individual {idx}: {canon_str[:50]} -> "
              f"F1={f1:.2f}, F_est={f_est:.2f}, F2={pred_fitness2:.2f}")

    stats = {
        "n_clusters": len(clusters),
        "n_llm_calls": total_llm_calls,
        "n_knn_preds": total_knn_preds,
        "total_evaluated": total_llm_calls + total_knn_preds,
        "llm_scored_indices": llm_scored_indices,
    }

    return interp_cache, stats, llm_canons


# ===========================================================================
# 5. Main integration function
# ===========================================================================

def evaluate_population_fitness2(population, scorer, behavior_instance,
                                  pset, api_key=None,
                                  n_clusters=5, k_representatives=1, k_knn=3,
                                  archive=None):
    """Complete pipeline: single-view similarity -> spectral clustering
    -> representative evaluation -> proxy interpolation with archive.

    Args:
        population: list of DEAP individuals (must have Fitness1 set)
        scorer: LLMBasedInterpretabilityScorer
        behavior_instance: instance for behavior data extraction
        pset: primitive set for AST parsing
        api_key: DashScope API key
        n_clusters: K — target number of clusters for spectral clustering
        k_representatives: representatives per cluster
        k_knn: unused, kept for backward compatibility
        archive: F2_LLM_ARCHIVE dict {canon_str: {f2, features, ast}}

    Returns:
        interp_cache: dict of {canonical_str: fitness2_value}
        stats: dict with clustering statistics
    """
    print(f"\n[Clustering] Starting population clustering...")
    print(f"  Population size: {len(population)}")
    print(f"  Target clusters: {n_clusters}")
    print(f"  Representatives per cluster: {k_representatives}")

    t0 = time.time()

    # Step 1: Build structural similarity matrix
    print("  [Clustering] Building structural similarity matrix (AST)...")
    matrix_s2 = build_similarity_matrix(population, scorer, pset)
    t1 = time.time()
    print(f"  [Clustering] Similarity matrix built in {t1 - t0:.2f}s")

    # Step 2: Single-view Spectral Clustering
    print(f"  [Clustering] Spectral Clustering (K={n_clusters})...")
    clusters = cluster_by_spectral(matrix_s2, n_clusters=n_clusters)
    print(f"  [Clustering] Found {len(clusters)} clusters")
    for ci, c in enumerate(clusters):
        print(f"    Cluster {ci + 1}: {len(c)} individuals")
    t2 = time.time()

    # Step 3: Evaluate representatives + proxy interpolation
    print("  [Clustering] Evaluating representatives...")
    interp_cache, stats, _ = evaluate_fitness2_by_clustering(
        population, scorer, behavior_instance, matrix_s2,
        clusters, archive=archive,
        api_key=api_key, k_representatives=k_representatives,
        k_knn=k_knn,
    )
    t3 = time.time()

    print(f"\n[Clustering] Complete in {t3 - t0:.2f}s")
    print(f"  Clusters: {stats['n_clusters']}")
    print(f"  LLM calls: {stats['n_llm_calls']}")
    print(f"  Proxy predictions: {stats['n_knn_preds']}")
    print(f"  LLM calls saved: {len(population) - stats['n_llm_calls']} "
          f"({100 * (1 - stats['n_llm_calls'] / max(1, len(population))):.1f}%)")

    return interp_cache, stats
