"""Extra configuration for main_manual_interpretability.py.

Parameters specific to the manual interpretability pipeline
(not covered by configure_parameters.py).
"""

import configure_parameters as _cfgp


# ---------------------------------------------------------------------------
# LLM & scoring
# ---------------------------------------------------------------------------
# LLM API key for interpretability scoring
API_KEY = "sk-5c5aca8589834b60a7e534857556fa81"

# Scoring mode: "rule_based" (all algorithmic) | "hybrid" (D1/D4/D5/D7 code, rest LLM)
SCORING_MODE = "hybrid"

# ★ Set to False to skip all LLM calls and use pure rule-based scoring.
#   Useful for quick clustering/structural-only analysis.
USE_LLM = True



# Interpretability score range
INTERPRETABILITY_MIN = 0.0
INTERPRETABILITY_MAX = 100.0

# Convenience aliases (mirror configure_parameters.py so _cfgx.SEED works)
SEED = _cfgp.seed
PROBLEM = _cfgp.problem
PATH = _cfgp.data_path

# ---------------------------------------------------------------------------
# AST canonicalization
# ---------------------------------------------------------------------------
# ★ Whether to run the 6-step AST canonicalization pipeline before clustering.
#   True  → constant folding, commutative sort, terminal substitution, etc.
#   False → use raw tree structure directly; relies on BH + terminal_set
#            + cost for clustering equivalence
USE_CANONICAL = True

# ---------------------------------------------------------------------------
# Manual GP tree input (function-call syntax)
# ---------------------------------------------------------------------------
GP_TREES = [
    # A1. Pure CFH (baseline)
    "add(mul(CFH, SC), mul(DC, SC))",
    "mul(SC, add(CFH, DC))",
    "CFH",
    "add(add(add(CFH, CFH), CFH), CFH)",
    "max(CFH, CFH)",
    "min(CFH, CFH)",
    "max(DC, SC)",
    "max(SC, DC)",
    "min(DC, SC)",
    "min(SC, DC)",
    "add(SC, DC)",
    "mul(SC, DC)",
    "add(mul(max(div(div(DC, SC), mul(CTT1, CTD)), max(sub(DC, CR), add(CTT1, DC))), max(min(max(CR, DC), add(CFD, ERC)), mul(div(CFR1, CFD), mul(FUT, FRT)))), max(min(sub(max(SC, SC), max(DC, CFH)), max(add(CFD, FUT), min(ERC, ERC))), add(max(div(FRT, CTD), min(FRT, CFD)), sub(max(CTD, CTD), sub(CFR1, SC)))))"
]

# ---------------------------------------------------------------------------
# Clustering pipeline (representative LLM + proxy model)
# ---------------------------------------------------------------------------
# Co-regularized Spectral Clustering (multi-view: cost + AST structure)
CLUSTER_K = 5               # K — target number of clusters
CLUSTER_K_CANDIDATES = 20   # K — top-K candidates filtered by Fitness1 (cost)
CLUSTER_K_REP = 1           # N — number of representatives per cluster (N ≤ K)

# ---------------------------------------------------------------------------
# Final Pareto front refinement (post-evolution LLM re-evaluation)
# ---------------------------------------------------------------------------
# ★ Number of non-dominated fronts to aggregate before final LLM scoring.
#   The last-generation population is sorted into fronts (Front 1, 2, ...).
#   Top-P fronts are merged, each individual gets a true LLM Fitness2,
#   then the final Pareto front is recomputed from the merged set.
#   Set to 1 to only use Front 1 (default).
PARETO_FRONT_LEVELS = 2

# ---------------------------------------------------------------------------
# Local Qwen3-Embedding
# ---------------------------------------------------------------------------
EMBED_MODEL_PATH = "/Users/chenlong/.cache/modelscope/hub/models/Qwen/Qwen3-Embedding-0.6B"




