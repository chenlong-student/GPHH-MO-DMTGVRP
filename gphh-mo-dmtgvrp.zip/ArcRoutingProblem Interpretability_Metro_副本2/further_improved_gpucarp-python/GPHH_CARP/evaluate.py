from deap import gp
import configure_parameters
import functions
import hashlib
import random
import math
from copy import deepcopy
import utils

_TERMINAL_INDEX = {
    "CFH": 0,
    "CFD": 1,
    "CFR1": 2,
    "CTT1": 3,
    "CTD": 4,
    "CR": 5,
    "DEM": 6,
    "DEM1": 7,
    "DC": 8,
    "FULL": 9,
    "FRT": 10,
    "FUT": 11,
    "RQ": 12,
    "RQ1": 13,
    "SC": 14,
    "ERC": 15,
}

_PRIMITIVE_FUNC = {
    "add": functions.add,
    "sub": functions.sub,
    "mul": functions.mul,
    "div": functions.div,
    "max": functions.max,
    "min": functions.min,
    "if": functions.if_func,
    "sin": functions.sin,
    "cos": functions.cos,
    "exp": functions.exp,
    "ln": functions.ln,
    "neg": functions.neg,
    "sqrt": functions.sqrt,
    "abs": functions.abs,
}


def _individual_signature(individual):
    signature = getattr(individual, "_fast_eval_signature", None)
    current_signature = str(individual)

    if signature != current_signature:
        individual._fast_eval_signature = current_signature
        individual._fast_eval_program = None

    return current_signature




def _get_individual_erc_seed(individual):
    """Get (and cache) a deterministic ERC seed for this individual.

    The seed is derived deterministically from the individual's tree structure
    + the global seed, so it is identical regardless of evaluation order,
    parallel worker assignment, or run number.
    """
    cached = getattr(individual, "_erc_seed_cached", None)
    if cached is not None:
        return cached

    base = configure_parameters.erc_seed
    if base is None:
        base = 42

    # Deterministic hash of (base_seed, individual_tree) — uses hashlib to
    # avoid PYTHONHASHSEED randomization across process launches.
    key = f"{base}:{str(individual)}".encode("utf-8")
    h = int(hashlib.sha256(key).hexdigest(), 16)
    seed = (h % (2**31 - 2)) + 1  # in [1, 2**31 - 1]
    individual._erc_seed_cached = seed
    return seed


def _compile_program(individual):
    current_signature = _individual_signature(individual)
    cached_program = getattr(individual, "_fast_eval_program", None)

    if cached_program is not None:
        return cached_program

    def walk(index):
        node = individual[index]
        cursor = index + 1
        program = []

        if isinstance(node, gp.Primitive):
            for _ in range(node.arity):
                child_program, cursor = walk(cursor)
                program.extend(child_program)
            program.append(("prim", _PRIMITIVE_FUNC[node.name], node.arity))
            return program, cursor

        node_name = getattr(node, "name", None)
        if node_name in _TERMINAL_INDEX:
            program.append(("term", _TERMINAL_INDEX[node_name]))
            return program, cursor

        value = getattr(node, "value", node)
        if callable(value):
            raise TypeError(f"Unsupported callable terminal: {node_name}")
        program.append(("const", float(value)))
        return program, cursor

    program, next_index = walk(0)
    if next_index != len(individual):
        raise ValueError("Failed to compile the full GP tree")

    individual._fast_eval_signature = current_signature
    individual._fast_eval_program = tuple(program)
    return individual._fast_eval_program


def _execute_program(program, context):
    stack = []

    for instruction in program:
        op_type = instruction[0]

        if op_type == "const":
            stack.append(instruction[1])
            continue

        if op_type == "term":
            stack.append(context[instruction[1]])
            continue

        func = instruction[1]
        arity = instruction[2]

        if arity == 1:
            stack.append(func(stack.pop()))
            continue

        if arity == 2:
            right = stack.pop()
            left = stack.pop()
            stack.append(func(left, right))
            continue

        third = stack.pop()
        second = stack.pop()
        first = stack.pop()
        stack.append(func(first, second, third))

    return stack[-1]


def _build_reverse_index(required_arcs):
    arc_key_to_indices = {}
    for idx, arc in enumerate(required_arcs):
        key = (arc.start_vertex, arc.end_vertex, arc.demanda_original, arc.coste_original)
        arc_key_to_indices.setdefault(key, []).append(idx)

    reverse_index = []
    for idx, arc in enumerate(required_arcs):
        reverse_key = (
            arc.end_vertex,
            arc.start_vertex,
            getattr(arc.reverse_arc, "demanda_original", arc.demanda_original),
            getattr(arc.reverse_arc, "coste_original", arc.coste_original),
        )

        candidates = arc_key_to_indices.get(reverse_key)
        if not candidates:
            raise KeyError(
                f"Cannot locate reverse arc for ({arc.start_vertex}->{arc.end_vertex}, "
                f"demand={arc.demanda_original}, cost={arc.coste_original})"
            )

        reverse_idx = next((candidate for candidate in candidates if candidate != idx), candidates[0])
        reverse_index.append(reverse_idx)

    return tuple(reverse_index)


def _build_inter_arc_distance(start_vertices, end_vertices, od):
    count = len(start_vertices)
    return tuple(
        tuple(od[end_vertices[i]][start_vertices[j]] for j in range(count))
        for i in range(count)
    )


def _get_seed_meta(instance):
    meta = getattr(instance, "_fast_eval_meta", None)
    if meta is not None:
        return meta

    required_arcs = tuple(instance.seed_requiredArc)
    start_vertices = tuple(arc.start_vertex for arc in required_arcs)
    end_vertices = tuple(arc.end_vertex for arc in required_arcs)
    demands = tuple(getattr(arc, "demanda", 0.0) for arc in required_arcs)
    costs = tuple(arc.coste for arc in required_arcs)
    od = instance.seedGraphConnected
    depot = instance.deposito

    meta = {
        "required_arcs": required_arcs,
        "reverse_index": _build_reverse_index(required_arcs),
        "start_vertices": start_vertices,
        "end_vertices": end_vertices,
        "demands": demands,
        "costs": costs,
        "arc_to_depot": tuple(od[depot][start_vertex] for start_vertex in start_vertices),
        "depot_to_arc": tuple(od[end_vertex][depot] for end_vertex in end_vertices),
        "deadheading": tuple(od[start][end] for start, end in zip(start_vertices, end_vertices)),
        "inter_arc_distance": _build_inter_arc_distance(start_vertices, end_vertices, od),
        "vehicle_capacity": tuple(vehicle.capacity for vehicle in instance.vehicles),
        "vehicle_positions": tuple(vehicle.current_position for vehicle in instance.vehicles),
        "vehicle_costs": tuple(vehicle.total_cost for vehicle in instance.vehicles),
        "vehicle_remaining": tuple(getattr(vehicle, "remain_capacity", vehicle.capacity) for vehicle in instance.vehicles),
        "depot": depot,
        "od": od,
        "task_num": max(1, len(required_arcs)),
        "problem": configure_parameters.problem,
    }

    instance._fast_eval_meta = meta
    return meta


def _active_state(count):
    return list(range(count)), list(range(count))


def _remove_active_arc(active_arcs, active_pos, arc_idx):
    pos = active_pos[arc_idx]
    if pos == -1:
        return

    last_idx = active_arcs.pop()
    active_pos[arc_idx] = -1

    if pos == len(active_arcs):
        return

    active_arcs[pos] = last_idx
    active_pos[last_idx] = pos


def _compute_candidate_neighbor(active_arcs, demands, inter_arc_distance, candidate_idx):
    best_dem_dist = float("inf")
    best_ctt_dist = float("inf")
    best_dem = 0.0
    best_ctt = 0.0

    for other_idx in active_arcs:
        if other_idx == candidate_idx:
            continue

        ctt_dist = inter_arc_distance[candidate_idx][other_idx]
        if ctt_dist < best_ctt_dist:
            best_ctt_dist = ctt_dist
            best_ctt = ctt_dist

        dem_dist = inter_arc_distance[other_idx][candidate_idx]
        if dem_dist < best_dem_dist:
            best_dem_dist = dem_dist
            best_dem = demands[other_idx]

    return best_dem, best_ctt


def _precompute_candidate_neighbors(active_arcs, demands, inter_arc_distance):
    dem1_map = {}
    ctt1_map = {}

    for arc_idx in active_arcs:
        best_dem_dist = float("inf")
        best_ctt_dist = float("inf")
        best_dem = 0.0
        best_ctt = 0.0
        row = inter_arc_distance[arc_idx]

        for other_idx in active_arcs:
            if other_idx == arc_idx:
                continue

            ctt_dist = row[other_idx]
            if ctt_dist < best_ctt_dist:
                best_ctt_dist = ctt_dist
                best_ctt = ctt_dist

            dem_dist = inter_arc_distance[other_idx][arc_idx]
            if dem_dist < best_dem_dist:
                best_dem_dist = dem_dist
                best_dem = demands[other_idx]

        dem1_map[arc_idx] = best_dem
        ctt1_map[arc_idx] = best_ctt

    return dem1_map, ctt1_map


def _compute_route_features(vehicle_idx, arc_idx, meta, current_positions, remaining_capacity):
    od = meta["od"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    start_vertices = meta["start_vertices"]
    demand = meta["demands"][arc_idx]

    best_distance = float("inf")
    best_remaining = 0.0

    for other_vehicle_idx, other_position in enumerate(current_positions):
        if other_vehicle_idx == vehicle_idx:
            continue

        other_remaining = remaining_capacity[other_vehicle_idx]
        feasible = other_remaining >= demand
        pass_depot = od[other_position][start_vertices[arc_idx]] == (
            od[other_position][depot] + od[depot][start_vertices[arc_idx]]
        )

        if not feasible and not pass_depot:
            continue

        distance = od[other_position][start_vertices[arc_idx]]
        if distance < best_distance:
            best_distance = distance
            best_remaining = other_remaining if feasible else capacities[other_vehicle_idx]

    return best_distance, best_remaining


def _precompute_route_features(meta, active_arcs, current_positions, remaining_capacity):
    od = meta["od"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    start_vertices = meta["start_vertices"]
    demands = meta["demands"]

    best_vehicle = {}
    best_distance = {}
    best_remaining = {}
    second_vehicle = {}
    second_distance = {}
    second_remaining = {}
    # RQ1: closest vehicle's remaining (unconditional, matching Java)
    rq1_vehicle = {}
    rq1_distance = {}
    rq1_remaining = {}

    for arc_idx in active_arcs:
        best_vehicle[arc_idx] = -1
        best_distance[arc_idx] = float("inf")
        best_remaining[arc_idx] = 0.0
        second_vehicle[arc_idx] = -1
        second_distance[arc_idx] = float("inf")
        second_remaining[arc_idx] = 0.0
        rq1_vehicle[arc_idx] = -1
        rq1_distance[arc_idx] = float("inf")
        rq1_remaining[arc_idx] = 0.0

    for other_vehicle_idx, other_position in enumerate(current_positions):
        other_remaining = remaining_capacity[other_vehicle_idx]
        od_row = od[other_position]
        via_depot_base = od_row[depot]

        for arc_idx in active_arcs:
            demand = demands[arc_idx]
            start_vertex = start_vertices[arc_idx]
            distance = od_row[start_vertex]

            feasible = other_remaining >= demand
            pass_depot = distance == (via_depot_base + od[depot][start_vertex])

            if not feasible and not pass_depot:
                continue

            candidate_remaining = other_remaining if feasible else capacities[other_vehicle_idx]

            if distance < best_distance[arc_idx]:
                second_vehicle[arc_idx] = best_vehicle[arc_idx]
                second_distance[arc_idx] = best_distance[arc_idx]
                second_remaining[arc_idx] = best_remaining[arc_idx]
                best_vehicle[arc_idx] = other_vehicle_idx
                best_distance[arc_idx] = distance
                best_remaining[arc_idx] = candidate_remaining
            elif distance < second_distance[arc_idx]:
                second_vehicle[arc_idx] = other_vehicle_idx
                second_distance[arc_idx] = distance
                second_remaining[arc_idx] = candidate_remaining

            # RQ1: always pick the closest vehicle regardless of feasibility
            if distance < rq1_distance[arc_idx]:
                rq1_vehicle[arc_idx] = other_vehicle_idx
                rq1_distance[arc_idx] = distance
                rq1_remaining[arc_idx] = other_remaining

    return (
        best_vehicle,
        best_distance,
        best_remaining,
        second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    )


def _select_best_candidate(program, meta, active_arcs, current_positions, remaining_capacity,
                           selected_count, rng):
    od = meta["od"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    start_vertices = meta["start_vertices"]
    demands = meta["demands"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]
    end_vertices = meta["end_vertices"]

    remaining_fraction = len(active_arcs) / meta["task_num"]
    unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

    dem1_map, ctt1_map = _precompute_candidate_neighbors(
        active_arcs, demands, meta["inter_arc_distance"]
    )
    (
        best_vehicle,
        best_distance,
        best_remaining,
        _second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    ) = _precompute_route_features(meta, active_arcs, current_positions, remaining_capacity)

    best_value = None
    best_candidate = None
    context = [1.0] * 16

    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        route_load = capacities[vehicle_idx] - remaining_capacity[vehicle_idx]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = route_load / capacities[vehicle_idx] if capacities[vehicle_idx] else 0.0
        context[_TERMINAL_INDEX["RQ"]] = remaining_capacity[vehicle_idx]

        for arc_idx in active_arcs:

            dem1 = dem1_map[arc_idx]
            ctt1 = ctt1_map[arc_idx]

            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction

            if best_vehicle[arc_idx] != vehicle_idx:
                cfr1 = best_distance[arc_idx]
            else:
                cfr1 = second_distance[arc_idx]
                # Fallback when no second vehicle exists
                if math.isinf(cfr1):
                    cfr1 = best_distance[arc_idx]

            rq1 = rq1_remaining.get(arc_idx, 0.0)

            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = cfr1
            context[_TERMINAL_INDEX["CTT1"]] = ctt1
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["RQ1"]] = rq1
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)
            candidate = (vehicle_idx, arc_idx)

            if best_value is None:
                best_value = value
                best_candidate = candidate
            elif configure_parameters.fitnessType == "MIN":
                if value < best_value:
                    best_value = value
                    best_candidate = candidate
                elif value == best_value:
                    best_candidate = candidate if rng.random() < 0.5 else best_candidate
            else:
                if value > best_value:
                    best_value = value
                    best_candidate = candidate
                elif value == best_value:
                    best_candidate = candidate if rng.random() < 0.5 else best_candidate

    return best_candidate


def _score_vehicle_arcs(program, meta, active_arcs, current_positions,
                        remaining_capacity, selected_count, rng):
    """
    Evaluate all (vehicle, arc) pairs in parallel.
    Returns:
      best_arc:       dict  vehicle_idx -> (arc_idx, value)
      second_arc:     dict  vehicle_idx -> (arc_idx, value)
      arc_best_vehicle: dict arc_idx -> list of (vehicle_idx, value)
    """
    od = meta["od"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    start_vertices = meta["start_vertices"]
    demands = meta["demands"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]
    end_vertices = meta["end_vertices"]

    remaining_fraction = len(active_arcs) / meta["task_num"]
    unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

    dem1_map, ctt1_map = _precompute_candidate_neighbors(
        active_arcs, demands, meta["inter_arc_distance"]
    )
    (
        best_vehicle,
        best_distance,
        best_remaining,
        _second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    ) = _precompute_route_features(meta, active_arcs, current_positions, remaining_capacity)

    context = [1.0] * 16
    best_arc = {}       # vehicle_idx -> (arc_idx, value)
    second_arc = {}     # vehicle_idx -> (arc_idx, value)
    arc_best_vehicle = {}  # arc_idx -> [(vehicle_idx, value), ...]


    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        route_load = capacities[vehicle_idx] - remaining_capacity[vehicle_idx]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = route_load / capacities[vehicle_idx] if capacities[vehicle_idx] else 0.0
        context[_TERMINAL_INDEX["RQ"]] = remaining_capacity[vehicle_idx]

        results = []

        for arc_idx in active_arcs:
            dem1 = dem1_map[arc_idx]
            ctt1 = ctt1_map[arc_idx]

            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction

            if best_vehicle[arc_idx] != vehicle_idx:
                cfr1 = best_distance[arc_idx]
            else:
                cfr1 = second_distance[arc_idx]
                # Fallback when no second vehicle exists
                if math.isinf(cfr1):
                    cfr1 = best_distance[arc_idx]

            rq1 = rq1_remaining.get(arc_idx, 0.0)

            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = cfr1
            context[_TERMINAL_INDEX["CTT1"]] = ctt1
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["RQ1"]] = rq1
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)

            arc_best_vehicle.setdefault(arc_idx, []).append((vehicle_idx, value))
            results.append((arc_idx, value))

        # --- Select best and second-best with random tie-breaking ---
        if results and not all(_is_nan(v) for _, v in results):
            # Find best value
            best_val = None
            for _, v in results:
                if _is_nan(v):
                    continue
                if best_val is None or _is_better(v, best_val):
                    best_val = v
            # Collect all arcs tied for best
            best_tied = [a for a, v in results if _scores_equal(v, best_val)]
            # Randomly pick one as best
            chosen_best = rng.choice(best_tied)
            best_arc[vehicle_idx] = (chosen_best, best_val)
            # Remove chosen best, pick second from remaining
            best_tied.remove(chosen_best)
            if best_tied:
                chosen_second = rng.choice(best_tied)
                second_val = best_val
                second_arc[vehicle_idx] = (chosen_second, second_val)
            else:
                # No other tied arcs — find second-best value
                second_val = None
                for a, v in results:
                    if _is_nan(v) or _scores_equal(v, best_val):
                        continue
                    if second_val is None or _is_better(v, second_val):
                        second_val = v
                if second_val is not None:
                    second_tied = [a for a, v in results if _scores_equal(v, second_val)]
                    chosen_second = rng.choice(second_tied)
                    second_arc[vehicle_idx] = (chosen_second, second_val)

    return best_arc, second_arc, arc_best_vehicle


def _is_better(a, b):
    """Return True if score a is better than score b.
    NaN scores are treated as worst (infinitely bad)."""
    a_nan = isinstance(a, float) and math.isnan(a)
    b_nan = isinstance(b, float) and math.isnan(b)
    if a_nan and b_nan:
        return False
    if a_nan:
        return False
    if b_nan:
        return True
    if configure_parameters.fitnessType == "MIN":
        return a < b
    return a > b


def _is_nan(v):
    """Check if a value is NaN."""
    return isinstance(v, float) and math.isnan(v)


def _scores_equal(a, b):
    """Compare scores treating NaN == NaN as True."""
    a_nan = isinstance(a, float) and math.isnan(a)
    b_nan = isinstance(b, float) and math.isnan(b)
    if a_nan and b_nan:
        return True
    if a_nan or b_nan:
        return False
    return a == b


def _select_vehicle_for_arc(arc, contenders, rng):
    """
    Given a list of (vehicle_idx, value) contenders for one arc,
    pick the best vehicle. Ties are broken randomly.
    Returns the winning vehicle_idx, or None if no valid contender.
    """
    if not contenders:
        return None

    # Find best value using NaN-aware comparison
    best_v = contenders[0]
    for v in contenders[1:]:
        if _is_better(v[1], best_v[1]):
            best_v = v

    # Collect all vehicles with the same best value (NaN-aware)
    winners = [v for v in contenders if _scores_equal(v[1], best_v[1])]
    if not winners:
        return None  # Should not happen, but guard
    if len(winners) == 1:
        return winners[0][0]
    return winners[rng.randint(0, len(winners) - 1)][0]


def _compute_fitness2(total_costs):
    """Compute Fitness2: max mileage difference among vehicles with assigned tasks.

    A vehicle is considered 'active' if its total_cost > 0 (meaning it was assigned tasks).
    If <=1 active vehicle, Fitness2 = 0.
    """
    active = [c for c in total_costs if c > 0]
    if len(active) <= 1:
        return 0.0
    return max(active) - min(active)


def _apply_fitness2_penalty(fitness1, fitness2, active_arcs, service_costs):
    """Apply unserved arc penalty to both objectives.

    If there are unserved arcs, both fitness values get a penalty
    to ensure complete solutions dominate partial ones.
    """
    num_unserved = len(active_arcs)
    if num_unserved > 0:
        avg_cost = sum(service_costs[ai] for ai in active_arcs) / num_unserved
        unserved_penalty = num_unserved * avg_cost * 10.0
        return fitness1 + unserved_penalty, fitness2 + unserved_penalty
    return fitness1, fitness2


def evaluate_individual_CARP(individual, instance):
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    erc_seed = _get_individual_erc_seed(individual)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(instance.seed)  # tie-breaking RNG

    current_positions = list(meta["vehicle_positions"])
    remaining_capacity = list(meta["vehicle_remaining"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    capacities = meta["vehicle_capacity"]
    reverse_index = meta["reverse_index"]

    selected_count = 0

    def _assign_arc(vehicle_idx, arc_idx):
        """Assign a single arc to a vehicle, updating state and costs."""
        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]
        demand = demands[arc_idx]

        if remaining_capacity[vehicle_idx] < demand:
            if curr_pos != depot:
                total_costs[vehicle_idx] += od[curr_pos][depot]
            remaining_capacity[vehicle_idx] = capacities[vehicle_idx]
            curr_pos = depot
            if curr_pos != target_start:
                total_costs[vehicle_idx] += od[depot][target_start]
        elif curr_pos != target_start:
            total_costs[vehicle_idx] += od[curr_pos][target_start]

        remaining_capacity[vehicle_idx] -= demand
        total_costs[vehicle_idx] += service_costs[arc_idx]
        current_positions[vehicle_idx] = end_vertices[arc_idx]

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

    # ---------- Parallel multi-vehicle decision ----------
    # Each round: every vehicle independently evaluates all active arcs
    # and claims its best one.  Conflicts (multiple vehicles want the same
    # arc) are resolved by the vehicle with the better GP score; ties
    # broken randomly.  Vehicles that lose try their second-best arc.
    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs(
            program, meta, active_arcs, current_positions,
            remaining_capacity, selected_count, erc_rng
        )

        assigned_this_round = set()  # arc indices assigned this round
        winners = {}                  # arc_idx -> vehicle_idx

        # Phase 1: resolve conflicts on each arc, pick one winner
        for arc_idx, contenders in arc_best.items():
            # Filter to only vehicles that listed this arc as their best
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
                and not _is_nan(v[1])
            ]
            if not contenders_best:
                continue

            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            if winner_vehicle is not None:
                winners[arc_idx] = winner_vehicle
                assigned_this_round.add(arc_idx)

        # Phase 2: vehicles that lost their best arc try second-best
        for vehicle_idx in range(len(current_positions)):
            if vehicle_idx in {v for v in winners.values()}:
                continue  # already won something

            if vehicle_idx not in second_arc:
                continue

            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue  # already taken

            # Check arc still exists (may have been removed by winner)
            if arc_idx not in set(active_arcs):
                continue

            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            # No vehicle can serve any remaining arc — shouldn't happen
            # with correct data, but guard against infinite loop.
            break

        # Phase 3: apply all assignments
        for arc_idx, vehicle_idx in winners.items():
            _assign_arc(vehicle_idx, arc_idx)
            selected_count += 2

    total_assigned = sum(1 for arc_idx in range(len(meta["required_arcs"]))
                         if arc_idx not in set(active_arcs))

    if total_assigned == 0:
        # Program produced NaN/invalid scores for all evaluations — worst fitness
        individual.fitness.values = (1e10, 1e10) if configure_parameters.fitnessType == "MIN" else (-1e10, -1e10)
        return individual

    # Penalty for unserved arcs
    num_unserved = len(active_arcs)
    if num_unserved > 0:
        avg_cost = sum(service_costs[ai] for ai in active_arcs) / num_unserved if num_unserved > 0 else 0
        unserved_penalty = num_unserved * avg_cost * 10.0
        for vehicle_idx, pos in enumerate(current_positions):
            if pos != depot:
                total_costs[vehicle_idx] += od[pos][depot]
        fitness1 = sum(total_costs) + unserved_penalty
        fitness2 = _compute_fitness2(total_costs) + unserved_penalty
        individual.fitness.values = (fitness1, fitness2)
        return individual

    total_fitness = 0.0
    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            total_costs[vehicle_idx] += od[pos][depot]
        total_fitness += total_costs[vehicle_idx]

    fitness2 = _compute_fitness2(total_costs)
    individual.fitness.values = (total_fitness, fitness2)
    return individual


def evaluate_individual_CPP(individual, instance):
    """CPP evaluation: single vehicle, no capacity limit, each required arc serviced once."""
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    rng = random.Random(instance.seed)

    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    od = meta["od"]
    depot = meta["depot"]
    reverse_index = meta["reverse_index"]

    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    dem1_map, ctt1_map = _precompute_candidate_neighbors(
        active_arcs, demands, meta["inter_arc_distance"]
    )

    vehicle_pos = meta["vehicle_positions"][0]
    total_cost = 0.0
    selected_count = 0

    while active_arcs:
        best_value = None
        best_arc_idx = None
        context = [1.0] * 16

        remaining_fraction = len(active_arcs) / meta["task_num"]
        unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = 0.0
        context[_TERMINAL_INDEX["RQ"]] = 0.0
        context[_TERMINAL_INDEX["RQ1"]] = 0.0

        for arc_idx in active_arcs:
            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction
            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = meta["arc_to_depot"][arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = 0.0
            context[_TERMINAL_INDEX["CTT1"]] = ctt1_map[arc_idx]
            context[_TERMINAL_INDEX["CTD"]] = meta["depot_to_arc"][arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1_map[arc_idx]
            context[_TERMINAL_INDEX["DC"]] = meta["deadheading"][arc_idx]
            context[_TERMINAL_INDEX["SC"]] = service_costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)

            if best_value is None:
                best_value = value
                best_arc_idx = arc_idx
            elif configure_parameters.fitnessType == "MIN":
                if value < best_value:
                    best_value = value
                    best_arc_idx = arc_idx
                elif value == best_value and arc_idx < best_arc_idx:
                    best_arc_idx = arc_idx
            else:
                if value > best_value:
                    best_value = value
                    best_arc_idx = arc_idx
                elif value == best_value and arc_idx < best_arc_idx:
                    best_arc_idx = arc_idx

        total_cost += od[vehicle_pos][start_vertices[best_arc_idx]]
        total_cost += service_costs[best_arc_idx]
        vehicle_pos = end_vertices[best_arc_idx]
        selected_count += 1

        _remove_active_arc(active_arcs, active_pos, best_arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[best_arc_idx])

    total_cost += od[vehicle_pos][depot]

    # CPP: single vehicle, so Fitness2 = 0
    individual.fitness.values = (total_cost, 0.0)
    return individual


def print_vehicle_routes(individual, instance):
    """
    Simulate the GP routing policy and print the detailed path for each vehicle.
    Shows depot -> deadheading -> service arc -> refill events -> return to depot.
    instance can be the parent Instance or a SeededSample.
    Dispatches to URARP or CARP version based on problem type.
    """
    if configure_parameters.problem == "URARP":
        _print_vehicle_routes_URARP(individual, instance)
    else:
        _print_vehicle_routes_CARP(individual, instance)


def _print_vehicle_routes_URARP(individual, instance):
    """Print vehicle routes for URARP with ring lock-in constraint."""
    sample = instance
    if not hasattr(instance, "seed_requiredArc"):
        sample = instance.instanceSeedList[0]

    program = _compile_program(individual)
    meta = _get_seed_meta_urarp(sample)
    erc_seed = _get_individual_erc_seed(individual)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(sample.seed)

    num_vehicles = len(meta["vehicle_positions"])
    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    service_costs = meta["costs"]
    capacities = meta["vehicle_capacity"]
    reverse_index = meta["reverse_index"]
    max_mileage = meta["max_running_mileage"]
    arc_ring_id = meta["arc_ring_id"]
    required_arcs = meta["required_arcs"]

    current_positions = list(meta["vehicle_positions"])
    remaining_mileage = list(meta["vehicle_mileage"])
    total_costs = list(meta["vehicle_costs"])

    routes = [[] for _ in range(num_vehicles)]
    route_cost = [0.0] * num_vehicles

    active_arcs, active_pos = _active_state(len(required_arcs))
    selected_count = 0
    vehicle_current_ring = {i: None for i in range(num_vehicles)}
    ring_owner = {}

    # URARP: need available_facilities for display (no perturbations for display)
    available_facilities = sample.facility_nodes
    blocked_access_nodes = set()

    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs_urarp(
            program, meta, active_arcs, current_positions,
            remaining_mileage, available_facilities,
            blocked_access_nodes, vehicle_current_ring,
            ring_owner, selected_count, erc_rng
        )

        assigned_this_round = set()
        winners = {}

        for arc_idx, contenders in arc_best.items():
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
                and not _is_nan(v[1])
            ]
            if not contenders_best:
                continue
            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            if winner_vehicle is not None:
                winners[arc_idx] = winner_vehicle
                assigned_this_round.add(arc_idx)

        for vehicle_idx in range(num_vehicles):
            if vehicle_idx in {v for v in winners.values()}:
                continue
            if vehicle_idx not in second_arc:
                continue
            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue
            if arc_idx not in set(active_arcs):
                continue
            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            break

        # Ring exclusivity resolution (same as evaluate_individual_URARP)
        max_iter = 20
        while max_iter > 0:
            max_iter -= 1
            ring_winners = {}
            for ai, vi in winners.items():
                arc_r = arc_ring_id[ai]
                if arc_r is not None and arc_r not in ring_owner:
                    ring_winners.setdefault(arc_r, []).append((ai, vi))

            conflict = False
            for ring_id, vw_list in ring_winners.items():
                if len(vw_list) <= 1:
                    continue
                vw_list.sort(key=lambda x: x[1])
                for ai, vi in vw_list[1:]:
                    del winners[ai]
                    assigned_this_round.discard(ai)
                conflict = True
                break

            if not conflict:
                break

        for arc_idx, vehicle_idx in winners.items():
            curr_pos = current_positions[vehicle_idx]
            target_start = start_vertices[arc_idx]
            target_end = end_vertices[arc_idx]
            sc = service_costs[arc_idx]
            arc_ring = arc_ring_id[arc_idx]

            # Lock vehicle into ring (claim exclusivity)
            if vehicle_current_ring[vehicle_idx] is None and arc_ring is not None:
                vehicle_current_ring[vehicle_idx] = arc_ring
                ring_owner[arc_ring] = vehicle_idx

            # Check if recharge needed
            cost_to_arc = od[curr_pos][target_start]
            total_needed = cost_to_arc + sc
            if remaining_mileage[vehicle_idx] < total_needed:
                if curr_pos != depot:
                    cost_back = od[curr_pos][depot]
                    route_cost[vehicle_idx] += cost_back
                    routes[vehicle_idx].append(("deadhead", curr_pos, depot, cost_back))
                remaining_mileage[vehicle_idx] = max_mileage
                routes[vehicle_idx].append(("refill", depot, None, 0.0))
                curr_pos = depot
                cost_to_arc = od[depot][target_start]
            elif curr_pos != target_start:
                cost_fwd = od[curr_pos][target_start]
                route_cost[vehicle_idx] += cost_fwd
                routes[vehicle_idx].append(("deadhead", curr_pos, target_start, cost_fwd))

            route_cost[vehicle_idx] += sc
            remaining_mileage[vehicle_idx] -= sc
            routes[vehicle_idx].append(("service", target_start, target_end, sc,
                                        0.0, arc_idx + 1))  # URARP: no demand
            current_positions[vehicle_idx] = target_end

            _remove_active_arc(active_arcs, active_pos, arc_idx)
            _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

            # Free vehicle when ring is done
            if vehicle_current_ring[vehicle_idx] is not None:
                locked = vehicle_current_ring[vehicle_idx]
                has_remaining = any(arc_ring_id[i] == locked for i in active_arcs)
                if not has_remaining:
                    vehicle_current_ring[vehicle_idx] = None
                    del ring_owner[locked]

            selected_count += 2

    # Return to depot
    for v_idx in range(num_vehicles):
        pos = current_positions[v_idx]
        if pos != depot:
            cost_back = od[pos][depot]
            route_cost[v_idx] += cost_back
            routes[v_idx].append(("deadhead", pos, depot, cost_back))

    _print_routes_common(routes, route_cost, num_vehicles, depot, sample, instance)


def _print_routes_common(routes, route_cost, num_vehicles, depot, sample, instance):
    """Shared print formatting for vehicle routes (both URARP and CARP).

    Format rules:
    - Service arcs: connected with "="
    - Deadhead (no-service) arcs: connected with "-"
    - After arriving at a facility node for refill (before remaining mileage runs out),
      append "(fill)" to that node.
    """
    print("\n========== Vehicle Routes (Best Individual) ==========")
    print(f"(Cost shown for seed={sample.seed}; train fitness uses {len(instance.instanceSeedList)} seeds)")
    total_print = 0.0

    path_matrix = None
    if hasattr(sample, "seedPathMatrix"):
        path_matrix = sample.seedPathMatrix

    facility_nodes = getattr(instance, "facility_nodes", {depot})

    for v_idx in range(num_vehicles):
        if not routes[v_idx]:
            print(f"  Vehicle {v_idx + 1}: No tasks assigned")
            continue

        print(f"  --- Vehicle {v_idx + 1} ---")
        parts = [f"{depot}(Depot)"]
        v_cost = 0.0
        last_node = depot
        was_refill = False

        for entry in routes[v_idx]:
            action = entry[0]
            if action == "deadhead":
                _, frm, to, cost = entry
                v_cost += cost
                dh_nodes = _expand_deadhead_path(frm, to, path_matrix)
                for i, n in enumerate(dh_nodes[1:], 1):
                    connector = "-"
                    # If the previous entry was a service, use "=" for the first deadhead node
                    # only if it's directly the service destination (already handled by service)
                    parts.append(f"{connector}{n}")
                last_node = to
                was_refill = False
            elif action == "refill":
                # Mark that we just refilled at last_node
                # Append (fill) to the last node in parts
                if parts:
                    parts[-1] = parts[-1] + "(fill)"
                was_refill = True
            elif action == "service":
                _, frm, to, cost, dem, arc_num = entry
                v_cost += cost
                parts.append(f"={to}")
                last_node = to
                was_refill = False

        if last_node != depot:
            close_path = _expand_deadhead_path(last_node, depot, path_matrix)
            for n in close_path[1:]:
                parts.append(f"-{n}")
            parts.append("(Depot)")
        else:
            parts.append("(Depot)")

        total_print += v_cost
        print(f"    Route: {''.join(parts)}")
        print(f"    Total cost: {v_cost:.2f}")

    print(f"  Overall total cost: {total_print:.2f}")
    print("=" * 50)


def _print_vehicle_routes_CARP(individual, instance):
    """Original CARP route printing (no ring constraints)."""
    sample = instance
    if not hasattr(instance, "seed_requiredArc"):
        sample = instance.instanceSeedList[0]

    program = _compile_program(individual)
    meta = _get_seed_meta(sample)
    erc_seed = _get_individual_erc_seed(individual)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(sample.seed)

    num_vehicles = len(meta["vehicle_positions"])
    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    capacities = meta["vehicle_capacity"]
    reverse_index = meta["reverse_index"]
    required_arcs = meta["required_arcs"]

    current_positions = list(meta["vehicle_positions"])
    remaining_capacity = list(meta["vehicle_remaining"])
    total_costs = list(meta["vehicle_costs"])

    routes = [[] for _ in range(num_vehicles)]
    route_cost = [0.0] * num_vehicles

    active_arcs, active_pos = _active_state(len(required_arcs))
    selected_count = 0

    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs(
            program, meta, active_arcs, current_positions,
            remaining_capacity, selected_count, erc_rng
        )

        assigned_this_round = set()
        winners = {}

        for arc_idx, contenders in arc_best.items():
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
            ]
            if not contenders_best:
                continue
            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            winners[arc_idx] = winner_vehicle
            assigned_this_round.add(arc_idx)

        for vehicle_idx in range(num_vehicles):
            if vehicle_idx in {v for v in winners.values()}:
                continue
            if vehicle_idx not in second_arc:
                continue
            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue
            if arc_idx not in set(active_arcs):
                continue
            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            break

        for arc_idx, vehicle_idx in winners.items():
            curr_pos = current_positions[vehicle_idx]
            target_start = start_vertices[arc_idx]
            demand = demands[arc_idx]
            target_end = end_vertices[arc_idx]

            if remaining_capacity[vehicle_idx] < demand:
                if curr_pos != depot:
                    cost_back = od[curr_pos][depot]
                    route_cost[vehicle_idx] += cost_back
                    routes[vehicle_idx].append(("deadhead", curr_pos, depot, cost_back))
                remaining_capacity[vehicle_idx] = capacities[vehicle_idx]
                routes[vehicle_idx].append(("refill", depot, None, 0.0))
                curr_pos = depot
                if curr_pos != target_start:
                    cost_fwd = od[depot][target_start]
                    route_cost[vehicle_idx] += cost_fwd
                    routes[vehicle_idx].append(("deadhead", depot, target_start, cost_fwd))
            elif curr_pos != target_start:
                cost_fwd = od[curr_pos][target_start]
                route_cost[vehicle_idx] += cost_fwd
                routes[vehicle_idx].append(("deadhead", curr_pos, target_start, cost_fwd))

            service_cost = service_costs[arc_idx]
            route_cost[vehicle_idx] += service_cost
            remaining_capacity[vehicle_idx] -= demand
            routes[vehicle_idx].append(("service", target_start, target_end, service_cost,
                                        demand, arc_idx + 1))

            current_positions[vehicle_idx] = target_end

            _remove_active_arc(active_arcs, active_pos, arc_idx)
            _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])
            selected_count += 2

    for v_idx in range(num_vehicles):
        pos = current_positions[v_idx]
        if pos != depot:
            cost_back = od[pos][depot]
            route_cost[v_idx] += cost_back
            routes[v_idx].append(("deadhead", pos, depot, cost_back))

    _print_routes_common(routes, route_cost, num_vehicles, depot, sample, instance)


def _expand_deadhead_path(frm, to, path_matrix):
    """Return the full shortest path node list from frm to to.
    Falls back to [frm, to] if path_matrix is unavailable."""
    if path_matrix and frm > 0 and to > 0:
        try:
            p = path_matrix[frm][to]
            if p:
                return p
        except (IndexError, TypeError):
            pass
    return [frm, to]





def evaluate_individual(individual, instance):
    if configure_parameters.problem == "CARP":
        return evaluate_individual_CARP(individual, instance)
    elif configure_parameters.problem == "URARP":
        return evaluate_individual_URARP(individual, instance)
    elif configure_parameters.problem == "CPP":
        return evaluate_individual_CPP(individual, instance)
    raise ValueError(f"Unsupported problem type: {configure_parameters.problem}")


def evaluate_batch(ind, sample_list):
    """Evaluate an individual across multiple samples, averaging both objectives."""
    fit1_sum = 0.0
    fit2_sum = 0.0

    for sample in sample_list:
        evaluate_individual(ind, sample)
        fit1_sum += ind.fitness.values[0]
        fit2_sum += ind.fitness.values[1]

    ind.fitness.values = (fit1_sum / len(sample_list), fit2_sum / len(sample_list))
    return ind


def evaluate_population(pop, sample_list):
    """Evaluate every individual in the population (serial).
    No caching — each individual is evaluated afresh each time."""
    for ind in pop:
        evaluate_batch(ind, sample_list)
    return pop


# ==============================================================================
# Parallel evaluation (multiprocessing)
# ==============================================================================

# Per-worker global instance — set once by _init_worker, avoids pickling
# the heavy Instance object for every evaluation task.
_global_worker_instance = None


def _init_worker(sample_list):
    """Initialize the worker process with the sample list for evaluation."""
    global _global_worker_instance
    _global_worker_instance = sample_list


def _eval_single_individual(individual):
    """Evaluate one individual on all samples. Runs inside a worker process.

    ERC seed is generated once per individual (cached on the individual),
    matching the serial behaviour where _get_individual_erc_seed caches
    the seed. Returns the individual with fitness set.
    """
    global _global_worker_instance
    fit1_sum = 0.0
    fit2_sum = 0.0

    # Generate one ERC seed for this individual, cached on the individual
    erc_seed = _get_individual_erc_seed_worker(individual)

    sample_list = _global_worker_instance
    for sample in sample_list:
        _evaluate_individual_with_erc(individual, sample, erc_seed)
        fit1_sum += individual.fitness.values[0]
        fit2_sum += individual.fitness.values[1]
    individual.fitness.values = (fit1_sum / len(sample_list), fit2_sum / len(sample_list))
    return individual


def _get_individual_erc_seed_worker(individual):
    """Get (and cache) an ERC seed for this individual inside a worker process.

    Uses the same deterministic formula as _get_individual_erc_seed so that
    results are identical whether running sequentially or in parallel.
    """
    cached = getattr(individual, "_erc_seed_cached", None)
    if cached is not None:
        return cached

    base = configure_parameters.erc_seed
    if base is None:
        base = 42

    key = f"{base}:{str(individual)}".encode("utf-8")
    h = int(hashlib.sha256(key).hexdigest(), 16)
    seed = (h % (2**31 - 2)) + 1
    individual._erc_seed_cached = seed
    return seed


def _evaluate_individual_with_erc(individual, instance, erc_seed):
    """Evaluate one individual on one sample with a given ERC seed.
    Mirrors evaluate_individual but uses the provided erc_seed directly."""
    if configure_parameters.problem == "CARP":
        _evaluate_individual_CARP_with_erc(individual, instance, erc_seed)
    elif configure_parameters.problem == "URARP":
        _evaluate_individual_URARP_with_erc(individual, instance, erc_seed)
    elif configure_parameters.problem == "CPP":
        _evaluate_individual_CPP_with_erc(individual, instance, erc_seed)


def _evaluate_individual_CARP_with_erc(individual, instance, erc_seed):
    """evaluate_individual_CARP with explicit erc_seed (no global state)."""
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(instance.seed)

    current_positions = list(meta["vehicle_positions"])
    remaining_capacity = list(meta["vehicle_remaining"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    capacities = meta["vehicle_capacity"]
    reverse_index = meta["reverse_index"]

    selected_count = 0

    def _assign_arc(vehicle_idx, arc_idx):
        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]
        demand = demands[arc_idx]

        if remaining_capacity[vehicle_idx] < demand:
            if curr_pos != depot:
                total_costs[vehicle_idx] += od[curr_pos][depot]
            remaining_capacity[vehicle_idx] = capacities[vehicle_idx]
            curr_pos = depot
            if curr_pos != target_start:
                total_costs[vehicle_idx] += od[depot][target_start]
        elif curr_pos != target_start:
            total_costs[vehicle_idx] += od[curr_pos][target_start]

        remaining_capacity[vehicle_idx] -= demand
        total_costs[vehicle_idx] += service_costs[arc_idx]
        current_positions[vehicle_idx] = end_vertices[arc_idx]

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs_with_erc(
            program, meta, active_arcs, current_positions,
            remaining_capacity, selected_count, erc_rng
        )

        assigned_this_round = set()
        winners = {}

        for arc_idx, contenders in arc_best.items():
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
                and not _is_nan(v[1])
            ]
            if not contenders_best:
                continue

            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            if winner_vehicle is not None:
                winners[arc_idx] = winner_vehicle
                assigned_this_round.add(arc_idx)

        for vehicle_idx in range(len(current_positions)):
            if vehicle_idx in {v for v in winners.values()}:
                continue
            if vehicle_idx not in second_arc:
                continue

            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue
            if arc_idx not in set(active_arcs):
                continue

            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            break

        for arc_idx, vehicle_idx in winners.items():
            _assign_arc(vehicle_idx, arc_idx)
            selected_count += 2

    total_assigned = sum(1 for arc_idx in range(len(meta["required_arcs"]))
                         if arc_idx not in set(active_arcs))

    if total_assigned == 0:
        individual.fitness.values = (1e10, 1e10) if configure_parameters.fitnessType == "MIN" else (-1e10, -1e10)
        return individual

    # Penalty for unserved arcs
    num_unserved = len(active_arcs)
    if num_unserved > 0:
        avg_cost = sum(service_costs[ai] for ai in active_arcs) / num_unserved if num_unserved > 0 else 0
        unserved_penalty = num_unserved * avg_cost * 10.0
        for vehicle_idx, pos in enumerate(current_positions):
            if pos != depot:
                total_costs[vehicle_idx] += od[pos][depot]
        fitness1 = sum(total_costs) + unserved_penalty
        fitness2 = _compute_fitness2(total_costs) + unserved_penalty
        individual.fitness.values = (fitness1, fitness2)
        return individual

    total_fitness = 0.0
    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            total_costs[vehicle_idx] += od[pos][depot]
        total_fitness += total_costs[vehicle_idx]

    fitness2 = _compute_fitness2(total_costs)
    individual.fitness.values = (total_fitness, fitness2)


def _evaluate_individual_CPP_with_erc(individual, instance, erc_seed):
    """evaluate_individual_CPP with explicit erc_seed (no global state)."""
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(instance.seed)

    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    od = meta["od"]
    depot = meta["depot"]
    reverse_index = meta["reverse_index"]

    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    dem1_map, ctt1_map = _precompute_candidate_neighbors(
        active_arcs, demands, meta["inter_arc_distance"]
    )

    vehicle_pos = meta["vehicle_positions"][0]
    total_cost = 0.0
    selected_count = 0

    while active_arcs:
        best_value = None
        best_arc_idx = None
        context = [1.0] * 16

        remaining_fraction = len(active_arcs) / meta["task_num"]
        unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = 0.0
        context[_TERMINAL_INDEX["RQ"]] = 0.0
        context[_TERMINAL_INDEX["RQ1"]] = 0.0

        for arc_idx in active_arcs:
            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction
            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = meta["arc_to_depot"][arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = 0.0
            context[_TERMINAL_INDEX["CTT1"]] = ctt1_map[arc_idx]
            context[_TERMINAL_INDEX["CTD"]] = meta["depot_to_arc"][arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1_map[arc_idx]
            context[_TERMINAL_INDEX["DC"]] = meta["deadheading"][arc_idx]
            context[_TERMINAL_INDEX["SC"]] = service_costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)

            if best_value is None:
                best_value = value
                best_arc_idx = arc_idx
            elif configure_parameters.fitnessType == "MIN":
                if value < best_value:
                    best_value = value
                    best_arc_idx = arc_idx
                elif value == best_value and arc_idx < best_arc_idx:
                    best_arc_idx = arc_idx
            else:
                if value > best_value:
                    best_value = value
                    best_arc_idx = arc_idx
                elif value == best_value and arc_idx < best_arc_idx:
                    best_arc_idx = arc_idx

        total_cost += od[vehicle_pos][start_vertices[best_arc_idx]]
        total_cost += service_costs[best_arc_idx]
        vehicle_pos = end_vertices[best_arc_idx]
        selected_count += 1

        _remove_active_arc(active_arcs, active_pos, best_arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[best_arc_idx])

    total_cost += od[vehicle_pos][depot]

    # CPP: single vehicle, Fitness2 = 0
    individual.fitness.values = (total_cost, 0.0)


def _score_vehicle_arcs_with_erc(program, meta, active_arcs, current_positions,
                                  remaining_capacity, selected_count, rng):
    """Same as _score_vehicle_arcs but uses the provided rng for ERC values."""
    od = meta["od"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    start_vertices = meta["start_vertices"]
    demands = meta["demands"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]
    end_vertices = meta["end_vertices"]

    remaining_fraction = len(active_arcs) / meta["task_num"]
    unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

    dem1_map, ctt1_map = _precompute_candidate_neighbors(
        active_arcs, demands, meta["inter_arc_distance"]
    )
    (
        best_vehicle,
        best_distance,
        best_remaining,
        _second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    ) = _precompute_route_features(meta, active_arcs, current_positions, remaining_capacity)

    context = [1.0] * 16
    best_arc = {}
    second_arc = {}
    arc_best_vehicle = {}

    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        route_load = capacities[vehicle_idx] - remaining_capacity[vehicle_idx]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = route_load / capacities[vehicle_idx] if capacities[vehicle_idx] else 0.0
        context[_TERMINAL_INDEX["RQ"]] = remaining_capacity[vehicle_idx]

        results = []

        for arc_idx in active_arcs:
            dem1 = dem1_map[arc_idx]
            ctt1 = ctt1_map[arc_idx]

            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction

            if best_vehicle[arc_idx] != vehicle_idx:
                cfr1 = best_distance[arc_idx]
            else:
                cfr1 = second_distance[arc_idx]
                if math.isinf(cfr1):
                    cfr1 = best_distance[arc_idx]

            rq1 = rq1_remaining.get(arc_idx, 0.0)

            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = cfr1
            context[_TERMINAL_INDEX["CTT1"]] = ctt1
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["RQ1"]] = rq1
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)

            arc_best_vehicle.setdefault(arc_idx, []).append((vehicle_idx, value))
            results.append((arc_idx, value))

        if results and not all(_is_nan(v) for _, v in results):
            best_val = None
            for _, v in results:
                if _is_nan(v):
                    continue
                if best_val is None or _is_better(v, best_val):
                    best_val = v
            best_tied = [a for a, v in results if _scores_equal(v, best_val)]
            chosen_best = rng.choice(best_tied)
            best_arc[vehicle_idx] = (chosen_best, best_val)
            best_tied.remove(chosen_best)
            if best_tied:
                chosen_second = rng.choice(best_tied)
                second_val = best_val
                second_arc[vehicle_idx] = (chosen_second, second_val)
            else:
                second_val = None
                for a, v in results:
                    if _is_nan(v) or _scores_equal(v, best_val):
                        continue
                    if second_val is None or _is_better(v, second_val):
                        second_val = v
                if second_val is not None:
                    second_tied = [a for a, v in results if _scores_equal(v, second_val)]
                    chosen_second = rng.choice(second_tied)
                    second_arc[vehicle_idx] = (chosen_second, second_val)

    return best_arc, second_arc, arc_best_vehicle


# ==============================================================================
# URARP (Uncertain Rich Arc Routing Problem) evaluation
# ==============================================================================

def _apply_urarp_perturbations(instance, rng):
    """
    Apply dynamic perturbations for URARP:
    - facility_change_rate: some facilities become unavailable
    - entrances_change_rate: some access nodes become blocked
    - vehicle_change_rate: some vehicles break down (is_alive = False)
    Returns (unavailable_facilities, blocked_access_nodes, dead_vehicles)
    """
    unavailable_facilities = set()
    for fac in instance.facility_nodes:
        if rng.random() < configure_parameters.facility_change_rate:
            unavailable_facilities.add(fac)

    blocked_access_nodes = set()
    for node in instance.access_nodes:
        if rng.random() < configure_parameters.entrances_change_rate:
            blocked_access_nodes.add(node)

    return unavailable_facilities, blocked_access_nodes


def _can_enter_arc_urarp(arc_idx, vehicle_pos, vehicle_in_service,
                         meta, blocked_access_nodes):
    """
    Check if a vehicle can legally serve the given arc under URARP rules.

    Entry is allowed if:
    1. Vehicle is already at the arc's start node (continuous service within a ring)
    2. The arc's start node is an access node AND it is not blocked
    3. The arc's start node is the vehicle's depot (vehicles can always leave depot)
    """
    start_vertex = meta["start_vertices"][arc_idx]
    arc_ring = meta["arc_ring_id"][arc_idx]

    # Case 1: vehicle is already at the start node (continuous service)
    if vehicle_pos == start_vertex:
        return True

    # Case 2: vehicle is at depot — can always leave
    if vehicle_pos == meta["depot"]:
        return True

    # Case 3: entering a ring arc — must use an access node
    if arc_ring is not None:
        # Need to reach start_vertex via an access node
        if start_vertex in blocked_access_nodes:
            return False
        # Access is allowed if start_vertex itself is an access node,
        # OR if there exists an accessible access node on the shortest path
        if start_vertex in meta["access_nodes"]:
            return True
        # For non-access-node start vertices, check if any access node
        # lies on the shortest path from vehicle_pos to start_vertex
        # (simplified: allow if any unblocked access node exists)
        accessible = meta["access_nodes"] - blocked_access_nodes
        if not accessible:
            return False
        # Check path connectivity through access nodes
        od = meta["od"]
        for access_node in accessible:
            path_via = od[vehicle_pos][access_node] + od[access_node][start_vertex]
            if path_via < float("inf"):
                return True
        return False

    # Non-ring arcs: always accessible
    return True


def _nearest_recharge_facility(vehicle_pos, unavailable_facilities, od):
    """
    Find the nearest available facility for recharging.
    Returns (facility_node, cost_to_reach) or (None, inf).
    """
    best_fac = None
    best_cost = float("inf")
    for fac in unavailable_facilities:
        continue  # skip unavailable
    # We need available facilities — caller should pass available set
    return best_fac, best_cost


def _nearest_available_facility(vehicle_pos, available_facilities, od):
    """Find the nearest available facility node and its travel cost."""
    best_fac = None
    best_cost = float("inf")
    for fac in available_facilities:
        cost = od[vehicle_pos][fac]
        if cost < best_cost:
            best_cost = cost
            best_fac = fac
    return best_fac, best_cost


def _check_range_feasible_urarp(vehicle_idx, arc_idx, meta,
                                 remaining_mileage, available_facilities,
                                 current_positions):
    """
    Check if the vehicle has enough range to serve the arc.
    If not, check if it can reach a facility to recharge first.
    Returns (can_serve, need_recharge, recharge_cost)
    """
    od = meta["od"]
    depot = meta["depot"]
    start_vertex = meta["start_vertices"][arc_idx]
    service_cost = meta["costs"][arc_idx]
    vehicle_pos = current_positions[vehicle_idx]

    cost_to_arc = od[vehicle_pos][start_vertex]
    total_needed = cost_to_arc + service_cost

    # Vehicle has enough range
    if remaining_mileage[vehicle_idx] >= total_needed:
        return True, False, 0.0

    # Need to recharge first
    if available_facilities:
        fac, fac_cost = _nearest_available_facility(vehicle_pos, available_facilities, od)
        if fac is not None and fac_cost < float("inf"):
            # After recharge, check if can reach arc
            after_recharge = meta["max_running_mileage"]
            total_after = fac_cost + od[fac][start_vertex] + service_cost
            if after_recharge >= total_after:
                return True, True, fac_cost

    # Can't serve this arc with current range
    return False, False, 0.0


def _precompute_candidate_neighbors_urarp(active_arcs, inter_arc_distance):
    """URARP version: nearest neighbor by distance only (no demand)."""
    ctt1_map = {}
    for arc_idx in active_arcs:
        best_dist = float("inf")
        best_ctt = 0.0
        row = inter_arc_distance[arc_idx]
        for other_idx in active_arcs:
            if other_idx == arc_idx:
                continue
            ctt_dist = row[other_idx]
            if ctt_dist < best_dist:
                best_dist = ctt_dist
                best_ctt = ctt_dist
        ctt1_map[arc_idx] = best_ctt
    return ctt1_map


def _precompute_route_features_urarp(meta, active_arcs, current_positions,
                                     remaining_mileage):
    """URARP version: no demand/feasibility checks, just distance + remaining mileage."""
    od = meta["od"]
    depot = meta["depot"]
    start_vertices = meta["start_vertices"]

    best_vehicle = {}
    best_distance = {}
    best_remaining = {}
    second_vehicle = {}
    second_distance = {}
    second_remaining = {}
    rq1_remaining = {}

    for arc_idx in active_arcs:
        best_vehicle[arc_idx] = -1
        best_distance[arc_idx] = float("inf")
        best_remaining[arc_idx] = 0.0
        second_vehicle[arc_idx] = -1
        second_distance[arc_idx] = float("inf")
        second_remaining[arc_idx] = 0.0
        rq1_remaining[arc_idx] = 0.0

    for other_vehicle_idx, other_position in enumerate(current_positions):
        other_mileage = remaining_mileage[other_vehicle_idx]
        od_row = od[other_position]
        via_depot_base = od_row[depot]

        for arc_idx in active_arcs:
            start_vertex = start_vertices[arc_idx]
            distance = od_row[start_vertex]

            # URARP: always feasible (no capacity/demand constraint)
            if distance < best_distance[arc_idx]:
                second_vehicle[arc_idx] = best_vehicle[arc_idx]
                second_distance[arc_idx] = best_distance[arc_idx]
                second_remaining[arc_idx] = best_remaining[arc_idx]
                best_vehicle[arc_idx] = other_vehicle_idx
                best_distance[arc_idx] = distance
                best_remaining[arc_idx] = other_mileage
            elif distance < second_distance[arc_idx]:
                second_vehicle[arc_idx] = other_vehicle_idx
                second_distance[arc_idx] = distance
                second_remaining[arc_idx] = other_mileage

            # RQ1: closest vehicle's remaining (unconditional)
            if distance < rq1_remaining.get(arc_idx, float("inf")):
                rq1_remaining[arc_idx] = other_mileage

    return (
        best_vehicle,
        best_distance,
        best_remaining,
        second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    )


def _score_vehicle_arcs_urarp(program, meta, active_arcs, current_positions,
                               remaining_mileage, available_facilities,
                               blocked_access_nodes, vehicle_current_ring,
                               ring_owner,
                               selected_count, rng):
    """
    URARP version of _score_vehicle_arcs.
    Evaluates all (vehicle, arc) pairs with range and access constraints.
    Infeasible pairs get NaN score.

    Ring lock-in constraint: when a vehicle is servicing a ring
    (vehicle_current_ring[vehicle_idx] is set), it may only score arcs
    belonging to that ring until the ring is fully serviced.

    Ring exclusivity constraint: once a ring is claimed by a vehicle,
    all other vehicles cannot score any arc from that ring (NaN).
    """
    od = meta["od"]
    depot = meta["depot"]
    start_vertices = meta["start_vertices"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]
    end_vertices = meta["end_vertices"]
    max_mileages = meta["vehicle_capacity"]  # alias for max_running_mileage
    arc_ring_id = meta["arc_ring_id"]

    remaining_fraction = len(active_arcs) / meta["task_num"]
    unassigned_fraction = (meta["task_num"] - selected_count) / meta["task_num"]

    ctt1_map = _precompute_candidate_neighbors_urarp(
        active_arcs, meta["inter_arc_distance"]
    )
    (
        best_vehicle,
        best_distance,
        best_remaining,
        _second_vehicle,
        second_distance,
        second_remaining,
        rq1_remaining,
    ) = _precompute_route_features_urarp(meta, active_arcs, current_positions,
                                         remaining_mileage)

    context = [1.0] * 16
    best_arc = {}
    second_arc = {}
    arc_best_vehicle = {}

    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        # URARP: "route_load" = mileage consumed so far
        route_load = max_mileages[vehicle_idx] - remaining_mileage[vehicle_idx]

        context[_TERMINAL_INDEX["CR"]] = od[vehicle_pos][depot]
        context[_TERMINAL_INDEX["FULL"]] = route_load / max_mileages[vehicle_idx] if max_mileages[vehicle_idx] else 0.0
        context[_TERMINAL_INDEX["RQ"]] = remaining_mileage[vehicle_idx]

        # Ring lock-in: which ring is this vehicle locked to?
        locked_ring = vehicle_current_ring[vehicle_idx]

        results = []

        for arc_idx in active_arcs:
            arc_ring = arc_ring_id[arc_idx]

            # Ring exclusivity: if this ring is owned by a different vehicle,
            # this vehicle cannot touch any arc from it.
            if arc_ring is not None and arc_ring in ring_owner and ring_owner[arc_ring] != vehicle_idx:
                results.append((arc_idx, float("nan")))
                continue

            # Ring lock-in: if vehicle is servicing a ring, it cannot
            # jump to arcs from a different ring.
            if locked_ring is not None and arc_ring != locked_ring:
                results.append((arc_idx, float("nan")))
                continue

            # URARP: check access node constraint
            vehicle_in_service = (locked_ring is not None)
            if not _can_enter_arc_urarp(arc_idx, vehicle_pos, vehicle_in_service,
                                         meta, blocked_access_nodes):
                results.append((arc_idx, float("nan")))
                continue

            # URARP: check range feasibility
            can_serve, _, recharge_cost = _check_range_feasible_urarp(
                vehicle_idx, arc_idx, meta, remaining_mileage, available_facilities,
                current_positions
            )
            if not can_serve:
                results.append((arc_idx, float("nan")))
                continue

            ctt1 = ctt1_map[arc_idx]

            context[_TERMINAL_INDEX["FRT"]] = remaining_fraction
            context[_TERMINAL_INDEX["FUT"]] = unassigned_fraction

            if best_vehicle[arc_idx] != vehicle_idx:
                cfr1 = best_distance[arc_idx]
            else:
                cfr1 = second_distance[arc_idx]
                if math.isinf(cfr1):
                    cfr1 = best_distance[arc_idx]

            rq1 = rq1_remaining.get(arc_idx, 0.0)

            context[_TERMINAL_INDEX["CFH"]] = od[vehicle_pos][start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CFR1"]] = cfr1
            context[_TERMINAL_INDEX["CTT1"]] = ctt1
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = 0.0
            context[_TERMINAL_INDEX["DEM1"]] = 0.0
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["RQ1"]] = rq1
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)

            arc_best_vehicle.setdefault(arc_idx, []).append((vehicle_idx, value))
            results.append((arc_idx, value))

        # Select best and second-best
        if results and not all(_is_nan(v) for _, v in results):
            best_val = None
            for _, v in results:
                if _is_nan(v):
                    continue
                if best_val is None or _is_better(v, best_val):
                    best_val = v
            best_tied = [a for a, v in results if _scores_equal(v, best_val)]
            chosen_best = rng.choice(best_tied)
            best_arc[vehicle_idx] = (chosen_best, best_val)
            best_tied.remove(chosen_best)
            if best_tied:
                chosen_second = rng.choice(best_tied)
                second_val = best_val
                second_arc[vehicle_idx] = (chosen_second, second_val)
            else:
                second_val = None
                for a, v in results:
                    if _is_nan(v) or _scores_equal(v, best_val):
                        continue
                    if second_val is None or _is_better(v, second_val):
                        second_val = v
                if second_val is not None:
                    second_tied = [a for a, v in results if _scores_equal(v, second_val)]
                    chosen_second = rng.choice(second_tied)
                    second_arc[vehicle_idx] = (chosen_second, second_val)

    return best_arc, second_arc, arc_best_vehicle


def evaluate_individual_URARP(individual, instance):
    """
    Evaluate an individual for the URARP problem.

    Key differences from CARP:
    - Range-based routing (not capacity-based)
    - Access node constraints for ring entry
    - Facility recharging
    - Dynamic perturbations (facility/access node/vehicle)
    """
    program = _compile_program(individual)
    meta = _get_seed_meta_urarp(instance)
    erc_seed = _get_individual_erc_seed(individual)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(instance.seed)

    # Apply dynamic perturbations
    unavailable_facilities, blocked_access_nodes = _apply_urarp_perturbations(instance, rng)
    available_facilities = instance.facility_nodes - unavailable_facilities

    current_positions = list(meta["vehicle_positions"])
    remaining_mileage = list(meta["vehicle_mileage"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    service_costs = meta["costs"]
    reverse_index = meta["reverse_index"]
    max_mileage = meta["max_running_mileage"]
    arc_ring_id = meta["arc_ring_id"]

    selected_count = 0
    num_vehicles = len(current_positions)
    vehicle_current_ring = {i: None for i in range(num_vehicles)}
    ring_owner = {}  # ring_id -> vehicle_idx (exclusivity map)

    def _assign_arc_urarp(vehicle_idx, arc_idx):
        """Assign arc to vehicle with URARP constraints."""
        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]
        target_end = end_vertices[arc_idx]
        service_cost = service_costs[arc_idx]
        arc_ring = meta["arc_ring_id"][arc_idx]

        # Lock vehicle into this ring (and claim exclusivity) if not already locked
        if vehicle_current_ring[vehicle_idx] is None and arc_ring is not None:
            vehicle_current_ring[vehicle_idx] = arc_ring
            ring_owner[arc_ring] = vehicle_idx

        # Check if vehicle needs to recharge first
        cost_to_arc = od[curr_pos][target_start]
        total_needed = cost_to_arc + service_cost

        if remaining_mileage[vehicle_idx] < total_needed:
            # Try to recharge at nearest available facility
            fac, fac_cost = _nearest_available_facility(curr_pos, available_facilities, od)
            if fac is not None and fac_cost < float("inf"):
                total_costs[vehicle_idx] += fac_cost
                remaining_mileage[vehicle_idx] = max_mileage
                remaining_mileage[vehicle_idx] -= fac_cost
                curr_pos = fac
            else:
                # Try depot as fallback
                if curr_pos != depot:
                    cost_back = od[curr_pos][depot]
                    total_costs[vehicle_idx] += cost_back
                    remaining_mileage[vehicle_idx] -= cost_back
                remaining_mileage[vehicle_idx] = max_mileage
                curr_pos = depot
                # Recalculate cost from depot
                cost_to_arc = od[depot][target_start]
                total_needed = cost_to_arc + service_cost

        # Travel to arc start
        if curr_pos != target_start:
            travel_cost = od[curr_pos][target_start]
            total_costs[vehicle_idx] += travel_cost
            remaining_mileage[vehicle_idx] -= travel_cost

        # Service the arc
        total_costs[vehicle_idx] += service_cost
        remaining_mileage[vehicle_idx] -= service_cost
        current_positions[vehicle_idx] = target_end

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

        # Check if the locked ring is now fully serviced; if so, free the vehicle
        if vehicle_current_ring[vehicle_idx] is not None:
            locked = vehicle_current_ring[vehicle_idx]
            has_remaining = any(
                arc_ring_id[i] == locked for i in active_arcs
            )
            if not has_remaining:
                vehicle_current_ring[vehicle_idx] = None
                del ring_owner[locked]

    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs_urarp(
            program, meta, active_arcs, current_positions,
            remaining_mileage, available_facilities,
            blocked_access_nodes, vehicle_current_ring,
            ring_owner, selected_count, erc_rng
        )

        assigned_this_round = set()
        winners = {}

        for arc_idx, contenders in arc_best.items():
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
                and not _is_nan(v[1])
            ]
            if not contenders_best:
                continue

            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            if winner_vehicle is not None:
                winners[arc_idx] = winner_vehicle
                assigned_this_round.add(arc_idx)

        for vehicle_idx in range(len(current_positions)):
            if vehicle_idx in {v for v in winners.values()}:
                continue
            if vehicle_idx not in second_arc:
                continue
            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue
            if arc_idx not in set(active_arcs):
                continue

            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            break

        # Ring exclusivity: if multiple vehicles are assigned arcs from the
        # same unowned ring, only the first (lowest vehicle index) keeps it.
        # Remove the others and re-resolve until no ring conflicts remain.
        max_iter = 20
        while max_iter > 0:
            max_iter -= 1
            ring_winners = {}
            for ai, vi in winners.items():
                arc_r = arc_ring_id[ai]
                if arc_r is not None and arc_r not in ring_owner:
                    ring_winners.setdefault(arc_r, []).append((ai, vi))

            conflict = False
            for ring_id, vw_list in ring_winners.items():
                if len(vw_list) <= 1:
                    continue
                vw_list.sort(key=lambda x: x[1])
                for ai, vi in vw_list[1:]:
                    del winners[ai]
                    assigned_this_round.discard(ai)
                conflict = True
                break

            if not conflict:
                break

        for arc_idx, vehicle_idx in winners.items():
            _assign_arc_urarp(vehicle_idx, arc_idx)
            selected_count += 2

    total_assigned = sum(1 for arc_idx in range(len(meta["required_arcs"]))
                         if arc_idx not in set(active_arcs))

    if total_assigned == 0:
        individual.fitness.values = (1e10, 1e10) if configure_parameters.fitnessType == "MIN" else (-1e10, -1e10)
        return individual

    # Penalty for unserved arcs — ensures complete solutions always dominate partial ones
    num_unserved = len(active_arcs)
    if num_unserved > 0:
        # Estimate cost of serving remaining arcs: avg arc cost * unserved count * heavy multiplier
        avg_cost = sum(service_costs[ai] for ai in active_arcs) / num_unserved if num_unserved > 0 else 0
        unserved_penalty = num_unserved * avg_cost * 10.0
        # Add return-to-depot cost for stranded vehicles too
        for vehicle_idx, pos in enumerate(current_positions):
            if pos != depot:
                cost_back = od[pos][depot]
                total_costs[vehicle_idx] += cost_back
        fitness1 = sum(total_costs) + unserved_penalty
        fitness2 = _compute_fitness2(total_costs) + unserved_penalty
        individual.fitness.values = (fitness1, fitness2)
        return individual

    # Return to depot for all vehicles
    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            cost_back = od[pos][depot]
            total_costs[vehicle_idx] += cost_back

    fitness1 = sum(total_costs)
    fitness2 = _compute_fitness2(total_costs)
    individual.fitness.values = (fitness1, fitness2)
    return individual


def _evaluate_individual_URARP_with_erc(individual, instance, erc_seed):
    """evaluate_individual_URARP with explicit erc_seed (no global state)."""
    program = _compile_program(individual)
    meta = _get_seed_meta_urarp(instance)
    erc_rng = random.Random(erc_seed)
    rng = random.Random(instance.seed)

    unavailable_facilities, blocked_access_nodes = _apply_urarp_perturbations(instance, rng)
    available_facilities = instance.facility_nodes - unavailable_facilities

    current_positions = list(meta["vehicle_positions"])
    remaining_mileage = list(meta["vehicle_mileage"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))

    depot = meta["depot"]
    od = meta["od"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    service_costs = meta["costs"]
    reverse_index = meta["reverse_index"]
    max_mileage = meta["max_running_mileage"]
    arc_ring_id = meta["arc_ring_id"]

    selected_count = 0
    num_vehicles = len(current_positions)
    vehicle_current_ring = {i: None for i in range(num_vehicles)}
    ring_owner = {}

    def _assign_arc_urarp(vehicle_idx, arc_idx):
        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]
        target_end = end_vertices[arc_idx]
        service_cost = service_costs[arc_idx]
        arc_ring = meta["arc_ring_id"][arc_idx]

        # Lock vehicle into this ring (claim exclusivity)
        if vehicle_current_ring[vehicle_idx] is None and arc_ring is not None:
            vehicle_current_ring[vehicle_idx] = arc_ring
            ring_owner[arc_ring] = vehicle_idx

        cost_to_arc = od[curr_pos][target_start]
        total_needed = cost_to_arc + service_cost

        if remaining_mileage[vehicle_idx] < total_needed:
            fac, fac_cost = _nearest_available_facility(curr_pos, available_facilities, od)
            if fac is not None and fac_cost < float("inf"):
                total_costs[vehicle_idx] += fac_cost
                remaining_mileage[vehicle_idx] = max_mileage
                remaining_mileage[vehicle_idx] -= fac_cost
                curr_pos = fac
            else:
                if curr_pos != depot:
                    cost_back = od[curr_pos][depot]
                    total_costs[vehicle_idx] += cost_back
                    remaining_mileage[vehicle_idx] -= cost_back
                remaining_mileage[vehicle_idx] = max_mileage
                curr_pos = depot
                cost_to_arc = od[depot][target_start]
                total_needed = cost_to_arc + service_cost

        if curr_pos != target_start:
            travel_cost = od[curr_pos][target_start]
            total_costs[vehicle_idx] += travel_cost
            remaining_mileage[vehicle_idx] -= travel_cost

        total_costs[vehicle_idx] += service_cost
        remaining_mileage[vehicle_idx] -= service_cost
        current_positions[vehicle_idx] = target_end

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

        # Free vehicle when its locked ring is fully serviced
        if vehicle_current_ring[vehicle_idx] is not None:
            locked = vehicle_current_ring[vehicle_idx]
            has_remaining = any(
                arc_ring_id[i] == locked for i in active_arcs
            )
            if not has_remaining:
                vehicle_current_ring[vehicle_idx] = None
                del ring_owner[locked]

    while active_arcs:
        best_arc, second_arc, arc_best = _score_vehicle_arcs_urarp(
            program, meta, active_arcs, current_positions,
            remaining_mileage, available_facilities,
            blocked_access_nodes, vehicle_current_ring,
            ring_owner, selected_count, erc_rng
        )

        assigned_this_round = set()
        winners = {}

        for arc_idx, contenders in arc_best.items():
            contenders_best = [
                v for v in contenders
                if arc_idx == best_arc.get(v[0], (None, None))[0]
                and not _is_nan(v[1])
            ]
            if not contenders_best:
                continue

            winner_vehicle = _select_vehicle_for_arc(arc_idx, contenders_best, rng)
            if winner_vehicle is not None:
                winners[arc_idx] = winner_vehicle
                assigned_this_round.add(arc_idx)

        for vehicle_idx in range(len(current_positions)):
            if vehicle_idx in {v for v in winners.values()}:
                continue
            if vehicle_idx not in second_arc:
                continue
            arc_idx = second_arc[vehicle_idx][0]
            if arc_idx in assigned_this_round:
                continue
            if arc_idx not in set(active_arcs):
                continue

            winners[arc_idx] = vehicle_idx
            assigned_this_round.add(arc_idx)

        if not winners:
            break

        # Ring exclusivity: same as in evaluate_individual_URARP
        max_iter = 20
        while max_iter > 0:
            max_iter -= 1
            ring_winners = {}
            for ai, vi in winners.items():
                arc_r = arc_ring_id[ai]
                if arc_r is not None and arc_r not in ring_owner:
                    ring_winners.setdefault(arc_r, []).append((ai, vi))

            conflict = False
            for ring_id, vw_list in ring_winners.items():
                if len(vw_list) <= 1:
                    continue
                vw_list.sort(key=lambda x: x[1])
                for ai, vi in vw_list[1:]:
                    del winners[ai]
                    assigned_this_round.discard(ai)
                conflict = True
                break

            if not conflict:
                break

        for arc_idx, vehicle_idx in winners.items():
            _assign_arc_urarp(vehicle_idx, arc_idx)
            selected_count += 2

    total_assigned = sum(1 for arc_idx in range(len(meta["required_arcs"]))
                         if arc_idx not in set(active_arcs))

    if total_assigned == 0:
        individual.fitness.values = (1e10, 1e10) if configure_parameters.fitnessType == "MIN" else (-1e10, -1e10)
        return individual

    # Penalty for unserved arcs
    num_unserved = len(active_arcs)
    if num_unserved > 0:
        avg_cost = sum(service_costs[ai] for ai in active_arcs) / num_unserved if num_unserved > 0 else 0
        unserved_penalty = num_unserved * avg_cost * 10.0
        for vehicle_idx, pos in enumerate(current_positions):
            if pos != depot:
                total_costs[vehicle_idx] += od[pos][depot]
        fitness1 = sum(total_costs) + unserved_penalty
        fitness2 = _compute_fitness2(total_costs) + unserved_penalty
        individual.fitness.values = (fitness1, fitness2)
        return individual

    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            total_costs[vehicle_idx] += od[pos][depot]

    fitness1 = sum(total_costs)
    fitness2 = _compute_fitness2(total_costs)
    individual.fitness.values = (fitness1, fitness2)


def _get_seed_meta_urarp(instance):
    """Build metadata dict for URARP evaluation (cached per instance).

    URARP has no demand or capacity — these are set to zeros for compatibility
    with shared precompute functions. GP tree terminals DEM, DEM1, FULL are
    set to 0.0 in URARP scoring.
    """
    meta = getattr(instance, "_fast_eval_meta_urarp", None)
    if meta is not None:
        return meta

    required_arcs = tuple(instance.seed_requiredArc)
    start_vertices = tuple(arc.start_vertex for arc in required_arcs)
    end_vertices = tuple(arc.end_vertex for arc in required_arcs)
    costs = tuple(arc.coste for arc in required_arcs)
    od = instance.seedGraphConnected
    depot = instance.deposito

    arc_ring_id = tuple(getattr(arc, "ring_id", None) for arc in required_arcs)
    arc_ring_seq = tuple(getattr(arc, "ring_sequence", 0) for arc in required_arcs)
    arc_ring_total = tuple(getattr(arc, "ring_total", 0) for arc in required_arcs)

    arc_count = len(required_arcs)
    meta = {
        "required_arcs": required_arcs,
        "reverse_index": _build_reverse_index(required_arcs),
        "start_vertices": start_vertices,
        "end_vertices": end_vertices,
        "costs": costs,
        "arc_to_depot": tuple(od[depot][sv] for sv in start_vertices),
        "depot_to_arc": tuple(od[ev][depot] for ev in end_vertices),
        "deadheading": tuple(od[s][e] for s, e in zip(start_vertices, end_vertices)),
        "inter_arc_distance": _build_inter_arc_distance(start_vertices, end_vertices, od),
        "vehicle_capacity": tuple(v.max_running_mileage for v in instance.vehicles),  # alias for max_mileage
        "vehicle_positions": tuple(v.current_position for v in instance.vehicles),
        "vehicle_costs": tuple(v.total_cost for v in instance.vehicles),
        "vehicle_mileage": tuple(v.remaining_mileage for v in instance.vehicles),
        "depot": depot,
        "od": od,
        "task_num": max(1, arc_count),
        "problem": configure_parameters.problem,
        "arc_ring_id": arc_ring_id,
        "arc_ring_seq": arc_ring_seq,
        "arc_ring_total": arc_ring_total,
        "access_nodes": instance.access_nodes,
        "facility_nodes": instance.facility_nodes,
        "max_running_mileage": instance.max_running_mileage,
        "inter_ring_transfer_cost": instance.inter_ring_transfer_cost,
    }

    instance._fast_eval_meta_urarp = meta
    return meta


def evaluate_population_parallel(pop, sample_list):
    """Evaluate population using multiprocessing.

    Each worker process gets its own copy of the sample list.
    ERC seeds are generated independently per worker but follow the
    same global sequence as serial mode, so results are equivalent.
    """
    import os
    from concurrent.futures import ProcessPoolExecutor

    workers = configure_parameters.parallel_eval_workers
    if workers <= 0:
        workers = os.cpu_count() or 4

    with ProcessPoolExecutor(max_workers=workers,
                              initializer=_init_worker,
                              initargs=(sample_list,)) as executor:
        results = list(executor.map(_eval_single_individual, pop))
        for i, ind in enumerate(results):
            pop[i] = ind
    return pop


def evaluate_population_parallel_test(pop, sample_list):
    """Evaluate population using multiprocessing (test phase variant).

    Uses parallel_eval_test / parallel_eval_test_workers configuration.
    Same logic as evaluate_population_parallel but with separate worker count.
    """
    import os
    from concurrent.futures import ProcessPoolExecutor

    workers = configure_parameters.parallel_eval_test_workers
    if workers <= 0:
        workers = os.cpu_count() or 4

    with ProcessPoolExecutor(max_workers=workers,
                              initializer=_init_worker,
                              initargs=(sample_list,)) as executor:
        results = list(executor.map(_eval_single_individual, pop))
        for i, ind in enumerate(results):
            pop[i] = ind
    return pop
