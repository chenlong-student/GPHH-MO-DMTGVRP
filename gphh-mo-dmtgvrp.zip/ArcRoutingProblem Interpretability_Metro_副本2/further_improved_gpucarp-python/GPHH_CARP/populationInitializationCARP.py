from deap import creator, tools, gp
import psetHoldCARP
from toolBoxCARP import toolbox
import configure_parameters


def _grow_expr():
    """Generate a tree with Grow method, depth in [min, max]."""
    for _ in range(configure_parameters.max_attempts_unique):
        raw = gp.genGrow(
            psetHoldCARP.psetHold(),
            min_=configure_parameters.min_depth_initial_genGrow,
            max_=configure_parameters.max_depth_initial_genGrow,
        )
        tree = gp.PrimitiveTree(raw)
        if tree.height <= configure_parameters.max_depth_initial_genGrow:
            return tree
    return tree


def _full_expr():
    """Generate a tree with Full method, depth in [min, max]."""
    for _ in range(configure_parameters.max_attempts_unique):
        raw = gp.genFull(
            psetHoldCARP.psetHold(),
            min_=configure_parameters.min_depth_initial_genFull,
            max_=configure_parameters.max_depth_initial_genFull,
        )
        tree = gp.PrimitiveTree(raw)
        if tree.height <= configure_parameters.max_depth_initial_genFull:
            return tree
    return tree


def _half_and_half_expr():
    """Half-and-Half: 50% Grow, 50% Full."""
    import random
    if random.random() < 0.5:
        return _grow_expr()
    else:
        return _full_expr()


def register_population(toolbox=toolbox):
    """注册个体和种群初始化操作"""

    gen_method = configure_parameters.population_generation_way

    if gen_method == "genGrow":
        expr_func = _grow_expr
    elif gen_method == "genFull":
        expr_func = _full_expr
    elif gen_method == "genHalfAndHalf":
        expr_func = _half_and_half_expr
    else:
        raise ValueError(f"Unknown population_generation_way: {gen_method}")

    toolbox.register("expr", expr_func)
    toolbox.register("individual", tools.initIterate, creator.IndividualMO, toolbox.expr)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
