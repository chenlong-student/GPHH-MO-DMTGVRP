"""Quick test for clustering pipeline without LLM dependency.

Uses a mock scorer that returns a deterministic Fitness2 based on tree structure.
"""
import sys, os, random, time, math
from copy import deepcopy

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from deap import base, creator, gp, tools

import configure_parameters
import evaluate
import utils
import Instance
import toolboxRegister
import psetHoldCARP
from interp_cluster import (
    build_similarity_matrix, cluster_by_similarity,
    evaluate_fitness2_by_clustering
)

# Mock scorer — returns a pseudo-Fitness2 based on tree size/height
class MockScorer:
    def score(self, ind, behavior_data=None, canonical_text=None):
        size = len(ind)
        height = ind.height
        # Larger/deeper trees get higher complexity score
        return min(100.0, size * 2.0 + height * 5.0 + random.uniform(0, 5))


SEED = 0
PROBLEM = "CARP"
PATH = f"data_{PROBLEM}/kshs/kshs1.dat"

print("=" * 60)
print("Clustering Pipeline Test (Mock Scorer)")
print("=" * 60)

# Setup
creator.create("FitnessMO", base.Fitness, weights=(-1.0, -1.0))
creator.create("IndividualMO", gp.PrimitiveTree, fitness=creator.FitnessMO)

instance = Instance.Instance(PATH, 0)
toolbox = toolboxRegister.toolbox_init(SEED)
pset = psetHoldCARP.psetHold()

toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_=2, max_=6)
toolbox.register("individual", tools.initIterate, creator.IndividualMO, toolbox.expr)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

pop = toolbox.population(n=40)
pop = utils.remove_duplicate_and_refill(pop, toolbox, 100)

# Evaluate Fitness1 (cost) for all individuals
print("\n--- Step 1: Evaluating Fitness1 (cost) ---")
t0 = time.time()
costs = []
for ind in pop:
    fit_sum = 0.0
    fitness_obj = ind.fitness
    for sample in instance.instanceSeedList:
        evaluate.evaluate_individual(ind, sample)
        fit_sum += ind.fitness
        ind.fitness = fitness_obj
    avg_cost = fit_sum / len(instance.instanceSeedList)
    ind.fitness.values = (avg_cost, 50.0)  # placeholder
    costs.append(avg_cost)
print(f"  Done in {time.time()-t0:.2f}s")
print(f"  Cost range: [{min(costs):.2f}, {max(costs):.2f}]")

# Build similarity matrix (no embedding)
print("\n--- Step 2: Building Similarity Matrix (s1=cost, s2=AST, s3=skip) ---")
t0 = time.time()
from main_gphh_arp_interpretability import _individual_canonical, _primitive_tree_to_ast

scorer = MockScorer()
sim_matrix, sim_details = build_similarity_matrix(
    pop, scorer, pset, api_key=None, weights=(0.5, 0.5, 0.0)
)
print(f"  Done in {time.time()-t0:.2f}s")

# Show similarity stats
sims = []
n = len(pop)
for i in range(n):
    for j in range(i+1, n):
        sims.append(sim_matrix[i][j])
print(f"  Similarity stats: min={min(sims):.4f}, max={max(sims):.4f}, "
      f"mean={sum(sims)/len(sims):.4f}")

# Cluster
print("\n--- Step 3: Clustering (threshold=0.55) ---")
t0 = time.time()
clusters = cluster_by_similarity(sim_matrix, threshold=0.55)
print(f"  Done in {time.time()-t0:.2f}s")
print(f"  Found {len(clusters)} clusters:")
for ci, c in enumerate(clusters):
    cluster_costs = [costs[i] for i in c]
    print(f"    Cluster {ci+1:2d}: {len(c):3d} individuals  "
          f"cost range=[{min(cluster_costs):.1f}, {max(cluster_costs):.1f}]")

# Evaluate with mock scorer + KNN
print("\n--- Step 4: Representative LLM + KNN Interpolation ---")
t0 = time.time()
behavior_instance = instance.instanceSeedList[0] if instance.instanceSeedList else instance
sim_details_for_knn = sim_details  # not used by KNN, just pass through
interp_cache, stats = evaluate_fitness2_by_clustering(
    pop, scorer, behavior_instance, sim_matrix, sim_details_for_knn,
    clusters, api_key=None, k_representatives=1, k_knn=3,
    weights=(0.5, 0.5, 0.0)
)
print(f"  Done in {time.time()-t0:.2f}s")
print(f"\n  Statistics:")
print(f"    Clusters: {stats['n_clusters']}")
print(f"    LLM calls (representatives): {stats['n_llm_calls']}")
print(f"    KNN predictions: {stats['n_knn_preds']}")
print(f"    LLM calls saved: {len(pop) - stats['n_llm_calls']} "
      f"({100*(1 - stats['n_llm_calls']/len(pop)):.1f}%)")

# Show results
print("\n--- Step 5: Results ---")
print(f"{'#':>3} {'Cluster':>7} {'Cost':>10} {'Fitness2':>10} {'Method':>6} {'Tree (truncated)':<50}")
print("-" * 100)

for i, ind in enumerate(pop):
    canon_str, _ = _individual_canonical(ind)
    f2 = interp_cache.get(canon_str, 99.9)
    method = "LLM" if canon_str in interp_cache and i in [
        sorted(c, key=lambda x: pop[x].fitness.values[0])[0] for c in clusters
    ] else "KNN"
    # Determine if this individual was a representative
    is_rep = False
    for c in clusters:
        rep = sorted(c, key=lambda x: pop[x].fitness.values[0])[0]
        if i == rep:
            is_rep = True
            break
    method = "LLM" if is_rep else "KNN"

    cluster_id = -1
    for ci, c in enumerate(clusters):
        if i in c:
            cluster_id = ci + 1
            break

    tree_str = str(ind)[:48]
    print(f"{i+1:>3} {cluster_id:>7} {ind.fitness.values[0]:>10.2f} {f2:>10.2f} {method:>6} {tree_str:<50}")

# Verify KNN differentiation
print("\n--- KNN Differentiation Check ---")
f2_values = []
for ind in pop:
    canon_str, _ = _individual_canonical(ind)
    f2 = interp_cache.get(canon_str, 0)
    f2_values.append(f2)

unique_f2 = len(set(round(v, 2) for v in f2_values))
print(f"  Unique Fitness2 values: {unique_f2} / {len(f2_values)}")
print(f"  Fitness2 range: [{min(f2_values):.2f}, {max(f2_values):.2f}]")
print(f"  Fitness2 mean: {sum(f2_values)/len(f2_values):.2f}")
print(f"  Fitness2 std:  {math.sqrt(sum((v-sum(f2_values)/len(f2_values))**2 for v in f2_values)/len(f2_values)):.2f}")

print("\n" + "=" * 60)
print("CLUSTERING PIPELINE TEST PASSED")
print("=" * 60)
