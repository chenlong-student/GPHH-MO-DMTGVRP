import fitnessType
from deap import base, creator, gp


def create_fitness_and_individual():
    """Define multi-objective fitness and individual for NSGA-II.

    FitnessMO: two objectives, both minimized (weights=-1.0):
      - Fitness values[0]: total cost
      - Fitness values[1]: max mileage difference among active vehicles

    Also creates FitnessMin/Individual as aliases for backwards compatibility
    with main_gphh_metro.py.
    """

    if "FitnessMO" not in creator.__dict__:
        creator.create("FitnessMO", base.Fitness, weights=(-1.0, -1.0))

    if "IndividualMO" not in creator.__dict__:
        creator.create("IndividualMO", gp.PrimitiveTree, fitness=creator.FitnessMO)

    # Backwards-compat aliases (used by main_gphh_metro.py)
    if "FitnessMin" not in creator.__dict__:
        creator.FitnessMin = creator.FitnessMO
    if "Individual" not in creator.__dict__:
        creator.Individual = creator.IndividualMO

    return creator
