##数据集使用:they can be download in https://www.uv.es/belengue/carp.html

problem = "URARP"  ##"CPP" or "URARP"
instance_set = "gdb"
instance_ele = "gdb1"
data_path = f"data_{problem}/{instance_set}/{instance_ele}.dat"

# data_path = f"data_{problem}/manual_cl/manual.dat"
# data_path = f"data_{problem}/kshs/kshs1.dat"
# data_path = f"data_{problem}/gdb/gdb1.dat"
# data_path = f"data_{problem}/val/val1A.dat"
# data_path = f"data_{problem}/egl/egl-e1-B.dat"

##随机种子
seed = 0

##instance中里程扰动幅度
cost_change_rate = 0.20     ## URARP-specific dynamic perturbation parameters
facility_change_rate = 0.10    # probability that a facility becomes unavailable
entrances_change_rate = 0.10   # probability that an access node is blocked
vehicle_change_rate = 0.05     # probability that a vehicle breaks down

##目标函数类型
fitnessType = 'MIN' ##or 'MAX'

##演化次数
gen = 51

##种群初始化
##种群规模
population_size = 512 ##1024

##种群初始化方式
population_generation_way = "genHalfAndHalf"   ## "genFull" or "genGrow" or "genHalfAndHalf"
##初始种群深度约束（Grow 方式）
min_depth_initial_genGrow = 4
max_depth_initial_genGrow = 4
##初始种群深度约束（Full 方式）
min_depth_initial_genFull = 2
max_depth_initial_genFull = 6

##交叉/变异后深度上限（重试策略）
max_cross_depth = 8
max_mutate_depth = 8
##Mutation replacement subtree max depth = 4 (matches ECJ default)
max_mutate_subtree_depth = 4
##交叉/变异重试次数上限
max_attempts_unique = 500

##种群繁衍
##父代选择方式
selection_way = "selTournament" ## or "selBest"
##锦标赛选择前7个
tourn_size = 7
##变异概率
mutate_probability = 0.15
##交叉概率
crossover_probability = 0.80
##重复概率
reproduct_probability = 1 - mutate_probability - crossover_probability

##gphh节点设置
##gphh_terminals: you can set them in "State.py" and use them in "terminalStateCARP.py" and "terminalSetARP.py"
terminals_from = "extended" ## or "basic"
include_erc = True

gpTerminal_CFH = "CFH" ##or None
gpTerminal_CFD = "CFD"
gpTerminal_CFR1 = "CFR1"
gpTerminal_CTT1 = "CTT1"
gpTerminal_CTD = "CTD"
gpTerminal_CR = "CR"
gpTerminal_DEM = "DEM"
gpTerminal_DEM1 = "DEM1"
gpTerminal_DC = "DC"
gpTerminal_FULL = "FULL"
gpTerminal_FRT = "FRT"
gpTerminal_FUT = "FUT"
gpTerminal_RQ = "RQ"
gpTerminal_RQ1 = "RQ1"
gpTerminal_SC = "SC"
gpTerminal_ERC = "ERC"

##gphh_functions: you can set them in "functions.py" and use them in "functionSet.py"
gpFunction_add = "add" ## or None
gpFunction_sub = "sub"
gpFunction_mul = "mul"
gpFunction_div = "div"
gpFunction_max = "max"
gpFunction_min = "min"
gpFunction_if = None
gpFunction_sin = None
gpFunction_cos = None
gpFunction_exp = None
gpFunction_ln = None
gpFunction_neg = None
gpFunction_sqrt = None
gpFunction_abs = None

##evaluation model
training_sample_num = 5
testing_sample_num = 250    ##500

##ERC（临时随机常量）种子：固定则跨代不变，None则跟随instance.seed变化
erc_seed = None

seed_gap_rotation = training_sample_num + training_sample_num
seed_gap_instance = 1

evaluation_seed = (1 + seed) * (100 + (training_sample_num + seed_gap_rotation + 3) * gen)

##in Instance.py for build_test_samples function
testing_seed = (evaluation_seed
                + 300 * (gen * (training_sample_num + seed_gap_rotation) + 100)
                + 700
                + 2000)
# testing_seed = -1

rotate_eval_model = True

##并行评估设置
parallel_eval = True          ## 是否启用多进程并行评估
parallel_eval_workers = 0     ## 0 = 使用所有可用 CPU 核心，>0 = 指定进程数

##测试阶段并行评估设置
parallel_eval_test = True          ## 是否启用多进程并行评估（测试阶段）
parallel_eval_test_workers = 0     ## 0 = 使用所有可用 CPU 核心，>0 = 指定进程数

combinePopulation = False
printVehiclesRoute = False
