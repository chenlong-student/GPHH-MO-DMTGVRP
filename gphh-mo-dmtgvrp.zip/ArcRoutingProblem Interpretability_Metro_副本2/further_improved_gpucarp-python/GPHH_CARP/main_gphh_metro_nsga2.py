import os
import time
import random
import statistics
import csv
from copy import deepcopy

import toolboxRegister
import configure_parameters
import breeding
import evaluate
import utils
import Instance
import psetHoldCARP
import math
from deap import tools
from deap import gp
from Instance import SeededSample
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _build_offspring_instances(instance, gen):
    """Build a separate set of instances for offspring evaluation.

    For generation s, offspring is evaluated on instances with seeds
    starting at evaluation_seed + (gen + 1 + configure_parameters.gen) * seed_gap_rotation.
    This is offset by one full run from pop instances so they never overlap.
    """
    start_seed = configure_parameters.evaluation_seed + (gen + 1 + configure_parameters.gen) * configure_parameters.seed_gap_rotation
    seeds = [start_seed + i * configure_parameters.seed_gap_instance
             for i in range(configure_parameters.training_sample_num)]
    return [SeededSample(instance, s) for s in seeds]


def _normalize(value, v_min, v_max):
    """Min-max normalize to [0, 1]. Clamp out-of-range values."""
    if v_max == v_min:
        return 0.5
    norm = (value - v_min) / (v_max - v_min)
    return max(0.0, min(1.0, norm))


def _plot_population_nor(SEED, PROBLEM, PATH, instance_ele, pop_parent, pop_offspring, pop_combined, pop_selected, gen_id, plot_dir, front_info=None):
    """Plot population distribution in normalized objective space.

    Top-left:     parent population (before crossover/mutation)
    Top-right:    offspring population (after crossover/mutation)
    Bottom-left:  combined (parent + offspring) population
    Bottom-right: selected population (after NSGA-II selection & evaluation)
    Saves one PNG per generation to *plot_dir*.
    """
    all_f1 = ([ind.fitness.values[0] for ind in pop_parent]
              + [ind.fitness.values[0] for ind in pop_offspring]
              + [ind.fitness.values[0] for ind in pop_combined]
              + [ind.fitness.values[0] for ind in pop_selected])
    all_f2 = ([ind.fitness.values[1] for ind in pop_parent]
              + [ind.fitness.values[1] for ind in pop_offspring]
              + [ind.fitness.values[1] for ind in pop_combined]
              + [ind.fitness.values[1] for ind in pop_selected])
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_parent = _raw_vals(pop_parent)
    xy_offspring = _raw_vals(pop_offspring)
    xy_combined = _raw_vals(pop_combined)
    xy_selected = _raw_vals(pop_selected)

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_parent], [v[1] for v in xy_parent],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Parent population  (n={len(pop_parent)})")

    ax_tr.scatter([v[0] for v in xy_offspring], [v[1] for v in xy_offspring],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Offspring population  (n={len(pop_offspring)})")

    ax_bl.scatter([v[0] for v in xy_combined], [v[1] for v in xy_combined],
                  s=8, alpha=0.6, edgecolors="none", color="tab:green")
    ax_bl.set_title(f"Combined population  (n={len(pop_combined)})")

    ax_br.scatter([v[0] for v in xy_selected], [v[1] for v in xy_selected],
                  s=8, alpha=0.6, edgecolors="none", color="tab:red")
    ax_br.set_title(f"New parent population  (n={len(pop_selected)})")

    title = f"Generation {gen_id} — standard - NSGA-II"
    if front_info:
        title += f" — {front_info}"
    fig.suptitle(title, fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"{PROBLEM}-{instance_ele}-{SEED}-gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_train_test_comparison(pop_train, pop_test, gen_id, plot_dir, problem_name, instance_ele, seed):
    """Plot population distribution on training vs test sets (4-subplot figure).

    Top-left:     full population on training instances
    Top-right:    full population on test instances
    Bottom-left:  Pareto front (non-dominated) on training instances
    Bottom-right: Pareto front on test instances
    """
    pareto_train = _get_pareto_front(pop_train)
    pareto_test = _get_pareto_front(pop_test)

    all_pops = [pop_train, pop_test, pareto_train, pareto_test]
    all_f1 = [ind.fitness.values[0] for pop in all_pops for ind in pop]
    all_f2 = [ind.fitness.values[1] for pop in all_pops for ind in pop]
    min_f1, max_f1 = min(all_f1), max(all_f1)
    min_f2, max_f2 = min(all_f2), max(all_f2)

    def _raw_vals(pop):
        return [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop]

    xy_train = _raw_vals(pop_train)
    xy_test = _raw_vals(pop_test)
    xy_pareto_train = _raw_vals(pareto_train)
    xy_pareto_test = _raw_vals(pareto_test)

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    ax_tl, ax_tr = axes[0]
    ax_bl, ax_br = axes[1]

    for ax in (ax_tl, ax_tr, ax_bl, ax_br):
        ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
        ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
        ax.set_xlabel("F1")
        ax.set_ylabel("F2")

    ax_tl.scatter([v[0] for v in xy_train], [v[1] for v in xy_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_tl.set_title(f"Full population — Train  (n={len(pop_train)})")

    ax_tr.scatter([v[0] for v in xy_test], [v[1] for v in xy_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_tr.set_title(f"Full population — Test  (n={len(pop_test)})")

    ax_bl.scatter([v[0] for v in xy_pareto_train], [v[1] for v in xy_pareto_train],
                  s=8, alpha=0.6, edgecolors="none", color="tab:blue")
    ax_bl.set_title(f"Pareto front — Train  (n={len(pareto_train)})")

    ax_br.scatter([v[0] for v in xy_pareto_test], [v[1] for v in xy_pareto_test],
                  s=8, alpha=0.6, edgecolors="none", color="tab:orange")
    ax_br.set_title(f"Pareto front — Test  (n={len(pareto_test)})")

    fig.suptitle(f"Generation {gen_id} — Train vs Test — NSGA-II", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, f"{problem_name}-{instance_ele}-{seed}-train_vs_test_gen_{gen_id:04d}.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _plot_population_test(pop_tested, plot_dir, filename="test_distribution.png"):
    """Plot population distribution in normalized objective space after testing.

    Single scatter plot showing all individuals evaluated on test instances.
    """
    f1_vals = [ind.fitness.values[0] for ind in pop_tested]
    f2_vals = [ind.fitness.values[1] for ind in pop_tested]
    min_f1, max_f1 = min(f1_vals), max(f1_vals)
    min_f2, max_f2 = min(f2_vals), max(f2_vals)

    xy_vals = [(ind.fitness.values[0], ind.fitness.values[1]) for ind in pop_tested]

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter([v[0] for v in xy_vals], [v[1] for v in xy_vals],
               s=8, alpha=0.6, edgecolors="none", color="tab:purple")
    ax.set_xlim(min_f1 - (max_f1 - min_f1) * 0.05, max_f1 + (max_f1 - min_f1) * 0.05)
    ax.set_ylim(min_f2 - (max_f2 - min_f2) * 0.05, max_f2 + (max_f2 - min_f2) * 0.05)
    ax.set_xlabel("F1")
    ax.set_ylabel("F2")
    ax.set_title(f"Test population  (n={len(pop_tested)})")
    fig.suptitle("Population on test set", fontsize=13, y=0.995)
    fig.tight_layout()

    os.makedirs(plot_dir, exist_ok=True)
    fig.savefig(os.path.join(plot_dir, filename), dpi=150, bbox_inches="tight")
    plt.close(fig)


def _mean(values):
    if not values:
        return 0.0
    return statistics.fmean(values)


def _std(values):
    if len(values) <= 1:
        return 0.0
    mean = statistics.fmean(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


def _program_size(individual):
    return len(individual)


def _unique_terminal_num(individual):
    terminal_set = set()

    for node in individual:
        node_name = getattr(node, "name", None)
        node_arity = getattr(node, "arity", None)

        if node_name is not None and node_arity == 0:
            terminal_set.add(node_name)

    return len(terminal_set)


def _write_stat_title(file_path):
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(
            "Gen,BestFit1,BestFit2,BestFit1Mean,BestFit1Std,BestFit2Mean,BestFit2Std,"
            "ProgSizeMean,ProgSizeStd,PopSize,ParetoFrontSize\n"
        )


def _append_stat(file_path, gen_id, population, best_ind, pareto_front_size):
    prog_size_list = [_program_size(ind) for ind in population]
    fit1_list = [ind.fitness.values[0] for ind in population]
    fit2_list = [ind.fitness.values[1] for ind in population]

    best_fit1 = best_ind.fitness.values[0]
    best_fit2 = best_ind.fitness.values[1]
    best_ind_str = f'"{str(best_ind)}"'

    with open(file_path, "a", encoding="utf-8") as file:
        file.write(
            f"{gen_id},{best_fit1},{best_fit2},{_mean(fit1_list)},{_std(fit1_list)},"
            f"{_mean(fit2_list)},{_std(fit2_list)},{_mean(prog_size_list)},{_std(prog_size_list)},"
            f"{len(population)},{pareto_front_size}\n"
        )


def _append_best_rule(file_path, gen_id, individual):
    with open(file_path, "a", encoding="utf-8") as file:
        file.write(f"Generation {gen_id}\n")
        file.write(f"Fitness1 (total cost): {individual.fitness.values[0]}\n")
        file.write(f"Fitness2 (mileage diff): {individual.fitness.values[1]}\n")
        file.write(f"Rule: {individual}\n\n")


def _get_pareto_front(population):
    """Return the first non-dominated front of the population."""
    fronts = tools.sortNondominated(population, len(population))
    if fronts and fronts[0]:
        return fronts[0]
    return population


def _build_cfh_individual(primitive_set):
    """Build a manual 'CFH' individual -- nearest-neighbor heuristic."""
    from deap import creator
    cfh_terminal = None
    for node in primitive_set.terminals[object]:
        if node.name == "CFH":
            cfh_terminal = node
            break
    if cfh_terminal is None:
        raise ValueError("CFH terminal not found in primitive set")
    tree_nodes = [cfh_terminal]
    tree = gp.PrimitiveTree(tree_nodes)
    ind = creator.IndividualMO(tree)
    return ind


def main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE):
    from deap import gp, creator

    if SEED is None:
        seed = configure_parameters.seed
    else:
        seed = SEED

    if PROBLEM is None:
        problem_name = configure_parameters.problem
    else:
        problem_name = PROBLEM

    if PATH is None:
        instance_path = configure_parameters.data_path
    else:
        instance_path = PATH

    if INSTANCE_SET is None:
        instance_set = configure_parameters.instance_set
    else:
        instance_set = INSTANCE_SET

    if INSTANCE_ELE is None:
        instance_ele = configure_parameters.instance_ele
    else:
        instance_ele = INSTANCE_ELE

    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)

    # ------------------------------------------------------------------
    # All output files go under output_stand/ to avoid colliding with
    # other experiment variants (e.g., output_test/ for the test variant).
    # ------------------------------------------------------------------
    output_base = os.path.join(current_dir, "output_stand")
    os.makedirs(output_base, exist_ok=True)

    instance_name = os.path.splitext(os.path.basename(instance_path))[0]

    # ========== 1. Load instance ==========
    instance = Instance.Instance(instance_path, 0)

    # ========== 2. Toolbox init ==========
    toolbox = toolboxRegister.toolbox_init(seed)

    # Seed RNG once at the start; do NOT re-seed per generation
    random.seed(seed)

    # ========== 3. Population init ==========
    # Reset RNG immediately before population generation so both programs
    # produce the exact same initial population independently.
    random.seed(seed + 42)
    pop = toolbox.population(n=configure_parameters.population_size)
    pop = utils.remove_duplicate_and_refill(pop, toolbox, configure_parameters.max_attempts_unique)

    # ========== 4. Initial fitness evaluation ==========
    if configure_parameters.parallel_eval:
        pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
    else:
        pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

    # ========== 5. Output files init ==========
    out_stat_path = os.path.join(output_base, "train", f"{instance_name}-{seed}-{problem_name}.out.stat")
    stat_csv_path = os.path.join(output_base, "train", f"{instance_name}-{seed}-{problem_name}.stat.csv")
    os.makedirs(os.path.dirname(out_stat_path), exist_ok=True)
    test_dir = output_base
    os.makedirs(test_dir, exist_ok=True)

    open(out_stat_path, "w", encoding="utf-8").close()
    _write_stat_title(stat_csv_path)

    # ========== 6. NSGA-II evolution ==========
    best_ind_pop = []
    global_best_ind = None  # Track best-so-far by Fitness1

    for s in range(configure_parameters.gen):
        start_time_gen = time.time()

        # === Step 1: pop_parent is the evaluated population from previous iteration ===
        # Get Pareto front and best individual (lowest Fitness1 on front)
        pareto_front = _get_pareto_front(pop_parent)
        best_ind = min(pareto_front, key=lambda ind: ind.fitness.values[0])
        best_ind_copy = deepcopy(best_ind)
        best_ind_pop.append(best_ind_copy)

        # Update global best-so-far (by Fitness1)
        if global_best_ind is None:
            global_best_ind = deepcopy(best_ind_copy)
        else:
            if best_ind.fitness.values[0] < global_best_ind.fitness.values[0]:
                global_best_ind = deepcopy(best_ind_copy)

        _append_best_rule(out_stat_path, s, best_ind)
        _append_stat(stat_csv_path, s, pop_parent, best_ind, len(pareto_front))

        print()
        print(f"================ Train Process in The {s}-th Generation =================")
        print(f"Pareto front size: {len(pareto_front)}")
        print("Best individual (lowest total cost on Pareto front):")
        print(best_ind)
        print(f"  Fitness1 (total cost): {best_ind.fitness.values[0]:.2f}")
        print(f"  Fitness2 (mileage diff): {best_ind.fitness.values[1]:.2f}")

        # Print vehicle routes for best-so-far individual
        if configure_parameters.printVehiclesRoute:
            evaluate.print_vehicle_routes(global_best_ind, instance)

        # Save original parent reference for plotting (before reassignment)
        orig_parent = pop_parent

        # === Step 2: pop_parent produces offspring via crossover/mutation ===
        offspring = breeding.breeding_population(
            pop_parent, toolbox,
            target_size=configure_parameters.population_size,
        )

        # === Step 3: Evaluate offspring → pop_offspring (on alternate instances) ===
        offspring_instances = _build_offspring_instances(instance, s)
        if configure_parameters.parallel_eval:
            pop_offspring = evaluate.evaluate_population_parallel(offspring, offspring_instances)
        else:
            pop_offspring = evaluate.evaluate_population(offspring, offspring_instances)

        # === Step 4: pop_parent + pop_offspring → pop_combined ===
        pop_combined = pop_parent + pop_offspring

        # === Step 5: NSGA-II survivor selection → pop_selected ===
        pop_selected = toolbox.select(pop_combined, configure_parameters.population_size)

        # Compute front info for plotting
        fronts = tools.sortNondominated(pop_combined, len(pop_combined))
        N = configure_parameters.population_size
        cumulative = 0
        last_front_idx = 0
        last_front_total = 0
        last_front_selected = 0
        for i, front in enumerate(fronts):
            if cumulative + len(front) <= N:
                cumulative += len(front)
                last_front_idx = i + 1
                last_front_total = len(front)
                last_front_selected = len(front)
            else:
                remaining = N - cumulative
                last_front_idx = i + 1
                last_front_total = len(front)
                last_front_selected = remaining
                break
        if last_front_selected < last_front_total:
            front_info = f"The {last_front_idx} -th front (count_selected / total_count {last_front_selected}/{last_front_total})"
        else:
            front_info = f"The {last_front_idx} -th front"

        # Build new individuals from selected so clearing fitness doesn't affect orig_parent/pop_offspring
        pop = [type(ind)(ind) for ind in pop_selected]

        # === Step 6: Clear fitness on pop so they are in unevaluated state ===
        for ind in pop:
            del ind.fitness.values

        # === Step 7: Rotate eval model before re-evaluation ===
        if configure_parameters.rotate_eval_model:
            instance.resetSeedInstance(seed, configure_parameters, s + 1)

        # === Step 8: Evaluate pop → pop_parent (for next iteration) ===
        if configure_parameters.parallel_eval:
            pop_parent = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
        else:
            pop_parent = evaluate.evaluate_population(pop, instance.instanceSeedList)

        # Plot population distribution in normalized objective space
        _plot_population_nor(
            seed,
            problem_name,
            instance_path,
            instance_ele,
            orig_parent, pop_offspring, pop_combined, pop_parent, s,
            os.path.join(output_base, "train", "plots_nor_nsga2", f"{instance_set}", f"{instance_ele}"),
            front_info=front_info,
        )

        end_time_eval = time.time()

        # Print average statistics
        avg_fit1 = _mean([ind.fitness.values[0] for ind in pop_parent])
        avg_fit2 = _mean([ind.fitness.values[1] for ind in pop_parent])
        print(f"The average Fitness1 (total cost): {avg_fit1:.2f}")
        print(f"The average Fitness2 (mileage diff): {avg_fit2:.2f}")

        end_time_gen = time.time()

    # ========== 7. Testing phase ==========
    print("\n================ Testing Process =================\n")

    final_pareto = _get_pareto_front(pop_parent)
    print(f"Final training Pareto front: {len(final_pareto)} solutions\n")

    # Save full pop_parent fitness (before testing overwrites them)
    pop_train = deepcopy(pop_parent)

    test_sample_list = instance.build_test_samples()
    test_csv_path = os.path.join(test_dir, "test", f"{instance_name}-{seed}-{problem_name}.stat.csv")
    os.makedirs(os.path.dirname(test_csv_path), exist_ok=True)

    # Test the final training Pareto front on test instances
    test_individuals = deepcopy(final_pareto)
    if configure_parameters.parallel_eval_test:
        test_individuals = evaluate.evaluate_population_parallel_test(test_individuals, test_sample_list)
    else:
        for ind in test_individuals:
            evaluate.evaluate_batch(ind, test_sample_list)
    for ind in test_individuals:
        print(f"  {ind}")
        print(f"    Test Fitness1 (total cost): {ind.fitness.values[0]:.2f}")
        print(f"    Test Fitness2 (mileage diff): {ind.fitness.values[1]:.2f}")

    # Evaluate full pop_parent on test set as well
    test_pop_full = deepcopy(pop_parent)
    if configure_parameters.parallel_eval_test:
        test_pop_full = evaluate.evaluate_population_parallel_test(test_pop_full, test_sample_list)
    else:
        for ind in test_pop_full:
            evaluate.evaluate_batch(ind, test_sample_list)

    # Plot train vs test comparison (4-subplot figure)
    _plot_train_test_comparison(
        pop_train, test_pop_full, configure_parameters.gen,
        os.path.join(output_base, "train", "plots_nor_nsga2", f"{instance_set}", f"{instance_ele}"),
    problem_name, instance_ele, seed
    )

    # Find non-dominated front based on TEST fitness values (from full population)
    test_fronts = tools.sortNondominated(test_pop_full, len(test_pop_full))
    test_pareto = test_fronts[0] if test_fronts else test_pop_full
    test_pareto_sorted = sorted(test_pareto, key=lambda ind: ind.fitness.values[0])

    # Write test results CSV (full population evaluated on test set)
    with open(test_csv_path, "w", encoding="utf-8") as file:
        file.write("Index,TestFit1,TestFit2,ProgramSize,UniqueTerminals,Individual\n")
        for idx, ind in enumerate(test_pop_full):
            file.write(
                f"{idx},{ind.fitness.values[0]},{ind.fitness.values[1]},"
                f"{_program_size(ind)},{_unique_terminal_num(ind)},\"{str(ind)}\"\n"
            )

    # Save test-based Pareto front to pareto_fronts/ under output_stand/
    pareto_dir = os.path.join(output_base, "pareto_fronts", f"{instance_set}-nsga2")
    os.makedirs(pareto_dir, exist_ok=True)
    pareto_csv_path = os.path.join(
        pareto_dir, f"{instance_name}-{seed}-NSGA2-pareto.csv"
    )
    with open(pareto_csv_path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Individual", "F1", "F2"])
        for ind in test_pareto_sorted:
            writer.writerow([str(ind), ind.fitness.values[0], ind.fitness.values[1]])
    print(f"\nTest Pareto front ({len(test_pareto_sorted)} solutions) saved to: {pareto_csv_path}")

    print(f"Experiment out.stat saved to: {out_stat_path}")
    print(f"Experiment stat.csv saved to: {stat_csv_path}")
    print(f"Experiment test csv saved to: {test_csv_path}")


if __name__ == "__main__":
    a = time.time()

    SEED = None
    PROBLEM = None
    PATH = None
    INSTANCE_SET = None
    INSTANCE_ELE = None

    main(SEED, PROBLEM, PATH, INSTANCE_SET, INSTANCE_ELE)

    print('total time', time.time() - a)
