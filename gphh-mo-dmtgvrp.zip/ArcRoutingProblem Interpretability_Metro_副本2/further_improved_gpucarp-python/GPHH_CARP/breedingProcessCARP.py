from deap import tools, gp
import psetHoldCARP
import configure_parameters


def register_breeding_ops(toolbox):
    """Register selection, crossover, and mutation operators for NSGA-II."""

    pset = psetHoldCARP.psetHold()

    # NSGA-II survivor selection (used in main loop)
    toolbox.register("select", tools.selNSGA2)
    # Tournament by crowding distance for parent selection
    toolbox.register("select_mating", tools.selTournamentDCD, tournsize=2)

    toolbox.register("mate", gp.cxOnePoint)

    toolbox.register("expr_mut", gp.genFull, min_=0, max_=configure_parameters.max_mutate_subtree_depth)
    toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)
