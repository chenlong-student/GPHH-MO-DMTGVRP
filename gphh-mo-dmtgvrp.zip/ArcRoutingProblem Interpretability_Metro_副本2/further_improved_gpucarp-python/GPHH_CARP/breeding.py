import random
from copy import deepcopy
from deap import tools, gp, creator

import configure_parameters


def _copy_individual(ind):
    child = deepcopy(ind)
    # Reset fitness properly after deepcopy (del breaks DEAP's descriptor)
    if hasattr(child, "fitness"):
        child.fitness = creator.FitnessMO()
    return child


def _copy_individual_new(ind):
    """Create a copy with cleared ERC seed (for crossover/mutation offspring).
    Reproduction clones use _copy_individual which preserves the ERC seed."""
    child = _copy_individual(ind)
    if hasattr(child, "_erc_seed_cached"):
        del child._erc_seed_cached
    return child


def _tree_depth(individual):
    """Return the max tree depth across all trees in an individual."""
    if hasattr(individual, 'height'):
        return individual.height
    return 0


def _mate_with_retry(parent1, parent2, max_depth, max_attempts, toolbox):
    """Koza-style crossover with depth retry.

    Mirrors ECJ CrossoverPipeline:
    - Try crossover up to max_attempts times
    - If valid (both children within depth limit), return both
    - If retries exhausted and at least one child is valid, do the valid one
      and clone the other parent
    - If no valid attempt found, clone both parents (reproduction fallback)
    """
    best_attempt = None  # (child1, child2, both_valid)

    for _ in range(max_attempts):
        c1 = _copy_individual_new(parent1)
        c2 = _copy_individual_new(parent2)
        toolbox.mate(c1, c2)
        d1 = _tree_depth(c1)
        d2 = _tree_depth(c2)
        if d1 <= max_depth and d2 <= max_depth:
            return c1, c2  # Both valid — accept immediately
        # Track the best attempt (at least one child valid)
        if best_attempt is None:
            best_attempt = (c1, c2, d1 <= max_depth, d2 <= max_depth)

    # Retries exhausted — use best attempt or fallback to clones
    if best_attempt is not None:
        c1, c2, v1, v2 = best_attempt
        if v1 and v2:
            return c1, c2
        elif v1:
            # Only child1 valid — clone parent2
            return c1, _copy_individual(parent2)
        elif v2:
            # Only child2 valid — clone parent1
            return _copy_individual(parent1), c2
        else:
            # Neither valid — clone both
            return _copy_individual(parent1), _copy_individual(parent2)
    else:
        # No attempts made (shouldn't happen)
        return _copy_individual(parent1), _copy_individual(parent2)


def _mutate_with_retry(parent, max_depth, max_attempts, toolbox):
    """Koza-style mutation with depth retry.

    Mirrors ECJ MutationPipeline:
    - Try mutation up to max_attempts times
    - If valid (child within depth limit), return it
    - If retries exhausted, clone the parent (no mutation)
    """
    for _ in range(max_attempts):
        child = _copy_individual_new(parent)
        toolbox.mutate(child)
        if _tree_depth(child) <= max_depth:
            return child  # Valid — accept
    # Retries exhausted — clone parent (skip mutation)
    return _copy_individual(parent)


def _select_parents_dcd(pop, n, toolbox, tournsize):
    """Select n parents using crowding-distance tournament (DCD).

    Falls back to random selection if DCD is unavailable.
    """
    if hasattr(toolbox, "select_mating"):
        try:
            return toolbox.select_mating(pop, n)
        except Exception:
            pass
    # Fallback: random selection
    return [pop[random.randint(0, len(pop) - 1)] for _ in range(n)]


def breeding_population(pop, toolbox,
                        seed=configure_parameters.seed,
                        cxpb=configure_parameters.crossover_probability,
                        mutpb=configure_parameters.mutate_probability,
                        reppb=configure_parameters.reproduct_probability,
                        tournsize=configure_parameters.tourn_size,
                        target_size=None,
                        max_cross_depth_override=None,
                        max_mutate_depth_override=None):
    """Generate offspring population using retry-based depth constraints.

    NSGA-II variant: no elite preservation (survivor selection happens
    in the main loop via selNSGA2 on combined population).
    Parent selection uses crowding-distance tournament (selTournamentDCD).

    Args:
        target_size: Number of offspring to produce (default: population_size from config)
        max_cross_depth_override: Override max crossover depth (for progressive complexity)
        max_mutate_depth_override: Override max mutation depth (for progressive complexity)
    """
    if toolbox is None:
        raise ValueError("toolbox must be provided")

    assert abs(cxpb + mutpb + reppb - 1.0) < 1e-8, \
        "cxpb + mutpb + reppb must sum to 1"

    target = target_size if target_size is not None else configure_parameters.population_size
    max_cross = max_cross_depth_override if max_cross_depth_override is not None else configure_parameters.max_cross_depth
    max_mut = max_mutate_depth_override if max_mutate_depth_override is not None else configure_parameters.max_mutate_depth

    max_attempts = configure_parameters.max_attempts_unique

    new_pop = []

    while len(new_pop) < target:
        r = random.random()

        # --- Crossover: produces 2 offspring ---
        if (r < cxpb) and (len(new_pop) <= target - 2):
            parents = _select_parents_dcd(pop, 2, toolbox, tournsize)
            parent1, parent2 = parents[0], parents[1]

            if len(pop) >= 2 and parent1 is parent2:
                attempt = 0
                while (parent1 is parent2) and (attempt < max_attempts):
                    parent2 = _select_parents_dcd(pop, 1, toolbox, tournsize)[0]
                    attempt += 1

            child1, child2 = _mate_with_retry(
                parent1, parent2, max_cross, max_attempts, toolbox
            )

            new_pop.append(child1)
            new_pop.append(child2)

        # --- Mutation: produces 1 offspring ---
        elif r < cxpb + mutpb:
            parent = _select_parents_dcd(pop, 1, toolbox, tournsize)[0]
            child = _mutate_with_retry(parent, max_mut, max_attempts, toolbox)
            new_pop.append(child)

        # --- Reproduction: produces 1 clone ---
        else:
            parent = _select_parents_dcd(pop, 1, toolbox, tournsize)[0]
            child = _copy_individual(parent)
            new_pop.append(child)

    return new_pop[:target]
