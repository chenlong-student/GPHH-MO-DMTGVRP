import os
import time
import random
import statistics
from copy import deepcopy

import toolboxRegister
import configure_parameters
import breeding
import evaluate
import utils
import Instance
import psetHoldCARP
import math

def _mean(values):
    if not values:
        return 0.0
    return statistics.fmean(values)

def _std(values):
    if len(values) <= 1:
        return 0.0
    mean = statistics.fmean(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(variance)

def _program_size(individual):
    return len(individual)

def _unique_terminal_num(individual):
    terminal_set = set()

    for node in individual:
        node_name = getattr(node, "name", None)
        node_arity = getattr(node, "arity", None)

        if node_name is not None and node_arity == 0:
            terminal_set.add(node_name)

    return len(terminal_set)


def _write_stat_title(file_path):
    with open(file_path, "w", encoding="utf-8") as file:
        file.write("Gen,BestFitness,BestInd,ProgHighMean,ProgHighStd,ProgSizeMean,ProgSizeStd,FitMean,FitStd,PopSize\n")

def _append_stat(file_path, gen_id, population, best_ind):
    prog_high_list = [ind.height for ind in population]
    prog_size_list = [_program_size(ind) for ind in population]
    fit_list = [ind.fitness.values[0] for ind in population]

    best_fitness = best_ind.fitness.values[0]
    best_ind_str = f'"{str(best_ind)}"'

    with open(file_path, "a", encoding="utf-8") as file:
        file.write(
            f"{gen_id},{best_fitness},{best_ind_str},{_mean(prog_high_list)},{_std(prog_high_list)},{_mean(prog_size_list)},{_std(prog_size_list)},"
            f"{_mean(fit_list)},{_std(fit_list)},{len(population)}\n"
        )

def _append_best_rule(file_path, gen_id, individual):
    with open(file_path, "a", encoding="utf-8") as file:
        file.write(f"Generation {gen_id}\n")
        file.write(f"Fitness: {individual.fitness}\n")
        file.write(f"Rule: {individual}\n\n")

def _get_test_file_name(instance_name):
    return (
        f"{instance_name}-"
        f"{configure_parameters.seed}.csv"
    )

def _make_manual_individual(primitive_set, tree_nodes):
    """Create a DEAP Individual from a list of GP nodes (terminals/primitives)."""
    from deap import gp, creator
    tree = gp.PrimitiveTree(tree_nodes)
    ind = creator.IndividualMO(tree)
    return ind


def _build_cfh_individual(primitive_set):
    """Build a manual 'CFH' individual — nearest-neighbor heuristic.
    The GP tree is just a single CFH terminal, so the vehicle always
    picks the arc with the smallest cost-from-here value.
    """
    from deap import creator
    cfh_terminal = None
    for node in primitive_set.terminals[object]:
        if node.name == "CFH":
            cfh_terminal = node
            break
    if cfh_terminal is None:
        raise ValueError("CFH terminal not found in primitive set")
    tree_nodes = [cfh_terminal]
    ind = _make_manual_individual(primitive_set, tree_nodes)
    return ind


def main(SEED, PROBLEM, PATH):

    if SEED is None:
        seed = configure_parameters.seed
    else:
        seed = SEED

    if PROBLEM is None:
        problem_name = configure_parameters.problem
    else:
        problem_name = PROBLEM

    if PATH is None:
        instance_path = configure_parameters.data_path
    else:
        instance_path = PATH

    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)

    # seed = configure_parameters.seed
    # problem_name = configure_parameters.problem
    # instance_path = configure_parameters.data_path
    instance_name = os.path.splitext(os.path.basename(instance_path))[0]

    # ========== 1. 加载算例 ==========
    instance = Instance.Instance(instance_path, 0)

    # ========== 2. Toolbox 初始化 ==========
    toolbox = toolboxRegister.toolbox_init(seed)

    # Seed RNG once at the start; do NOT re-seed per generation
    random.seed(seed)

    # # ========== 2.5 手动个体测试 ==========
    # print("\n========== Manual Individual Testing ==========")
    # pset = psetHoldCARP.psetHold()
    # manual_cfh = _build_cfh_individual(pset)
    # print(f"Manual rule: {manual_cfh}")
    #
    # # Evaluate on training samples
    # evaluate.evaluate_batch(manual_cfh, instance.instanceSeedList)
    # print(f"Train fitness: {manual_cfh.fitness}")
    # evaluate.print_vehicle_routes(manual_cfh, instance)
    # print("=" * 50)

    # ========== 3. 种群初始化 ==========
    pop = toolbox.population(n=configure_parameters.population_size)
    pop = utils.remove_duplicate_and_refill(pop, toolbox, configure_parameters.max_attempts_unique)

    # ========== 4. 初始适应度评估 ==========
    if configure_parameters.parallel_eval:
        pop_evaluated = evaluate.evaluate_population_parallel(pop, instance.instanceSeedList)
    else:
        pop_evaluated = evaluate.evaluate_population(pop, instance.instanceSeedList)

    # ========== 5. 输出文件初始化 ==========
    out_stat_path = os.path.join(current_dir, "train", f"{instance_name}-{seed}-{problem_name}.out.stat")
    stat_csv_path = os.path.join(current_dir, "train", f"{instance_name}-{seed}-{problem_name}.stat.csv")
    test_dir = os.path.join(current_dir)
    os.makedirs(test_dir, exist_ok=True)

    open(out_stat_path, "w", encoding="utf-8").close()
    _write_stat_title(stat_csv_path)

    # ========== 6. 训练过程 ==========
    best_ind_pop = []
    global_best_ind = None  # Track best-so-far across all generations

    for s in range(configure_parameters.gen):
        start_time_gen = time.time()

        best_ind = utils.find_best_ind(pop_evaluated)
        best_ind_copy = deepcopy(best_ind)
        best_ind_pop.append(best_ind_copy)

        # Update global best-so-far
        if global_best_ind is None:
            global_best_ind = deepcopy(best_ind_copy)
        else:
            if best_ind.fitness.values[0] < global_best_ind.fitness.values[0]:
                global_best_ind = deepcopy(best_ind_copy)

        _append_best_rule(out_stat_path, s, best_ind)
        _append_stat(stat_csv_path, s, pop_evaluated, best_ind)

        print()
        print(f"================ Train Process in The {s}-th Generation =================")
        print("Best individual (current gen):")
        print(best_ind)
        print(f"Best fitness (total cost): {best_ind.fitness.values[0]:.2f}, Fitness2 (mileage diff): {best_ind.fitness.values[1]:.2f}")
        print(f"Global best-so-far (total cost): {global_best_ind.fitness.values[0]:.2f}")

        # Print vehicle routes for best-so-far individual
        if configure_parameters.printVehiclesRoute:
            evaluate.print_vehicle_routes(global_best_ind, instance)

        if s == configure_parameters.gen - 1:
            break

        ##更新子代种群
        new_pop = breeding.breeding_population(
            pop_evaluated, toolbox,
            target_size=configure_parameters.population_size,
        )

        if configure_parameters.rotate_eval_model:
            instance.resetSeedInstance(seed, configure_parameters, s + 1)

        start_time_eval = time.time()
        ##种群个体的适应度评估
        if configure_parameters.parallel_eval:
            offspring = evaluate.evaluate_population_parallel(new_pop, instance.instanceSeedList)
        else:
            offspring = evaluate.evaluate_population(new_pop, instance.instanceSeedList)

        pop_evaluated = offspring

        end_time_eval = time.time()
        print(f"The evaluation time is: {end_time_eval - start_time_eval}")
        height = 0
        length = 0
        fitness = 0
        for ind in pop_evaluated:
            height += ind.height
            length += len(ind)
            fitness += ind.fitness.values[0]
        height /= len(pop_evaluated)
        length /= len(pop_evaluated)
        fitness /= len(pop_evaluated)
        print(f"The average fitness of the pop_evaluated: {fitness}")
        # print(f"The average high of the pop_evaluated: {height}")
        # print(f"The average length of the pop_evaluated: {length}")
        # print(f"The population size of the pop_evaluated: {len(pop_evaluated)}")

        end_time_gen = time.time()
        print(f"The generation time is {end_time_gen - start_time_gen}")

    # ========== 7. 测试阶段 ==========
    print("\n================ Testing Process =================\n")

    test_sample_list = instance.build_test_samples()
    test_csv_path = os.path.join(test_dir, "test", f"{instance_name}-{seed}-{problem_name}.stat.csv")

    best_overall = deepcopy(utils.find_best_ind(best_ind_pop))

    with open(test_csv_path, "w", encoding="utf-8") as file:
        file.write("Run,Generation,ProgramSize,UniqueTerminals,TrainFitness,TestFitness,Individual\n")

        for i, best_ind in enumerate(best_ind_pop):
            train_fitness = best_ind.fitness.values[0]
            evaluate.evaluate_batch(best_ind, test_sample_list)

            print(f"---------- Best individual from the {i}-th generation ----------")
            print(best_ind)
            print(f"Test fitness: {best_ind.fitness.values[0]:.2f}")
            print()
            best_ind_str = f'"{str(best_ind)}"'

            file.write(
                f"0,{i},{_program_size(best_ind)},{_unique_terminal_num(best_ind)},"
                f"{train_fitness},{best_ind.fitness.values[0]},{best_ind_str}\n"
            )

        train_fitness = best_overall.fitness.values[0]
        evaluate.evaluate_batch(best_overall, test_sample_list)
        file.write(
            f"0,-1,{_program_size(best_overall)},{_unique_terminal_num(best_overall)},"
            f"{train_fitness},{best_overall.fitness.values[0]},0\n"
        )

    print(f"Experiment out.stat saved to: {out_stat_path}")
    print(f"Experiment stat.csv saved to: {stat_csv_path}")
    print(f"Experiment test csv saved to: {test_csv_path}")

if __name__ == "__main__":
    a = time.time()
    SEED = None
    PROBLEM = None
    PATH = None
    main(SEED, PROBLEM, PATH)

    print('total time', time.time() - a)

