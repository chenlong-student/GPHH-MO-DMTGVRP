from deap import base, tools, gp
import psetHold
import optimizationTarget

# ----------------------------
# 2. 设置 toolbox
# ----------------------------
creator = optimizationTarget.create_fitness_and_individual()

toolbox = base.Toolbox()

toolbox.register("expr", gp.genHalfAndHalf, pset=psetHold.psetHold(), min_=1, max_=2)
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 将树编译成可计算的函数
toolbox.register("compile", gp.compile, pset=psetHold.psetHold())
toolbox.pset = psetHold.psetHold()