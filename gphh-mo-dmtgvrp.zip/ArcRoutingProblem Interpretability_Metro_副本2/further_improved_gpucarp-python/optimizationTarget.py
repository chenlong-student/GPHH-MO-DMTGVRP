
from deap import base, creator, gp

def create_fitness_and_individual():
    """定义 fitness 和 individual 类型"""

    # 避免重复创建
    if "FitnessMin" not in creator.__dict__:
        creator.create("FitnessMin", base.Fitness, weights=(-1.0,))

    if "Individual" not in creator.__dict__:
        creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)

    return creator
