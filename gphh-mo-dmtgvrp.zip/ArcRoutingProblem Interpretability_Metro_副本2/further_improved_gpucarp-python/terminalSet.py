import random
from deap import gp


def terminal_set():

    ##先给出pset定义
    pset = gp.PrimitiveSet("MAIN", 1)  # 一个自变量 x
    pset.renameArguments(ARG0='x0')

    ##输入自定义的叶子结点
    pset.addTerminal("ARG0")

    ##随机常数的叶子节点, 在 [a, b] 范围内
    def rand101_const():
        return random.uniform(-3, 3)
    pset.addEphemeralConstant("rand", rand101_const)

    return pset



