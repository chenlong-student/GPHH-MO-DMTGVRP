from deap import tools, gp
import psetHold
from toolBox import toolbox

def register_breeding_ops(toolbox = toolbox):
    """选择、交叉、变异操作的注册"""

    pset = psetHold.psetHold()

    toolbox.register("select", tools.selTournament, tournsize=3)
    toolbox.register("mate", gp.cxOnePoint)

    toolbox.register("expr_mut", gp.genFull, min_=0, max_=2)
    toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)

    # 限制树的最大深度，防止爆炸增长
    toolbox.decorate("mate", gp.staticLimit(key=len, max_value=30))
    toolbox.decorate("mutate", gp.staticLimit(key=len, max_value=30))
