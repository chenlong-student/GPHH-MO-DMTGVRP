import numpy as np
from deap import gp
import dataGenerate
from toolBox import toolbox

def register_fitness_function(toolbox = toolbox):
    """注册评估函数"""

    X, y = dataGenerate.generate_dataset()

    def eval_symb_reg(individual):
        func = toolbox.compile(expr=individual)
        try:
            pred = np.array([func(xi) for xi in X])
            error = np.mean((pred - y)**2)
            return (error, )
        except Exception:
            return (1e6, )

    toolbox.register("compile", gp.compile, pset=toolbox.pset)
    toolbox.register("evaluate", eval_symb_reg)
