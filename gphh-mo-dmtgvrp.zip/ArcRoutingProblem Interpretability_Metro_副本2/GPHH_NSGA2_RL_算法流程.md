# GPHH-NSGA-II-RL 算法完整流程

## 一、算法概述

该算法是**基于遗传规划超启发式（GPHH）**结合**NSGA-II多目标选择**与**Q-learning强化学习**的车队路径优化算法（CARP问题）。它通过RL智能体动态选择每一代的环境选择策略，实现自适应进化。

**优化目标（均最小化）：**
- **F1（总成本）：** 所有车辆行驶成本之和
- **F2（里程平衡）：** 活跃车辆间的最大里程差（`max(route_mileage) - min(route_mileage)`，仅统计有任务的车辆）

---

## 二、核心数据结构

### 2.1 个体与适应度

```python
# optimizationTargetCARP.py
creator.create("FitnessMO", base.Fitness, weights=(-1.0, -1.0))  # 双目标最小化
creator.create("IndividualMO", gp.PrimitiveTree, fitness=creator.FitnessMO)

# Fitness values:
#   values[0] = F1 = 总成本（所有车辆行驶成本之和 + 未服务弧惩罚）
#   values[1] = F2 = 活跃车辆间最大里程差 + 未服务弧惩罚
```

### 2.2 CFH参考解

每代迭代时动态变化的"尺子"，用于标定种群适应度的相对水平：

```
reference_ind = CFH个体（最近邻启发式规则）
```

- 在种群初始化后构建并评估
- 当 `rotate_eval_model=True` 时，每轮种子轮换后**重新评估**，使其F1/F2反映当前轮的环境
- 状态计算中的 `ave_F1_Pareto` 和 `ave_F2_Pareto` 以参考解的F1/F2为基准做比值

### 2.3 RL动作空间（5种环境选择策略）

| 动作ID | 动作名称 | 选择机制 |
|--------|----------|----------|
| 0 | `strong_F1` | 仅按F1升序排序，取前N个 |
| 1 | `mild_F1` | 按 `0.7*F1 + 0.3*F2` 加权升序排序，取前N个 |
| 2 | `standard_NSGA2` | 标准NSGA-II非支配排序+拥挤度选择 |
| 3 | `mild_F2` | 按 `0.3*F1 + 0.7*F2` 加权升序排序，取前N个 |
| 4 | `strong_F2` | 仅按F2升序排序，取前N个 |

### 2.4 RL状态空间（3维离散化）

状态是三维元组 `(f1_bin, f2_bin, relative_bin)`，每个维度有3个bin：

**维度1：`ave_F1_Pareto` = Pareto解F1均值 / F1(reference_ind)，越小越好**

| Bin值 | 含义 | 条件 |
|-------|------|------|
| 2 (好) | F1显著优于参考解 | `ratio < 0.9` |
| 1 (中) | F1与参考解相当 | `0.9 ≤ ratio ≤ 1.2` |
| 0 (差) | F1显著劣于参考解 | `ratio > 1.2` |

**维度2：`ave_F2_Pareto` = Pareto解F2均值 / F2(reference_ind)，越小越好**

| Bin值 | 含义 | 条件 |
|-------|------|------|
| 2 (好) | F2显著优于参考解 | `ratio < 0.7` |
| 1 (中) | F2与参考解相当 | `0.7 ≤ ratio ≤ 1.2` |
| 0 (差) | F2显著劣于参考解 | `ratio > 1.2` |

**维度3：`relative_bin` = 两个目标改善程度的对比**

```
relative_ratio = ave_F2_Pareto / (ave_F1_Pareto + 1e-9)
```

| Bin值 | 含义 | 条件 |
|-------|------|------|
| 2 (F1领先) | F1改善明显领先于F2 | `ratio > 1.2` |
| 1 (均衡) | 两个目标改善幅度相当 | `0.833 ≤ ratio ≤ 1.2` |
| 0 (F2领先) | F2改善明显领先于F1 | `ratio < 0.833` |

**状态空间总规模：** `3 × 3 × 3 = 27` 种状态

**状态与动作的耦合关系（候选集规则）：**

| relative_bin | 落后方的bin | 候选动作(3个) | 逻辑 |
|-------------|------------|---------------|------|
| 2 (F1领先) | f2_bin=0 (F2差) | NSGA-II + strong_F2 + mild_F2 | F2落后，需要强推 |
| 2 (F1领先) | f2_bin=1 (F2中) | NSGA-II + mild_F2 + strong_F2 | F2中等，需要轻推 |
| 2 (F1领先) | f2_bin=2 (F2好) | NSGA-II + mild_F2 + mild_F1 | 都好，维持平衡 |
| 0 (F2领先) | f1_bin=0 (F1差) | NSGA-II + strong_F1 + mild_F1 | F1落后，需要强推 |
| 0 (F2领先) | f1_bin=1 (F1中) | NSGA-II + mild_F1 + strong_F1 | F1中等，需要轻推 |
| 0 (F2领先) | f1_bin=2 (F1好) | NSGA-II + mild_F1 + mild_F2 | 都好，维持平衡 |
| 1 (均衡) | 任意 | NSGA-II + mild_F1 + mild_F2 | 无明确方向，多目标为主 |

Q-learning在3个候选动作中根据历史奖励选择最优的那个。

### 2.5 RL超参数

| 参数 | 默认值 | 含义 |
|------|--------|------|
| `rl_epsilon` | 0.15 | 探索率（epsilon-greedy，仅在候选动作间随机） |
| `rl_learning_rate` | 0.1 | Q值学习率 |
| `rl_gamma` | 0.9 | 折扣因子 |
| `rl_user_preference` | "F1" | 用户偏好（"F1"或"F2"） |
| `rl_reward_penalty` | 0.2 | 非偏好目标恶化惩罚系数 |
| `rl_relative_threshold` | 1.2 | 相对改善判定阈值（偏离1.0超过20%认为有领先） |

### 2.6 归一化边界乘数

基于 `.dat` 文件中所有弧 `coste` 之和计算归一化范围：

| 参数 | 默认值 | 含义 |
|------|--------|------|
| `rl_f1_min_multiplier` | 0.8 | `F1_min = total_coste × 0.8` |
| `rl_f1_max_multiplier` | 1.3 | `F1_max = total_coste × 1.3` |
| `rl_f2_min_multiplier` | 0.0 | `F2_min = total_coste × 0.0` |
| `rl_f2_max_multiplier` | 0.7 | `F2_max = total_coste × 0.7` |

---

## 三、完整算法流程

### 阶段1：初始化

```
Step 1: 加载CARP问题实例
    instance = Instance(instance_path, gen=0)
    - 解析实例文件（顶点、弧段、车辆、容量、仓库）
    - 构建最短路径距离矩阵（Dijkstra）
    - 生成训练样本列表 instanceSeedList（多个随机种子样本）

Step 2: 初始化DEAP工具箱
    toolbox = toolboxRegister.toolbox_init(seed)
    - 注册GP原语集
      · 终端节点：CFH, CFD, DEM, SC, ERC 等
      · 函数节点：add, sub, mul, div, max, min, if 等
    - 注册选择操作
      · selNSGA2（环境选择/幸存者选择）
      · selTournamentDCD（交配选择/拥挤度锦标赛）
    - 注册遗传操作：cxOnePoint（交叉）、mutUniform（变异）
    - 注册个体/种群生成器

Step 3: 初始化种群
    pop = toolbox.population(n=population_size)
    pop = remove_duplicate_and_refill(pop, toolbox, max_attempts)
    - 随机生成GP个体（genHalfAndHalf方式），确保无重复

Step 4: 初始适应度评估
    pop_evaluated = evaluate_population(pop, instance.instanceSeedList)
    - 每个个体在所有训练样本上评估
    - 对每个样本返回 (F1, F2) 元组
    - 取所有样本的平均值作为最终适应度

Step 5: 计算归一化边界
    f1_min, f1_max, f2_min, f2_max = instance.get_normalization_bounds(
        f1_min_mul, f1_max_mul, f2_min_mul, f2_max_mul)
    - 基于.dat文件中所有弧coste之和计算

Step 6: 构建CFH参考个体
    reference_ind = CFH个体（最近邻启发式规则）
    - 在当前的训练样本上评估，获得参考F1/F2
    - 作为后续状态离散化的"尺子"

Step 7: 初始化输出文件
    - train/{instance}-{seed}-{problem}-RL.out.stat    （每代最佳规则文本）
    - train/{instance}-{seed}-{problem}-RL.stat.csv    （每代统计信息CSV，含RelativeImprovement列）

Step 8: 初始化RL智能体
    rl_agent = RLEvolutionController(user_pref="F1")
    - Q表初始化为空字典

Step 9: 计算初始状态
    init_pareto = 第一代非支配面
    init_ave_f1_p = mean(F1_Pareto) / F1(reference_ind)
    init_ave_f2_p = mean(F2_Pareto) / F2(reference_ind)
    prev_state = rl_agent.get_state_key(init_ave_f1_p, init_ave_f2_p)
```

### 阶段2：主进化循环（共 `gen` 代）

对每一代 `s` 从 `0` 到 `gen-1`，依次执行以下步骤：

#### Step A：RL选择动作

```python
action = rl_agent.select_action(prev_state)
```

**规则 + Q-learning选择策略：**

```
1. 根据当前state，规则引擎生成3个候选动作
2. if 只有1个候选:
       直接返回
   if random() < epsilon:
       从候选中随机选（探索）
   else:
       从候选中选Q值最高的（利用）
```

#### Step B：获取Pareto前沿和最佳个体

```python
pareto_front = _get_pareto_front(pop_evaluated)  # 第一代非支配面
best_ind = min(pareto_front, key=lambda ind: ind.fitness.values[0])
best_ind_pop.append(deepcopy(best_ind))

# 更新全局历史最优（按F1比较）
if best_ind.fitness.values[0] < global_best_ind.fitness.values[0]:
    global_best_ind = deepcopy(best_ind)
```

#### Step C：记录统计信息

- 写入 `.out.stat`：当前代最佳个体的GP规则、适应度、RL动作、奖励
- 写入 `.stat.csv`：F1/F2的最优值、均值、标准差、种群大小、Pareto前沿大小、**ave_F1_Pareto**、**ave_F2_Pareto**、**RelativeImprovement**、RL动作、奖励

#### Step D：生成后代（breeding_population）

```python
offspring = breeding_population(pop_evaluated, toolbox, target_size=population_size)
```

**父代选择：** `selTournamentDCD`（拥挤度距离锦标赛，tournsize=2）

**操作概率（`cxpb + mutpb + reppb = 1.0`）：**

| 操作 | 概率 | 过程 |
|------|------|------|
| 交叉 | `crossover_probability` (0.70) | 选2个父代 → cxOnePoint → 2个子代（带深度限制重试） |
| 变异 | `mutate_probability` (0.15) | 选1个父代 → mutUniform → 1个子代（带深度限制重试） |
| 复制 | `reproduct_probability` (0.15) | 选1个父代 → deepcopy → 1个克隆 |

#### Step E：评估后代

```python
# 若启用评估种子轮换，切换随机种子并重新评估参考个体
if rotate_eval_model:
    instance.resetSeedInstance(seed, configure_parameters, s + 1)
    reference_ind = 重新评估CFH个体(new_seeds)

# 评估后代
offspring = evaluate_population(offspring, instance.instanceSeedList)

# 若轮换模式，也重新评估父代（保证公平竞争）
if rotate_eval_model:
    pop_evaluated = evaluate_population(pop_evaluated, instance.instanceSeedList)
```

#### Step F：RL引导的环境选择

```python
combined_pop = pop_evaluated + offspring  # 父代 + 后代（2N个个体）
pop_evaluated = _select_rl_guided(combined_pop, population_size, action, toolbox)
```

**5种选择策略的具体行为：**

| action | 策略 | 行为 |
|--------|------|------|
| 0 | `strong_F1` | `sorted(combined, key=F1)[:N]` |
| 1 | `mild_F1` | `sorted(combined, key=0.7*F1+0.3*F2)[:N]` |
| 2 | `standard_NSGA2` | `toolbox.selNSGA2(combined, N)` |
| 3 | `mild_F2` | `sorted(combined, key=0.3*F1+0.7*F2)[:N]` |
| 4 | `strong_F2` | `sorted(combined, key=F2)[:N]` |

#### Step G：计算RL奖励

```python
avg_f1_before = mean(F1 of pop before selection)
avg_f2_before = mean(F2 of pop before selection)
avg_f1_after  = mean(F1 of pop after selection)
avg_f2_after  = mean(F2 of pop after selection)

reward = rl_agent.compute_reward(avg_f1_before, avg_f2_before,
                                 avg_f1_after,  avg_f2_after)
```

**奖励公式：**

```
# F1偏好时:
f1_improve  = (avg_f1_before - avg_f1_after) / (avg_f1_before + 1e-9)
f2_degrade  = (avg_f2_after - avg_f2_before) / (avg_f2_before + 1e-9)
reward      = f1_improve - 0.2 * f2_degrade

# F2偏好时:
f2_improve  = (avg_f2_before - avg_f2_after) / (avg_f2_before + 1e-9)
f1_degrade  = (avg_f1_after - avg_f1_before) / (avg_f1_before + 1e-9)
reward      = f2_improve - 0.2 * f1_degrade
```

**解读：** 奖励 = 偏好目标的相对改善率 − 0.2 × 非偏好目标的相对恶化率。鼓励RL代理在优化偏好目标的同时，不要过度牺牲另一个目标。

#### Step H：更新Q表

```python
next_state = rl_agent.get_state_key(next_ave_f1_p, next_ave_f2_p)

# 候选约束的Q-learning更新
next_candidates = rl_agent._get_candidate_actions(next_state)
best_next_q = max(Q[next_state][a] for a in next_candidates)
Q[s][a] += lr * (r + gamma * best_next_q - Q[s][a])
```

其中：
- `lr = 0.1`（学习率）
- `gamma = 0.9`（折扣因子，重视未来奖励）
- `r` = Step G计算的奖励
- `best_next_q` = 下一状态候选动作中的最优Q值（不是全部动作）

#### Step I：更新RL状态跟踪

```python
rl_agent.last_state = prev_state
rl_agent.last_action = action
prev_state = next_state
```

### 阶段3：Q表总结

进化结束后，输出训练过程中访问过的所有状态及其Q值：

```
========== Q-Table Summary ==========
  State (0, 1, 2): best_action=standard_NSGA2, q=[...]
  State (2, 2, 1): best_action=mild_F1, q=[...]
  ...
```

### 阶段4：测试阶段

```
Step 1: 构建测试样本
    test_sample_list = instance.build_test_samples()
    - 使用独立的测试种子（testing_seed），不参与训练
    - 默认500个测试样本

Step 2: 评估每代最佳个体
    for each best_ind in best_ind_pop:
        evaluate_batch(best_ind, test_sample_list)
        - 在所有测试样本上评估，取F1/F2平均值
        - 记录到 test/{instance}-{seed}-{problem}-RL.stat.csv

Step 3: 评估全局最优个体
    best_overall = find_best_ind(best_ind_pop)  # F1最小的个体
    evaluate_batch(best_overall, test_sample_list)
    - 记录到CSV文件最后一行（Generation = -1）
```

---

## 四、关键公式

### 4.1 F1 — 总成本

```
F1 = sum(所有车辆的行驶成本) + 未服务弧惩罚

单车成本 = 空驶成本(depot→第一个弧) + 服务成本 + 空驶成本(弧间)
         + 回程成本(last_arc→depot) + 补充成本(满载回depot再出发)
```

### 4.2 F2 — 里程平衡

```python
def _compute_fitness2(total_costs):
    active = [c for c in total_costs if c > 0]  # 有任务的车辆
    if len(active) <= 1:
        return 0.0
    return max(active) - min(active)
```

### 4.3 未服务弧惩罚

```
unserved_penalty = num_unserved * avg_arc_cost * 10.0
F1_penalized = F1 + unserved_penalty
F2_penalized = F2 + unserved_penalty
```

### 4.4 状态离散化

```python
ave_f1_p = mean(F1 of Pareto front) / F1(reference_ind)
ave_f2_p = mean(F2 of Pareto front) / F2(reference_ind)

# F1 bin: < 0.9 → 2(good), 0.9~1.2 → 1(medium), > 1.2 → 0(poor)
# F2 bin: < 0.7 → 2(good), 0.7~1.2 → 1(medium), > 1.2 → 0(poor)

# relative_bin:
ratio = ave_f2_p / ave_f1_p
if ratio > 1.2:        relative_bin = 2  (F1领先)
elif ratio < 0.833:    relative_bin = 0  (F2领先)
else:                  relative_bin = 1  (均衡)
```

### 4.5 Q表更新（候选约束Q-Learning）

```
Q[s][a] ← Q[s][a] + lr × (r + γ × max_{a' ∈ candidates(s')} Q[s', a'] − Q[s][a])
```

---

## 五、GP评估细节

### 5.1 终端节点

| 名称 | 含义 |
|------|------|
| CFH | 车辆当前位置到弧起点的距离（Cost From Here） |
| CFD | 弧起点到仓库的距离（Cost From Depot） |
| CFR1 | 其他车辆到该弧的最佳距离 |
| CTT1 | 该弧终点到其他弧起点的最小距离 |
| CTD | 仓库到该弧起点的距离（Cost To Depot） |
| CR | 车辆当前位置到仓库的距离（Cost Return） |
| DEM | 弧的需求量（Demand） |
| DEM1 | 最近邻弧的需求量 |
| DC | 弧的空驶成本（Deadhead Cost） |
| FULL | 车辆满载率 |
| FRT | 剩余任务比例（Fraction of Remaining Tasks） |
| FUT | 未分配任务比例（Fraction of Unassigned Tasks） |
| RQ | 车辆剩余容量（Remaining Quantity） |
| RQ1 | 最近车辆的剩余容量 |
| SC | 弧的服务成本（Service Cost） |
| ERC | 临时随机常数（Ephemeral Random Constant） |

### 5.2 函数节点

`add`, `sub`, `mul`, `div`（保护除法）, `max`, `min`

### 5.3 评估流程

1. **编译GP树**为字节码程序（指令栈：const/term/prim）
2. **预计算**：弧间距离矩阵、候选邻居特征、路线特征
3. **迭代分配**（`while active_arcs`）：
   - 每轮：所有车辆并行评估所有活跃弧 → GP树输出每个弧的优先级分数
   - 冲突解决：多辆车争同一弧时，GP分数优者胜出
   - 落选车辆尝试第二优选弧
   - 分配成功后从 `active_arcs` 移除该弧及其反向弧
4. **计算适应度**：F1=总成本，F2=最大里程差，加上未服务弧惩罚

---

## 六、育种操作

```
父代选择: selTournamentDCD（拥挤度距离锦标赛，tournsize=2）

操作概率: cxpb + mutpb + reppb = 1.0
  cxpb = 0.70  → 交叉（cxOnePoint，带深度限制重试 max_cross_depth=8）
  mutpb = 0.15 → 变异（mutUniform，带深度限制重试 max_mutate_depth=8）
  reppb = 0.15 → 复制（deepcopy）

个体复制时:
  child.fitness = creator.FitnessMO()  # 清空适应度（DEAP deepcopy bug修复）
```

---

## 七、数据流向总结

```
CARP实例文件
    │
    ▼
Instance(seed=0)
    ├── shortest path matrix (Dijkstra)
    ├── instanceSeedList → N个训练样本（不同随机种子）
    └── test_sample_list → M个测试样本（独立种子）

主程序:
    初始化: 随机生成种群 → 评估 → pop_evaluated(F1, F2)
          → 计算归一化边界 → 构建CFH参考个体 → 评估参考个体
    │
    ├─ 每代循环 ──────────────────────────────────┐
    │  1. RL选择动作 (规则候选 + Q-learning)       │
    │  2. 记录Pareto前沿统计 (size, F1/F2均值,     │
    │     relative_ratio)                         │
    │  3. breeding (DCD选择 + 交叉/变异/复制)      │
    │  4. 评估后代 (+ 轮换种子时重评父代+参考个体)  │
    │  5. 合并: combined = 父代 + 后代              │
    │  6. RL-guided选择 → 新种群                    │
    │  7. 计算奖励 → 候选约束Q表更新                │
    │  8. 更新状态跟踪                              │
    └─────────────────────────────────────────────┘
    │
    ▼
测试: 每代最佳个体 + 全局最优 → 测试样本评估 → CSV输出
```

---

## 八、文件结构

| 文件 | 作用 |
|------|------|
| `main_gphh_metro_nsga2_RL.py` | RL-NSGA-II主程序入口 |
| `configure_parameters_rl.py` | RL超参数 + 归一化边界 + 导入基础GPHH参数 |
| `configure_parameters.py` | 基础GPHH参数（问题、种群、育种、GP原语） |
| `optimizationTargetCARP.py` | FitnessMO / IndividualMO定义 |
| `evaluate.py` | 个体评估（F1总成本 + F2里程差） |
| `breeding.py` | 育种流程（交叉、变异、复制） |
| `breedingProcessCARP.py` | Toolbox选择操作注册 |
| `populationInitializationCARP.py` | 种群初始化（genHalfAndHalf等） |
| `utils.py` | 工具函数（去重、找最佳个体等） |
| `Instance.py` | 实例加载、样本生成、种子轮换、归一化边界计算 |
| `toolboxRegister.py` | DEAP工具箱初始化 |
