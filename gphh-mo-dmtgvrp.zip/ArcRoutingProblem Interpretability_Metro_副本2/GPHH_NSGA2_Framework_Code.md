# GPHH + NSGA-II 双目标优化算法框架（代码版）

> 对应实现文件：`main_interpretability_nsga2.py`

## 一、问题定义

| 项目 | 说明 |
|---|---|
| **问题** | UCARP（Uncapacitated Arc Routing Problem） |
| **方法** | GPHH 进化路由策略树（GP PrimitiveTree 结构） |
| **目标** | 双目标最小化 |
| **Fitness1** | 路由成本（Cost），数值计算 |
| **Fitness2** | 策略可解释性复杂度（0-100），由 LLM 或代理模型评估 |
| **选择机制** | NSGA-II（非支配排序 + 拥挤度距离） |
| **框架** | DEAP |

## 二、文件结构

```
GPHH_CARP/
├── main_interpretability_nsga2.py    # NSGA-II 主程序（本框架）
├── configure_parameters.py           # 进化参数（population_size, gen, cxpb, mutpb 等）
├── configure_parameters_extra.py     # 可解释性参数（USE_LLM, CLUSTER_P1/P2/P3, PARETO_FRONT_LEVELS 等）
├── interp_cluster.py                 # 聚类 + LLM 评分 + 代理模型流水线
├── evaluate.py                       # Fitness1 评估
├── Instance.py                       # CARP 实例加载与种子管理
├── psetHoldCARP.py                   # GP 原语集合（终端 + 函数）
├── toolboxRegister.py                # DEAP 工具箱注册
└── utils.py                          # 工具函数
```

## 三、模块级缓存

```python
_canonical_result_cache = {}       # 规范化中间结果（全程序生命周期）
_simplify_cache = {}               # AST 简化缓存（全程序生命周期）
_f2_permanent_cache = {}           # {canon_str: F2} 所有评分过的个体（跨代保留）
_llm_permanent_canons = set()      # 子集：曾被 LLM 评分的 canon_str（跨代保留）
_f2_llm_cache = {}                 # {canon_str: F2} 仅 LLM 评分的个体（跳过流水线用）
```

**核心规则：**
- **命中 `_f2_llm_cache`** → 跳过整个 F2 流水线，直接读取 F2，method 标 "LLM"
- **未命中** → 走完整流水线（规范化 → 相似度矩阵 → 聚类 → LLM/Proxy 评分）
- **一旦 LLM 评分过** → 永远不再参与 F2 计算
- **Proxy 评分过** → 保留值但可被后续更新

## 四、双目标设置

```python
creator.create("FitnessMO", base.Fitness, weights=(-1.0, -1.0))
creator.create("IndividualMO", gp.PrimitiveTree, fitness=creator.FitnessMO)
```

两个目标均为最小化，权重 `-1.0` 对应 DEAP 的 minimization 约定。

## 五、主循环（每代 7 步）

```
Generation G  (种群大小 = N)
│
│  【实例配置】  instance = Instance(path, seed=gen)  ← 通过 rotate_eval_model 逐代递增
│
│  Step 1: Evaluate F1（父代）
│    pop = evaluate.evaluate_population(pop, instance.instanceSeedList)
│
│  Step 2: Analyze F2（父代）
│    _analyze_generation(gen_id, pop, ...)
│    → 规范化 → LLM 缓存检查 → 聚类 → 评分 → 打印/CSV
│
│  Step 3: Breed
│    offspring = _breed_offspring(pop, toolbox, ...)  → N 个子代
│    → 锦标赛选择 + 交叉/变异/复制
│
│  Step 4: Evaluate F1（子代）
│    offspring = evaluate.evaluate_population(offspring, instance.instanceSeedList)
│
│  Step 5: Analyze F2（子代）
│    _compute_f2_for_population(offspring, ...)  ← 与父代相同的完整流水线
│    → 规范化 → LLM 缓存检查 → 聚类 → LLM/Proxy 评分
│
│  Step 6: NSGA-II Selection
│    combined = pop(N) + offspring(N) = 2N
│    pop = _nsga2_select(combined, N)
│    → 非支配排序 → 拥挤度距离 → 选出 N 个
│
│  Step 7: Deduplicate & Refill
│    pop = _deduplicate_and_refill(selected, combined, toolbox)
│    → 去重 → 优先从 combined 剩余个体补充 → 不够才用随机
│
│  Step 8: Rotate Instance（可选）
│    instance.resetSeedInstance(seed, config, gen_id + 1)
│    → 下一代使用不同的训练实例种子
│
│  → Generation G+1
```

### 5.1 父代与子代的实例关系

| 代数 | 父代使用的 instances | 子代使用的 instances |
|---|---|---|
| Gen 0 | seed=0 | seed=0（**相同**） |
| Gen 1 | seed=1 | seed=1（**相同**） |
| Gen 2 | seed=2 | seed=2（**相同**） |

**同一代内父代和子代使用相同的 instances。不同代之间因 `rotate_eval_model=True` 而使用不同的实例种子。**

### 5.2 育种策略（`_breed_offspring`）

```
while len(offspring) < N:
    r = random()
    if r < 0.80  → 交叉（两个父代锦标赛选择 → gp.cxOnePoint）
    if r < 0.95  → 变异（一个父代锦标赛选择 → gp.mutUniform）
    else         → 复制（一个父代锦标赛选择 → 直接复制）
```

### 5.3 去重补种（`_deduplicate_and_refill`）

```
输入: selected（N个，可能有重复），combined（2N原始池）

1. 从 selected 中提取唯一集合（按 str(ind) 去重）→ K 个
2. n_needed = N - K
3. 优先从 combined 的未入选个体中补充 n_needed 个（按 NSGA-II 排序顺序）
4. 仅当 combined 剩余个体也不够时才用随机个体填充
```

## 六、Fitness2 核心流水线（`_compute_f2_for_population`）

### 6.1 总体流程

```
输入: pop 个群体（大小 N）
│
├─ (a) 规范化（Canonicalization）
│     每个 ind → 6步 AST 规范化
│     若 ind.simpest=True → 跳过规范化
│     规范化后等于原树 → 标记 simpest=True
│
├─ (b) 检查 LLM 缓存（_f2_llm_cache）
│     cached   = {r | r.canonical in _f2_llm_cache}  → 直接赋 F2, method="LLM"
│     uncached = {r | r.canonical not in _f2_llm_cache} → 继续
│
├─ (c) 相似度矩阵（仅 uncached，大小 M×M，M=uncached 数量）
│     3D 相似度 = w1·成本邻近 + w2·AST结构 + w3·Embedding
│
├─ (d) 贪心聚类（仅 uncached）
│     阈值 CLUSTER_THRESHOLD = 0.65
│
├─ (e) 簇预选（P1/P2/P3）
│     Top 1/P1 按 avg F1 升序
│     Top 1/P2 按簇大小 降序
│     Top 1/P3 按 avg F2 升序（仅已知 F2 的簇）
│     并集 → selected_clusters
│
├─ (f) ★ 两阶段处理 ★
│
│     Phase 1 — 处理所有选中簇:
│       Stage 1: 代表选择（Top-K 按 F1 → 选 N 最中心）
│       Stage 2: LLM 评分代表 → 更新 all_llm_rep_f2 全局注册表
│       Stage 3: 训练 Ridge 代理模型
│       Stage 4: 非代表个体: F2 = F_est + 相似度修正
│
│     Phase 2 — 处理所有未选中簇:
│       构建局部代理模型（dummy labels=50）
│       跨簇相似度修正: F2(i) = F_est(i) + avg[S(i, rep_j) × (F2(rep_j) - F_est(i))]
│       其中 rep_j 来自 Phase 1 所有 LLM 评过的代表
│
├─ (g) 同步缓存
│     所有 F2 → _f2_permanent_cache
│     LLM 评分 → _f2_llm_cache + _llm_permanent_canons
│
└─ (h) 返回 results + clusters
```

### 6.2 Phase 1 vs Phase 2 关键区别

| | Phase 1（选中簇） | Phase 2（未选中簇） |
|---|---|---|
| **代表选择** | Top-K 按 F1 → N 最中心 | 无 |
| **LLM 评分** | 有，代表走 LLM | 无 |
| **代理模型** | 基于真实 F2 训练（Ridge） | 基于 dummy=50 训练（启发式） |
| **相似度修正** | 用本簇代表的 LLM 分数 | 用 Phase 1 **所有簇** 的 LLM 代表分数（跨簇） |
| **all_llm_rep_f2** | 写入（积累） | 读取（使用） |

### 6.3 Method 标签判定逻辑

```
个体规范化后 → 按优先级判定：

1. 命中 _f2_llm_cache → method = "LLM", 跳过全部流水线
2. 进入流水线后:
   - LLM 实际评分 → method = "LLM"
   - 代理模型估计 → method = "Proxy"
   - 命中 permanent cache 且该 canon 在 _llm_permanent_canons 中 → method = "LLM"
   - 命中 permanent cache 但仅 Proxy 评过 → method = "Proxy"
```

## 七、AST 规范化（6步）

1. **常量折叠**：`add(2, 3)` → `const(5)`
2. **交换律排序**：`add(B, A)` → `add(A, B)`（按字典序）
3. **结合律扁平化**：`add(A, add(B, C))` → `add(A, B, C)` → 平衡树
4. **合并同类项**：`add(mul(2, X), mul(3, X))` → `mul(5, X)`
5. **标量不变性归一化**：`mul(正标量, X)` → `X`
6. **终端相关性替换**：检测始终同时出现的终端，用统一标识替换

规范化后等于原树 → 标记 `simpest=True`，后续代跳过规范化。

## 八、3D 相似度计算

| 维度 | 名称 | 计算方式 | 权重（默认） |
|---|---|---|---|
| S1 | 成本邻近 | `1 - |cost_i - cost_j| / cost_range` | 0.5（无embedding）/ 0.4（有embedding） |
| S2 | AST 结构 | 子树 Jaccard(0.5) + 终端 Jaccard(0.3) + 高度相似(0.2) | 0.5 / 0.3 |
| S3 | 嵌入余弦 | Qwen3-Embedding 余弦相似度 | 0.0 / 0.3 |

**特殊规则**：若终端集相同 +（行为哈希相同 或 成本相同）→ 直接 S=1.0

综合相似度：`S = w1*S1 + w2*S2 + w3*S3`

## 九、可解释性维度 D1-D8

| 维度 | 名称 | 计算依据 |
|---|---|---|
| D1 | 结构简洁性 | 节点总数分段 |
| D2 | 结构对称性 | 路由终端种类数 |
| D3 | 规则正则性 | 原语使用种类和频率 |
| D4 | 策略一致性 | 重复子树比例 |
| D5 | 决策熵 | 行为数据中的决策熵 |
| D6 | 规则简洁性 | 节点总数分段 |
| D7 | 评分一致性 | 行为数据中的评分一致性 |
| D8 | 异常检测 | 节点总数分段 |

综合评分：`F2 = 0.4 * (100 - SQ) + 0.6 * (100 - BQ)`
其中 `SQ = D1+D2+D3+D4`，`BQ = D5+D6+D7+D8`

## 十、代理模型（Ridge 回归）

```python
# 设计矩阵: X = [1, p1, p2, p3, p4, p5, p6]
# p1: 总节点数, p2: 终端数, p3: 函数数
# p4: 唯一终端种类, p5: 唯一函数种类, p6: 树高度

# Ridge 回归: w = (X^T X + λI)^(-1) X^T y, λ=1.0
F_est = w0 + w1*p1 + w2*p2 + w3*p3 + w4*p4 + w5*p5 + w6*p6
```

相似度修正公式：
```
F2(i) = F_est(i) + avg_rep [ S(i, rep) × (F2(rep) - F_est(i)) ]
```

## 十一、NSGA-II 选择

```
combined = parents(N) + offspring(N) = 2N
│
├─ 为每个个体设置双目标 Fitness: (F1, F2)
│
├─ DEAP tools.selNSGA2(combined, N)
│   ├─ 非支配排序 → Front 1, 2, ..., F
│   ├─ 计算拥挤度距离
│   └─ 从最后一个入选前沿中按拥挤度截取至 N 个
│
└─ 返回 N 个个体（可能有重复，由后续去重处理）
```

## 十二、实例种子轮换（rotate_eval_model）

```python
# 初始: instance = Instance(data_path, seed=0)
# 每代末尾:
if rotate_eval_model:
    instance.resetSeedInstance(seed, configure_parameters, gen_id + 1)

# Gen 0 使用 seed=0 的实例
# Gen 1 使用 seed=1 的实例
# ...
```

这使得进化过程在不同的训练实例上评估，增强泛化能力。

## 十三、进化结束后处理

```
Final Population (N 个)
│
├─ 非支配分级 → Front 1, 2, ..., F
│
├─ 聚合前 PARETO_FRONT_LEVELS 个前沿的个体（默认 3）
│
├─ LLM 重新评分（查永久缓存，命中则跳过）
│   或规则评分（无 LLM 时）
│
├─ 重新计算 Pareto 前沿 → 最终非支配解集
│
├─ 测试集评估 → 每个解输出 Train(F1,F2) + Test(F1)
│
└─ 导出
    test/{name}-{seed}-nsga2.csv        （全代数据）
    test/{name}-{seed}-nsga2-pareto.csv （Pareto 前沿，含 Train/Test 对比）
```

## 十四、输出文件

| 文件 | 内容 |
|---|---|
| `test/{name}-{seed}-{problem}-nsga2.csv` | 全代数据，每行：`Gen,Cost,Fitness2,StructSize,Height,Method,Canonical,BehavHash,Transforms` |
| `test/{name}-{seed}-{problem}-nsga2-pareto.csv` | Pareto 前沿，每行：`#,TrainF1,TrainF2,TestF1,StructSize,Height,Canonical` |

## 十五、关键参数（默认值）

### 进化参数（configure_parameters.py）

| 参数 | 默认值 | 说明 |
|---|---|---|
| `population_size` | 100 | 种群规模 |
| `gen` | 3 | 进化代数 |
| `crossover_probability` | 0.80 | 交叉概率 |
| `mutate_probability` | 0.15 | 变异概率 |
| `reproduct_probability` | 0.05 | 复制概率 |
| `tourn_size` | 7 | 锦标赛大小 |
| `rotate_eval_model` | True | 每代轮换实例种子 |

### 可解释性参数（configure_parameters_extra.py）

| 参数 | 默认值 | 说明 |
|---|---|---|
| `USE_LLM` | True | 是否启用 LLM 评分 |
| `SCORING_MODE` | "hybrid" | D1/D4/D5/D7 用代码计算，其余 LLM |
| `USE_CANONICAL` | True | 启用 AST 规范化 |
| `CLUSTER_THRESHOLD` | 0.65 | 聚类相似度阈值 |
| `CLUSTER_K_CANDIDATES` | 20 | 代表候选池大小 K |
| `CLUSTER_K_REP` | 1 | 每簇代表数 N |
| `CLUSTER_P1` | 100 | 簇预选：按 F1 取 1/P1 |
| `CLUSTER_P2` | 100 | 簇预选：按大小取 1/P2 |
| `CLUSTER_P3` | 100 | 簇预选：按 F2 取 1/P3 |
| `PARETO_FRONT_LEVELS` | 3 | 最终 Pareto 聚合前沿数 |
| `USE_EMBEDDING` | False | 是否使用本地 Embedding |

## 十六、算法数据流总览

```
┌─────────────────────────────────────────────────────────────┐
│  Generation G                                               │
│                                                             │
│  Parents(N) ──→ F1 评估 ──→ F2 流水线 ──→ (F1, F2)          │
│                          │                                  │
│                          ▼                                  │
│                    _breed_offspring                         │
│                          │                                  │
│                          ▼                                  │
│  Offspring(N) ──→ F1 评估 ──→ F2 流水线 ──→ (F1, F2)        │
│                          │                                  │
│                          ▼                                  │
│               combined = Parents + Offspring (2N)           │
│                          │                                  │
│                          ▼                                  │
│               NSGA-II Selection (非支配排序 + 拥挤度)       │
│                          │                                  │
│                          ▼                                  │
│               Deduplicate & Refill → Parents(N)             │
│                          │                                  │
│                          ▼                                  │
│               rotate_eval_model → 新实例种子                 │
│                                                             │
│  → Generation G+1                                           │
└─────────────────────────────────────────────────────────────┘
```
