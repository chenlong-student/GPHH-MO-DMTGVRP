# LLM-Guided Interpretability-Aware GPHH for Uncertain Capacitated Arc Routing Problem

> A Multi-Objective Optimization Framework Using NSGA-II with LLM-Quantified Interpretability

---

## 1. Research Motivation & Problem Statement

### 1.1 Background

**Uncertain Capacitated Arc Routing Problem (UCARP)** 是经典的组合优化问题，要求在满足车辆容量约束的前提下，为服务一组带随机需求的边设计最小成本的路径方案。

**Genetic Programming Hyper-Heuristic (GPHH)** 通过演化由终端节点（Terminal Nodes）和函数节点（Function Nodes）构成的 **GP Tree** 来自动发现 routing policy，其核心优势在于：

- **端到端的策略发现**：无需人工设计启发式规则
- **内在可解释性**：policy 由可读的树结构表示，理论上可以被人类理解

### 1.2 The Interpretability Gap

当前 GPHH 在 UCARP 中的可解释性量化方法存在**根本性缺陷**：

| 方法 | 定义 | 核心问题 |
|------|------|----------|
| Tree Height | GP Tree 的最大深度 | 忽略了语义等价性 |
| Tree Size | GP Tree 的节点总数 | 无法识别结构冗余 |

**关键反例**：
```
表达式 A: CFH + CFH + CFH + CFH    → height=4, size=7
表达式 B: 4 × CFH                   → height=2, size=3
```
两者在语义上完全等价，人类理解难度几乎相同，但传统度量给出截然不同的可解释性评分。

**根本原因**：传统方法只测量**语法层面的复杂度**，忽略了**语义层面的可理解性**。

### 1.3 Research Question

> **RQ**: 如何利用 Large Language Model 同时感知 GP Tree 的**结构（structure）**和**行为（behavior）**，构建一个更准确的、面向人类理解的可解释性量化指标？

---

## 2. Core Idea: LLM-Quantified Interpretability

### 2.1 可解释性的定义

在本研究中，GP Tree 的 **Interpretability Score** $I \in [0, 100]$ 定义为：

> 一个具备基础领域知识的人类专家，在给定 GP Tree 的结构描述和行为轨迹后，能够**正确理解**该 policy 的决策逻辑并**准确预测**其在新场景下行为的**容易程度**。

分数越高表示越容易被人类理解。

### 2.2 双视角评估框架

LLM 从两个互补的视角评估可解释性：

```
┌─────────────────────────────────────────────────────────┐
│                    LLM Evaluator                        │
├──────────────────────────┬──────────────────────────────┤
│   Structural View        │   Behavioral View            │
│   (静态 - "它长什么样")    │   (动态 - "它做了什么")       │
├──────────────────────────┼──────────────────────────────┤
│ • 树结构描述             │ • 决策轨迹                   │
│ • 节点语义               │ • 场景-行为映射              │
│ • 子树复用模式           │ • 决策一致性                 │
│ • 数学等价简化           │ • 边界行为                   │
│ • 逻辑分层               │ • 规则覆盖度                 │
└──────────┬───────────────┴──────────────┬───────────────┘
           │                              │
           ▼                              ▼
┌──────────────────────┐  ┌───────────────────────────────┐
│ I_structure ∈ [0,100]│  │ I_behavior ∈ [0,100]           │
└──────────┬───────────┘  └───────────────┬───────────────┘
           │                              │
           └──────────┬───────────────────┘
                      ▼
              I_final = α·I_struct + β·I_behav
              (默认 α=0.4, β=0.6)
```

---

## 3. Prompt Design for LLM Interpretability Scoring

这是本研究的核心贡献。以下为**完整的提示词工程设计**。

### 3.1 总体 Prompt 架构

采用 **Chain-of-Thought + Rubric-Based Scoring** 的两阶段提示词框架：

```
Stage 1: Structural Analysis Prompt  →  I_struct
Stage 2: Behavioral Analysis Prompt  →  I_behavior
                                        ↓
                              Aggregation Prompt → I_final
```

### 3.2 Stage 1: Structural Analysis Prompt

#### 3.2.1 输入构造

LLM 接收以下关于 GP Tree 的结构化描述：

**（A）树的前缀表达式（Prefix Notation）**
```
(+ (+ (* 2 RF) DQ) (- YC MC))
```

**（B）带语义注释的节点列表**
```
Node ID | Type     | Symbol | Semantic Meaning        | Children
--------|----------|--------|------------------------|----------
N0      | Function | +      | 加法组合                | N1, N6
N1      | Function | +      | 加法组合                | N2, N5
N2      | Function | *      | 缩放剩余负载因子         | N3, N4
N3      | Terminal | 2      | 常数权重=2              | -
N4      | Terminal | RF     | Remaining Fill ratio    | -
N5      | Terminal | DQ     | Demand to Quota ratio   | -
N6      | Function | -      | 容量-成本权衡            | N7, N8
N7      | Terminal | YC     | Yield Capacity          | -
N8      | Terminal | MC     | Mean Cost              | -
```

**（C）子树复用检测报告**
```
Detected repeated subtrees:
- Subtree "RF" appears 3 times at depths [2, 4, 5]
- Subtree "DQ" appears 2 times at depths [3, 6]
```

**（D）语义等价简化建议**（由符号引擎辅助生成）
```
Original:  (+ (+ (* 2 RF) DQ) (- YC MC))
Simplified: (+ (* 2 RF) (+ DQ (- YC MC)))
Redundancy: 无乘法可合并的常量倍数重复
```

#### 3.2.2 Structural Prompt 模板

```
You are an expert evaluator of heuristic policy interpretability.
Your task is to assess how easily a human domain expert can understand
the decision logic encoded in a GP Tree used for arc routing.

## Context
This GP Tree represents a routing policy for the Uncertain Capacitated
Arc Routing Problem (UCARP). At each decision point, the vehicle evaluates
this tree with current problem-state features as terminal inputs. The tree
outputs a priority score; the edge with the highest score is selected next.

## GP Tree Structure

### Prefix Expression
{prefix_expression}

### Node Inventory with Semantics
{node_table}

### Subtree Reuse Pattern
{subtree_reuse_report}

### Symbolic Simplification Analysis
{simplification_analysis}

## Evaluation Rubric (Structural Interpretability)

Score from 0 to 100 based on these dimensions:

### D1: Syntactic Simplicity (0-25 points)
- 25: ≤5 nodes, single operation type
- 20: ≤10 nodes, ≤2 operation types
- 15: ≤15 nodes, ≤3 operation types
- 10: ≤20 nodes, mixed operations
-  5: >20 nodes, deeply nested
-  0: >30 nodes, chaotic structure

### D2: Semantic Coherence (0-25 points)
- 25: All terminals are directly meaningful routing concepts
       (e.g., remaining_capacity, demand, distance)
       and combined in intuitively meaningful ways
- 20: Most terminals meaningful, combinations mostly logical
- 15: Mix of meaningful and opaque terminals
- 10: Several terminals lack clear routing interpretation
-  5: Most terminals are abstract/meaningless
-  0: No discernible semantic connection to routing

### D3: Structural Regularity (0-25 points)
- 25: Clear hierarchical pattern; subtrees represent
       distinct, named decision factors (e.g., "urgency", "cost")
- 20: Recognizable sub-components with identifiable roles
- 15: Some pattern but partially irregular
- 10: Weak structure; hard to decompose into logical parts
-  5: No discernible pattern
-  0: Appears randomly constructed

### D4: Semantic Redundancy Penalty (0-25 points)
Evaluate whether repeated subtrees are semantically justified:
- 25: No unjustified repetition; each subtree serves unique purpose
       OR repetitions are logically necessary (e.g., same feature
       used in different decision contexts)
- 20: Minor redundancy with partial justification
- 15: Noticeable redundancy but partially understandable
- 10: Significant unjustified repetition
-  5: Heavy redundancy suggesting bloat
-  0: Extreme redundancy; clearly bloated

## Key Guideline
CRITICAL: Do NOT confuse syntactic size with interpretability.
A tree like "CFH+CFH+CFH+CFH" (height 4, size 7) and "4*CFH"
(height 2, size 3) should receive SIMILAR interpretability scores
because they express the same semantic logic. The human reader
understands both as "scale CFH by 4".

## Output Format
Provide your analysis in this JSON format:
{
  "d1_syntactic_simplicity": <0-25>,
  "d2_semantic_coherence": <0-25>,
  "d3_structural_regularity": <0-25>,
  "d4_redundancy_assessment": <0-25>,
  "structural_interpretability_score": <sum of D1-D4>,
  "reasoning": "<2-3 sentence explanation of the score>"
}
```

### 3.3 Stage 2: Behavioral Analysis Prompt

这是更关键也更具挑战性的部分。GP Tree 的 behavior 指的是：**该 policy 在构建完整解的过程中所做的一系列决策及其上下文**。

#### 3.3.1 Behavior 数据的构造

在 GPHH 评估一个 GP Tree 时，我们对它在多个 problem instance 上的行为进行追踪，生成以下数据：

**（A）决策轨迹（Decision Trace）**

对每个 problem instance，记录 policy 的完整决策序列：

```
Instance: EGL-G1-n23.dat
Vehicle Route 1:
  Step 1: At depot → Selected edge (1,4)
    Feature values: RF=1.00, DQ=0.15, YC=100, MC=12.3
    Tree output: 8.45
    All candidates ranked: (1,4):8.45 > (1,7):6.21 > (1,2):5.03 > ...
    Decision rationale: High remaining capacity + low demand ratio

  Step 2: At node 4 → Selected edge (4,8)
    Feature values: RF=0.85, DQ=0.22, YC=85, MC=11.8
    Tree output: 7.12
    All candidates ranked: (4,8):7.12 > (4,5):6.88 > (4,9):3.21 > ...

  Step 3: At node 8 → Return to depot (capacity near full)
    ...

Vehicle Route 2:
  ...
```

**（B）决策规则提取摘要（Extracted Rule Summary）**

通过观察决策轨迹，自动提取 policy 表现出的行为模式：

```
Extracted Behavioral Patterns:
1. When RF > 0.7 AND DQ < 0.3: policy prefers edges with lower MC
   (observed in 78% of such decisions)
2. When RF < 0.3: policy consistently returns to depot
   (observed in 95% of such decisions)
3. When YC - MC > 50: policy shows aggressive routing behavior
   (observed in 62% of such decisions)
4. Otherwise: policy distributes selections across candidates
   without strong preference (entropy = 0.82)
```

**（C）决策一致性指标（Consistency Metrics）**
```
Decision Consistency:
- Same-state-similar-action rate: 0.91
  (when feature vector is similar, does policy make similar choice?)
- Rule coverage: 0.87
  (what fraction of decisions are explained by extracted patterns?)
- Decision entropy: 0.65
  (lower = more deterministic/predictable policy)
- Cross-instance stability: 0.88
  (does policy behave consistently across different instances?)
```

**（D）边界行为分析（Edge Case Behavior）**
```
Edge Case Analysis:
- When all demands are zero: policy selects shortest path (expected)
- When capacity = 1: policy serves one edge per trip (expected)
- When demand spike occurs: policy returns to depot immediately
  (this is interpretable: the RF term dominates)
```

#### 3.3.2 Behavioral Prompt 模板

```
You are an expert evaluator of heuristic policy interpretability.
Your task is to assess how easily a human domain expert can understand
the DECISION BEHAVIOR of a routing policy represented by a GP Tree.

## Context
The GP Tree below is used as a routing policy for UCARP. Rather than
examining its structure, we want to understand: can a human look at
the policy's behavior across multiple scenarios and form a clear,
coherent mental model of "what this policy does and why"?

## GP Tree (Reference)
Prefix Expression: {prefix_expression}
Simplified Form: {simplified_form}

## Behavioral Evidence

### Decision Trace Summary (aggregated across 5 instances)
{decision_trace_summary}

### Extracted Behavioral Rules
{extracted_rules}

### Consistency Metrics
{consistency_metrics}

### Edge Case Behavior
{edge_case_behavior}

### Decision Contrast Example
Here are two similar situations where the policy made DIFFERENT choices:
  Situation A: {situation_a} → Chose edge X because {reason_a}
  Situation B: {situation_b} → Chose edge Y because {reason_b}
The key difference: {key_difference}

## Evaluation Rubric (Behavioral Interpretability)

Score from 0 to 100 based on these dimensions:

### D5: Decision Predictability (0-25 points)
Can a human, after observing some decisions, accurately predict
what the policy will do in a new scenario?
- 25: Policy follows clear, articulable rules; human can predict
       next action with >90% accuracy after seeing 5-10 examples
- 20: Mostly predictable; occasional surprising decisions
- 15: Somewhat predictable; requires many examples to learn pattern
- 10: Weakly predictable; pattern exists but is complex
-  5: Barely predictable; appears semi-random
-  0: Unpredictable; no discernible pattern

### D6: Rule Simplicity (0-25 points)
How simple are the behavioral rules that describe the policy?
- 25: Policy can be described in 1-2 simple "if-then" rules
       (e.g., "prefer edges with low demand-to-capacity ratio")
- 20: 2-3 rules with simple conditions
- 15: 3-4 rules, some conditions are compound
- 10: 4+ rules with complex/nested conditions
-  5: Many rules; hard to summarize
-  0: No compact rule description exists

### D7: Behavioral Consistency (0-25 points)
Does the policy behave consistently across different instances?
- 25: Same logic applies uniformly across all instances
- 20: Minor variations but core logic is stable
- 15: Some instance-dependent behavior shifts
- 10: Logic varies significantly by instance
-  5: Highly instance-dependent
-  0: Completely different behavior per instance

### D8: Anomaly Justifiability (0-25 points)
When the policy makes unexpected decisions, can a human understand WHY?
- 25: All decisions have clear, intuitive justifications
       even if surprising at first glance
- 20: Most decisions are justifiable; few edge cases unclear
- 15: About half of surprising decisions can be explained
- 10: Most surprising decisions lack clear explanation
-  5: Only a few surprising decisions are explainable
-  0: Surprising decisions are inexplicable

## Key Guideline
A structurally complex tree may have HIGH behavioral interpretability
if its behavior follows simple, consistent rules. Conversely, a
structurally simple tree may have LOW behavioral interpretability if
its behavior is erratic or inconsistent.

Focus on what the policy DOES, not just what it LOOKS LIKE.

## Output Format
{
  "d5_decision_predictability": <0-25>,
  "d6_rule_simplicity": <0-25>,
  "d7_behavioral_consistency": <0-25>,
  "d8_anomaly_justifiability": <0-25>,
  "behavioral_interpretability_score": <sum of D5-D8>,
  "natural_language_summary": "<Describe this policy's behavior in
   1-2 sentences as you would explain it to a colleague>",
  "confidence": <0.0-1.0, how confident the LLM is in its assessment>
}
```

### 3.4 Stage 3: Aggregation Prompt

```
You have received two interpretability assessments for a GP routing policy:

Structural Score: {I_struct}/100
  Reasoning: {struct_reasoning}

Behavioral Score: {I_behav}/100
  Natural Language Summary: {behavior_summary}
  Confidence: {confidence}

## Task
Compute the final interpretability score I_final ∈ [0, 100].

### Weighting
- Structural weight: α = 0.4
- Behavioral weight: β = 0.6
- Base: I_final = 0.4 × I_struct + 0.6 × I_behav

### Adjustment Rules
Apply these adjustments to the base score:

1. If confidence < 0.5: reduce final score by 10%
   (LLM is uncertain about its behavioral assessment)

2. If structural and behavioral scores differ by >30 points:
   reduce final score by 5%
   (large discrepancy suggests unreliable assessment)

3. If natural_language_summary uses clear, simple language
   (≤30 words, no jargon): add 5 points
   (confirms behavioral interpretability)

### Output
{
  "base_score": <weighted average>,
  "adjustments": [<list of applied adjustments>],
  "final_interpretability_score": <0-100, rounded to integer>,
  "interpretability_level": "<Very Low|Low|Medium|High|Very High>"
}

Interpretability Levels:
- Very High (85-100): Policy is immediately understandable to any
  domain expert; behavior can be described in one sentence
- High (70-84): Policy is clearly understandable; requires brief
  explanation of edge cases
- Medium (50-69): Policy is moderately understandable; requires
  detailed explanation and examples
- Low (25-49): Policy is partially understandable; expert can
  identify some patterns but significant opacity remains
- Very Low (0-24): Policy is essentially opaque; no clear
  understanding achievable
```

---

## 4. Multi-Objective Optimization Framework (NSGA-II)

### 4.1 问题形式化

$$
\begin{aligned}
\min \quad & f_1(x) = \mathbb{E}\left[\text{Total Travel Cost}\right] \\
\max \quad & f_2(x) = I_{\text{final}}(x) \\
\text{s.t.} \quad & x \in \mathcal{T}
\end{aligned}
$$

其中 $\mathcal{T}$ 是所有可行 GP Tree 的搜索空间。

转换为最小化形式：
$$
\min \quad f_2'(x) = 100 - I_{\text{final}}(x)
$$

### 4.2 NSGA-II 流程

```
Initialize Population P(0) with random GP Trees
for gen = 1 to MaxGen:
    Q = TournamentSelection(P)
    R = CrossoverAndMutation(Q)

    # LLM-based fitness evaluation (expensive!)
    for each individual x in R:
        fitness_1(x) = evaluate_travel_cost(x)    # simulation-based
        fitness_2(x) = 100 - LLM_interpretability(x)  # LLM-based

    Combined = P ∪ R
    fronts = FastNonDominatedSort(Combined)
    P = BuildNextPopulation(fronts, CrowdingDistance)
```

### 4.3 LLM 调用优化策略

LLM 调用代价高昂，需要以下优化：

**策略 1：代际抽样评估（Generational Sampling）**
```
- 每代只对 Pareto front 上的个体 + 随机抽样的 k 个个体进行 LLM 评估
- 其余个体使用前一代的代理模型（surrogate model）估计 interpretability
- 代理模型：训练一个简单的回归模型（如 Random Forest），
  输入为 tree 的结构特征，输出为 predicted I_score
```

**策略 2：缓存机制（Caching）**
```
- 对结构等价（通过前缀表达式标准化后相同）的 GP Tree 缓存 LLM 评分
- Semantic hashing: 对 GP Tree 做代数简化后计算 hash
```

**策略 3：增量评估（Incremental Evaluation）**
```
- 子代 GP Tree 通常只与父代有局部差异
- 只让 LLM 评估变化的子树部分，而非整个树
- 父代 score 作为 anchor，LLM 给出 delta
```

**策略 4：延迟评估（Lazy Evaluation）**
```
- 第 1-10 代：不进行 LLM 评估，仅优化 objective 1
- 第 11 代起：每 G 代进行一次 LLM 评估
- 期间使用代理模型
```

---

## 5. Experimental Design

### 5.1 研究问题

| RQ | 问题 | 验证目标 |
|----|------|----------|
| RQ1 | LLM-based interpretability score 是否与人类评估的可解释性相关？ | 评分的**效度** |
| RQ2 | LLM-based score 是否比传统 height/size 指标更准确？ | 评分的**优越性** |
| RQ3 | 多目标优化是否能产生高质量的 Pareto front（cost vs interpretability）？ | 框架的**有效性** |
| RQ4 | LLM 调用优化策略对结果的影响如何？ | 策略的**实用性** |
| RQ5 | Pareto front 上的高可解释性 policy 是否确实更易于人类理解和使用？ | **实际应用价值** |

### 5.2 基准数据集

使用 UCARP 标准 benchmark：

| Dataset | #Edges | #Vehicles | Capacity | 特点 |
|---------|--------|-----------|----------|------|
| EGL-G1  | 23-55  | 2-4       | 100      | 小规模，结构规则 |
| EGL-G2  | 22-55  | 3-5       | 100      | 小规模，结构不规则 |
| EGL-G3  | 75-100 | 4-10      | 100      | 中规模 |
| BE-C    | 40-140 | 2-8       | variable | 真实路网 |
| DB      | 51-101 | 1-3       | variable | 真实路网 |

每个 instance 引入需求不确定性（如需求 ~ N(μ, σ²)）。

### 5.3 实验设置

#### 5.3.1 对比方法

| Method | Description | 可解释性度量 |
|--------|-------------|-------------|
| **MO-GPHH-LLM** (Ours) | NSGA-II + LLM interpretability | LLM score |
| MO-GPHH-Height | NSGA-II + tree height | height |
| MO-GPHH-Size | NSGA-II + tree size | size |
| Single-GPHH | 单目标，仅最小化 cost | N/A |
| MO-GPHH-Hybrid | NSGA-II + 0.5×height + 0.5×size | 混合传统指标 |

#### 5.3.2 NSGA-II 参数

| Parameter | Value |
|-----------|-------|
| Population size | 200 |
| Generations | 100 |
| Tournament size | 7 |
| Crossover rate | 0.8 |
| Mutation rate | 0.2 |
| Function set | {+, -, *, /, if, min, max} |
| Terminal set | {RF, DQ, YC, MC, DM, SC, Constants} |
| LLM model | GPT-4o / Claude Sonnet 4.x |
| LLM eval frequency | 每 5 代 |
| Sample size per eval | Pareto front + 20 random |

#### 5.3.3 LLM Prompt 参数

| Parameter | Value |
|-----------|-------|
| Temperature | 0.0 (deterministic scoring) |
| Max tokens | 2048 |
| Format | JSON mode |
| System prompt | 固定专家角色设定 |

### 5.4 评估指标

#### 5.4.1 多目标优化质量

| Metric | 描述 |
|--------|------|
| **Hypervolume (HV)** | Pareto front 的支配空间体积 |
| **IGD (Inverted Generational Distance)** | 与参考 Pareto front 的距离 |
| **Spread** | Pareto front 的分布均匀性 |
| **Pareto front size** | 非支配解的数量 |

#### 5.4.2 可解释性评分质量

| Metric | 描述 |
|--------|------|
| **Spearman ρ (vs human)** | LLM score 与人类评分的等级相关性 |
| **Kendall τ (vs human)** | LLM score 与人类评分的一致性 |
| **MSE (vs human)** | LLM score 与人类评分的均方误差 |
| **Height/Size correlation** | 与传统指标的相关性（应不完全相关） |

#### 5.4.3 人类可解释性验证实验

设计一项**用户研究**：

1. 从每种方法的 Pareto front 上选取 10 个 representative policies
2. 招募 20 名 OR/物流领域的研究人员作为评估者
3. 向评估者展示 policy 的结构和行为描述
4. 评估者完成以下任务：
   - **理解任务**：用自己的话描述该 policy 的决策逻辑
   - **预测任务**：给定 5 个新场景，预测 policy 的决策
   - **评分任务**：对 policy 的可解释性进行 0-100 评分
5. 比较：
   - 人类评分与 LLM 评分的相关性
   - 人类预测准确率（越高说明 policy 越可理解）
   - 人类描述质量（由独立 LLM 评判）

### 5.5 实验流程

```
Phase 1: LLM Scoring Validation (RQ1, RQ2)
├── 1a. 选取 50 个 diverse GP Trees（覆盖不同 height/size/structure）
├── 1b. LLM 对每个 tree 进行 interpretability scoring
├── 1c. 20 名人类评估者独立评分
├── 1d. 计算 LLM score 与 human score 的相关性
└── 1e. 对比 LLM score vs height/size 与 human score 的相关性

Phase 2: Multi-Objective Optimization (RQ3)
├── 2a. 运行 MO-GPHH-LLM 在所有 benchmark 上
├── 2b. 运行所有 baseline methods
├── 2c. 计算 HV, IGD, Spread 等指标
├── 2d. 分析 Pareto front 的 trade-off 特性
└── 2e. 可视化 Pareto front（cost vs interpretability）

Phase 3: LLM Optimization Strategies (RQ4)
├── 3a. 对比不同 LLM 调用优化策略
│   ├── Full evaluation (baseline)
│   ├── Generational sampling
│   ├── Surrogate-assisted
│   └── Lazy evaluation
├── 3b. 测量 LLM 调用次数和总耗时
├── 3c. 比较 Pareto front 质量差异
└── 3d. 确定最佳 trade-off 策略

Phase 4: Human Study (RQ5)
├── 4a. 选取 representative policies
├── 4b. 设计用户研究问卷和任务
├── 4c. 招募并培训评估者
├── 4d. 收集人类评估数据
├── 4e. 统计分析：理解准确率、预测准确率、评分一致性
└── 4f. 定性分析：人类对高/低 interpretability policy 的反馈
```

### 5.6 预期结果

#### 预期 1：LLM Score 效度
- LLM score 与 human score 的 Spearman ρ > 0.7
- LLM score 优于 height/size（ρ 提升 > 0.2）
- 对语义等价树（如 CFH×4 vs CFH+CFH+CFH+CFH）给出相近分数

#### 预期 2：Pareto Front 质量
- MO-GPHH-LLM 的 HV 显著优于 baseline
- Pareto front 展示清晰的 cost-interpretability trade-off
- 高 interpretability 端的 policy 仅牺牲 5-15% 的 cost 性能

#### 预期 3：人类验证
- 人类对 MO-GPHH-LLM 高 interpretability policy 的预测准确率 > 80%
- 人类描述质量评分显著高于 baseline 方法的 policy

---

## 6. Potential Challenges & Mitigation

### 6.1 LLM 评分的一致性

**问题**：LLM 可能对同一 GP Tree 给出不同评分。

**解决方案**：
- Temperature = 0 + JSON mode 确保确定性
- 对每个 tree 进行 3 次独立评估取中位数
- 使用 self-consistency：LLM 先输出 reasoning，再输出 score

### 6.2 LLM 评分的计算成本

**问题**：每次 LLM 调用需要数秒，100 代 × 200 个体不可行。

**解决方案**：参见 Section 4.3 的优化策略。
- 预计使用 Surrogate-assisted 策略可将 LLM 调用减少 80-90%
- 总 LLM 调用次数：约 500-1000 次（vs 20,000 次全量评估）

### 6.3 LLM 评分的偏见

**问题**：LLM 可能对某些结构类型（如平衡树 vs 不平衡树）有系统性偏见。

**解决方案**：
- Phase 1 的人类研究可检测系统性偏见
- 使用多种 LLM 模型交叉验证（GPT-4o + Claude + LLaMA）
- 对已知语义等价的树对进行 bias 测试

### 6.4 行为数据的构造质量

**问题**：behavior 数据的质量直接影响 LLM 评估的准确性。

**解决方案**：
- 使用多样化的 problem instances 覆盖不同场景
- 决策轨迹使用自动摘要 + 关键决策高亮
- 行为规则提取使用决策树拟合（用决策树近似 GP Tree 的行为）

### 6.5 多目标优化的收敛性

**问题**：Interpretability score 是 off-policy（不通过梯度）的离散评估，可能影响 NSGA-II 的收敛。

**解决方案**：
- 使用代理模型提供连续的 interpretability estimate
- 增大种群规模（200+）和代数（100+）
- 引入 elitism 保留 Pareto-optimal 个体

---

## 7. Paper Structure (Proposed)

```
1. Introduction
   1.1 Background: UCARP and GPHH
   1.2 The Interpretability Challenge
   1.3 Limitations of Current Interpretability Metrics
   1.4 Contributions

2. Related Work
   2.1 GPHH for Arc Routing Problems
   2.2 Interpretability in Evolutionary Computation
   2.3 LLMs for Code/Policy Understanding
   2.4 Multi-Objective Optimization in Heuristic Design

3. Problem Formulation
   3.1 UCARP Definition
   3.2 GPHH Framework
   3.3 Multi-Objective Formulation

4. Methodology
   4.1 LLM-Based Interpretability Scoring
       4.1.1 Structural Analysis
       4.1.2 Behavioral Analysis
       4.1.3 Score Aggregation
   4.2 NSGA-II Framework
   4.3 LLM Evaluation Optimization Strategies

5. Experimental Design
   5.1 Benchmark Datasets
   5.2 Baseline Methods
   5.3 Evaluation Metrics
   5.4 Human Study Protocol

6. Results and Analysis
   6.1 LLM Scoring Validation (RQ1, RQ2)
   6.2 Multi-Objective Optimization Performance (RQ3)
   6.3 LLM Optimization Strategies (RQ4)
   6.4 Human Study Results (RQ5)
   6.5 Qualitative Analysis of Pareto-Optimal Policies

7. Discussion
   7.1 Implications for Interpretable GPHH
   7.2 Generalizability to Other Domains
   7.3 Limitations

8. Conclusion and Future Work
```

---

## 8. Timeline & Milestones

| Phase | Duration | Milestone |
|-------|----------|-----------|
| Literature Review | Month 1 | Related work section drafted |
| LLM Prompt Development | Month 2 | Prompts validated on 50 trees |
| Human Study (Phase 1) | Month 3 | LLM vs human correlation results |
| MO Framework Implementation | Month 3-4 | NSGA-II + LLM integration complete |
| Main Experiments | Month 4-5 | All benchmark results collected |
| LLM Optimization Experiments | Month 5 | Strategy comparison complete |
| Human Study (Phase 2) | Month 5-6 | User study complete |
| Paper Writing | Month 6-7 | First draft complete |
| Revision & Submission | Month 7-8 | Paper submitted |

---

## 9. Appendix: Detailed Prompt Examples

### A.1 完整 GP Tree 示例及预期评分

**Tree A** (高可解释性):
```
Prefix: (if (< RF 0.2) -999 (+ DQ (* 2 MC)))
Meaning: "如果剩余容量不足20%，返回depot（-999）；
         否则按 demand-to-quota + 2×mean-cost 排序"
Expected I_score: 85-95
```

**Tree B** (中等可解释性):
```
Prefix: (+ (* RF DQ) (- (/ YC MC) (max SC DM)))
Meaning: "组合剩余负载率和需求配额作为基础分，
         减去容量-成本比与最坏情况的较大值"
Expected I_score: 55-70
```

**Tree C** (低可解释性):
```
Prefix: (+ (* (- (+ RF DQ) (/ MC YC)) (min SC DM))
           (/ (- (* RF SC) DQ) (+ MC 0.3)))
Meaning: 复杂非线性组合，难以用自然语言简洁描述
Expected I_score: 20-40
```

### A.2 行为数据生成伪代码

```python
def generate_behavior_data(gp_tree, instances, n_scenarios_per_instance=10):
    """Generate behavioral evidence for a GP tree across instances."""

    all_decisions = []
    for instance in instances:
        solution = evaluate_gp_tree(gp_tree, instance)
        for route in solution.routes:
            for step in route.decision_steps:
                decision = {
                    'current_node': step.location,
                    'feature_vector': step.features,  # {RF, DQ, YC, MC, ...}
                    'tree_output': step.policy_score,
                    'selected_edge': step.chosen_edge,
                    'all_candidates': step.rankings,  # all edges scored
                    'reason': explain_decision(
                        gp_tree, step.features, step.chosen_edge
                    )
                }
                all_decisions.append(decision)

    # Extract behavioral rules using decision tree approximation
    rules = extract_rules_from_decisions(
        X=[d['feature_vector'] for d in all_decisions],
        y=[d['selected_edge'] for d in all_decisions]
    )

    # Compute consistency metrics
    consistency = compute_consistency_metrics(all_decisions)

    # Analyze edge cases
    edge_cases = analyze_edge_cases(gp_tree)

    return {
        'decisions': all_decisions,
        'rules': rules,
        'consistency': consistency,
        'edge_cases': edge_cases
    }
```

### A.3 代理模型训练

```python
def train_interpretability_surrogate(train_data):
    """
    Train a surrogate model to predict LLM interpretability score
    from GP tree structural features.

    Features:
    - tree_height, tree_size, tree_depth_avg
    - num_unique_terminals, num_unique_functions
    - subtree_reuse_ratio
    - nesting_depth, branching_factor
    - semantic_coherence_proxy (based on terminal types)
    - constant_count, arithmetic_operator_balance

    Target: LLM_interpretability_score
    """
    from sklearn.ensemble import RandomForestRegressor

    X = extract_features(train_data['gp_trees'])
    y = train_data['llm_scores']

    model = RandomForestRegressor(n_estimators=100, max_depth=8)
    model.fit(X, y)

    return model
```

---

## 10. Key References (To Be Expanded)

1. Mei, J., et al. "Genetic programming hyper-heuristic for the capacitated arc routing problem." *IEEE TEVC* (2014).
2. Deb, K., et al. "A fast and elitist multiobjective genetic algorithm: NSGA-II." *IEEE TEVC* (2002).
3. Burke, E.K., et al. "Hyper-heuristics: A survey of the state of the art." *JORS* (2013).
4. Liao, Z., et al. "Interpretability in genetic programming: A survey." *GPTP* (2022).
5. Recent work on LLM-based code explainability and neural-symbolic reasoning.
6. Arrieta, A.B., et al. "Explainable Artificial Intelligence (XAI): Concepts, taxonomies, opportunities and challenges." *Information Fusion* (2020).
